# Semantic Animation Architecture

This document outlines the high-level architecture for a professional Mermaid animator that adheres to the "Durable Diagram Automation" principles.

## 1. Pipeline Overview
1.  **Ingestion**: Extract Mermaid text from Markdown.
2.  **Detection**: Utilize `type-router.js` to identify `diagramType` via regex patterns (e.g., `flowchart`, `sequenceDiagram`, `stateDiagram-v2`).
3.  **Tokenization**: Route code to a dedicated tokenizer in `src/tokenizers/`. Current supported tokenizers include `flowchart.js`, `state.js`, and `sequence.js`.
4.  **Semantic Mapping**:
    *   **Identity**: Generate stable IDs (Edge HRN, State ID, or Message ID) to prevent collisions.
    *   **Inference**: Analyze labels and structural roles for semantic grouping (e.g., `observability`, `data`).
    *   **Profiles**: Assign an "Animation Strategy" (e.g., `traveling-dot`, `sequential-pulse`) based on the diagram type.
5.  **Transformation**: Generate an "Animation Manifest" mapping IDs to specific CSS classes, animation paths (`mpath`), and timing parameters.
6.  **Generation**: Output HTML shell with strategy-specific CSS keyframes.

## 2. Risk Mitigation: The Mapping Algorithm
The bridge between the logical model and the rendered SVG is the most fragile layer.
*   **Label Matching**: Primary strategy targets `<span>` or `<text>` elements containing edge labels.
*   **Geometric Proximity**: Fallback strategy uses node bounding boxes to identify paths connecting logical source/target.
*   **Path Ordinals**: Tertiary strategy uses stable ordering within subgraph containers.
*   **Warning System**: Edges that cannot be mapped with high confidence are tagged with `.animate-unmapped` for visibility.

## 3. Thin HTML Shell Boundary
The generated HTML must remain "dumb."
*   **No conditional logic**: JS only applies classes from the Manifest to the DOM.
*   **CSS Variables**: All timing (`--anim-delay`) and styling is driven by vars injected into elements.
*   **Profile-Driven CSS**:
    *   **Flow Profile**: Uses `stroke-dashoffset` for "Traveling Dot" or flow motion.
    *   **Temporal Profile**: Uses `opacity` and `transform: scale` for step-wise activation.
    *   **Metric Profile**: Uses `filter: drop-shadow` and `transform` for data-driven pulsing.

## 4. Determinism & Stability
*   **Seeded PRNG**: All jitter or delays must be deterministic given the same input seed.
*   **Semantic Hashing**: Validate the stability of the tool by hashing the logical semantic assignments, insulating tests from Mermaid's DOM output variance.
