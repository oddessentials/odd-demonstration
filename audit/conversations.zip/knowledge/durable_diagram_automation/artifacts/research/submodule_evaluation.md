# Submodule Evaluation: Multi-Type Mermaid Diagrams

The `Mermaid-graphs` submodule serves as a comprehensive test suite and reference for the diverse types of diagrams supported by Mermaid. A 2025-12-28 audit identified 22+ distinct diagram types, each presenting unique challenges and opportunities for semantic animation.

## 1. Diagram Type Inventory

| Category | Diagram Types | Animation Strategy | Status |
| :--- | :--- | :--- | :--- |
| **Edge-Flow** | `flowchart`, `stateDiagram-v2`, `sequenceDiagram`, `C4Dynamic`, `architecture-beta`, `requirementDiagram` | Traveling Dot / Path Pulse | Phase 1 |
| **Data-Flow** | `sankey-beta` | Gradient Stream | Phase 2 |
| **Radial/Segment** | `pie`, `radar-beta` | Reveal/Trace Animations | Phase 2 |
| **Timeline/Bar** | `gantt`, `xychart-beta`, `timeline`, `quadrantChart` | Cascade/Rise Effects | Phase 2 |
| **Hierarchy** | `mindmap`, `gitGraph`, `classDiagram` | Branch Grow / Node Highlight | Phase 2 |
| **Static/Layout** | `block-beta`, `packet-beta`, `kanban`, `erDiagram` | Minimal Glow / Static | Phase 2 |

## 2. Animator Architectural Evolution

The `odd-mermaid-animator` has evolved from a flowchart-centric tool to a modular architectural visualizer:

*   **Router-Based Detection**: The `type-router.js` layer now dynamically detects `diagramType` using regex headers, moving beyond the `flowchart`-only limitation.
*   **Modular Tokenization**: The transition to a `src/tokenizers/` directory allows for diagram-specific parsing logic (e.g., `sequence.js` for messages, `state.js` for composite nodes) while maintaining a unified semantic link.
*   **Strategy Branching**: The system now supports multiple animation strategies (e.g., `traveling-dot`, `sequential-pulse`), enabling semantically appropriate motion for different diagram categories.

## 3. Categorization Strategy

To support the full submodule breath, diagrams should be grouped into **Animation Profiles**:

1.  **Traveling Dot Strategy**: (Edge-Flow) Focuses on path traversal using dots or dashed animation keyframes. Best for directed acyclic graphs (DAGs).
2.  **Stream Flow Strategy**: (Data-Flow) Focuses on proportional volume movement using animated gradients within wide paths.
3.  **Reveal Strategy**: (Radial, Timeline) Focuses on sequential visibility using `clip-path` sweeps or staggered opacity shifts.
4.  **Growth Strategy**: (Hierarchy) Focuses on branch expansion from a root node using `stroke-dashoffset` path drawing.

## 4. Deterministic Strategy Beyond "Dot Flow"

Transitioning from "Dot Flow" to a broader deterministic model requires:
*   **Semantic Grouping expansion**: Beyond "observability" or "data", mapping to structural roles (e.g., `primary-actor`, `authoritative-source`).
*   **Diagram-Specific CSS Keyframes**: Custom animations for `sequenceDiagram` (e.g., `.msg-glow`) and `pie` (e.g., `.sector-pulse`).
*   **Phase-Aware Rendering**: Using the existing `phase` logic to drive complex multi-diagram coordination within a single document.
