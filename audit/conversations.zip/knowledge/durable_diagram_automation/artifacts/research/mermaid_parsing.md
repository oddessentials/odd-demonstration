# Mermaid Parsing & AST Extraction Research

To implement the "Durable Diagram Automation" principles, the tool must move away from regex and toward programmatic AST access.

## Identified Parsing Strategies

### 1. `@kamataryo/mermaid-js`
*   **Purpose**: A dedicated parser for Mermaid diagrams.
*   **Capability**: Provides a `parse` function that converts Mermaid text into a `DiagramAST`.
*   **Benefit**: Strongly typed AST suitable for programmatic traversal of nodes and edges.

### 2. `@rendermaid/core`
*   **Purpose**: TypeScript library for parsing and rendering.
*   **Capability**: Includes `parseMermaid` function returning a `MermaidAST`.
*   **Benefit**: Functional architecture with immutable data structures; supports JSON output.

### 3. Native `mermaid.parse()`
*   **Purpose**: Part of the core Mermaid API.
*   **Capability**: Primarily validates syntax and returns basic info (e.g., `diagramType`).
*   **Limitation**: Does not natively expose a rich, traversable AST for easy edge/node manipulation without deeper diving into internal Jison parsers.

## Final Strategy: First-Class Tokenizer
While external parsers like `@rendermaid/core` provide rich ASTs, they often trail behind Mermaid's core syntax updates or rely on internal APIs that aren't contractually stable.

**Decision**: Implement a dedicated, first-class tokenizer for a robust **Supported Subset v1** (`flowchart LR/TD`, solid/dotted/thick arrows, subgraphs).

*   **Benefit**: Full control over edge identity and cross-version stability.
*   **Safety**: Explicitly warns on unsupported syntax rather than silent failure.
*   **Portability**: Zero external dependencies for the parsing stage, making the tool a thin, durable "compiler".
