# Durable Diagram Automation Principles

These principles guide the development of professional, extensible tools for animating and manipulating Mermaid diagrams.

## 1. Semantic Durability
*   **Decouple from Indices**: Avoid coupling semantics to fragile rendering directives like `linkStyle` indices or specific colors. Indices change whenever the diagram structure is modified, leading to "maintenance debt".
*   **Infer from Structure**: Semantics (direction, importance, phase) should be inferred from the graph topology or explicit annotations/metadata, not from visual rendering side effects.

## 2. Topological Integrity
*   **Topological Directionality**: Animation direction must be derived from the graph topology (source → target) rather than stroke order or CSS dash offsets. This prevents "inverted flows" when Mermaid updates its SVG generation logic.
*   **Tokenizer-First Architecture**: Treat Mermaid syntax as a compiler target. Because internal ASTs are often unstable across versions, rely on a robust, well-defined tokenizer for the supported subset rather than fragile internal APIs.

## 3. Resilience & Adaptation
*   **Graceful Degradation**: Systems should animate meaningfully even without explicit grouping hints. Emphasize basic flow and directionality by default.
*   **Risk Center: AST↔SVG Mapping**: Mapping logical edges to SVG paths is the highest risk area. Treat this as a core algorithm involving label matching, geometric proximity, and path ordering, rather than simple glue code.
*   **Safe Handling of SVG Internals**: Do not rely on unstable SVG selectors (e.g., `<path marker-end>`). Build abstraction layers that tolerate DOM reordering or marker strategy changes.
*   **Explicit Failure Modes**: Silence is a failure. If mapping fails or semantics are ambiguous, surface warnings in the output (CLI or HTML classes) to maintain trust and visibility.

## 4. Operational Excellence
*   **Performance Stress Targets**: Define explicit upper bounds for diagram complexity (e.g., 200+ edges). Ensure animations remain GPU-friendly and bounded to avoid regressions as diagrams scale.
*   **Deterministic Semantic Assignments**: Determinism must extend to the semantic results. Hash the semantic assignments—not just the final HTML bytes—to ensure stable behavior across renders.
*   **Portable Output**: HTML output should be a truly "thin shell." All semantic resolution happens pre-generation; the HTML only applies classes and CSS variables.

## 5. Design for Meaning
*   **Communication Over Novelty**: Motion must reinforce understanding of direction, causality, and flow. It should not be a distraction.
*   **Observable & Overridable Semantics**: Keyword-based grouping and phase ordering must be observable (via logs/metadata) and overridable by explicit author hints to prevent the tool from becoming an "implicit policy" engine.
*   **Generalize Beyond Flowcharts**: Design for "directed relationships" as a concept. Validate abstractions against multiple diagram types (Sequence, State) to ensure durability.
