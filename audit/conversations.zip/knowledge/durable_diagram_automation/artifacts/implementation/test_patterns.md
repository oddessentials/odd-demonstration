# Hardened Testing Patterns for Diagram Automation

Testing professional diagram automation requires moving beyond visual inspection to structural and semantic verification.

## 1. Unit Testing the Tokenizer
The tokenizer must be tested against a wide range of Mermaid syntax variations to ensure robust edge and node extraction.

*   **Pattern Matching**: Verify all arrow types (`-->`, `-.->`, `==>`) and label combinations.
*   **Subgraph Scoping**: Ensure edge ordinals are correctly scoped to subgraphs.
*   **ID Stability**: Verify that IDs remain stable even if unrelated lines are added to the Mermaid source.

## 2. Semantic Regression Testing
Verify that the inference engine correctly assigns groups and phases without over-reaching.

*   **Keyword Collisions**: Test labels that contain multiple domain keywords.
*   **Quote Handling**: Ensure phase detection works on both `"1. Label"` and `1. Label`.
*   **Sequential Logic**: Verify warnings are emitted for non-sequential phase numbers.

## 3. Integration Determinism
Professional automation requires bit-identical results for identical inputs to build user trust.

*   **HTML Hash Check**: Verify that `SHA256(html1) === SHA256(html2)` for two consecutive runs on the same input, ensuring zero hidden non-determinism (Random/Date).
*   **Semantic Model Stability**: Validate that the logical model (enriched edges) remains unchanged across runs, isolating errors from Mermaid SVG variance.
*   **Seeded Jitter**: Confirm that animation delays are reproducible via seeded hashing (`tests/integration.test.js`).

## 4. Animation Behavior Verification
To avoid "unnoticeable" animations and ensure correctness, the visual behavior must be locked in with structural tests.

*   **Color Matching Proof (Runtime Sync)**: Verify that the traveling dot creation code explicitly uses `window.getComputedStyle(path).stroke`. This structural test proves the system is designed to dynamically match the line color at runtime, bypassing the "Render-State Gap" where build-time styles are overridden.
*   **Topological Flow Direction (Topology Proof)**: Assert that the `<animateMotion>` element correctly references the path ID and follows the path without `keyTimes` or `keyPoints` that might reverse the direction. This proves the animation matches the parsed `from → to` direction.
*   **Visual Complexity**: Verify that "flow" edges receive dual trailing dots for enhanced momentum, while async edges receive a single dot.
*   **Staggered Timing**: Ensure `begin` attributes on animations use the calculated `anim.delay` to prevent simultaneous bursts that reduce visual clarity.

## 5. Performance & Stress Targets
*   **Edge Scaling**: Test with a 200-edge generated diagram to ensure rendering stays under 100ms and maintains 60fps.
*   **Memory Efficiency**: Verify the tokenizer handles large input without excessive string allocation.

## 6. Implemented Test Suites
The following verification layers are implemented in `mermaid-flow-animator`:

| Test File | Coverage |
|-----------|----------|
| `tests/tokenizer.test.js` | Flowchart/Graph arrow types, subgraphs, ordinal scoping |
| `tests/state-tokenizer.test.js` | StateDiagram-v2 transitions, composite states, choice/fork/join |
| `tests/sequence-tokenizer.test.js` | SequenceDiagram participants, actors, message types, activation |
| `tests/type-router.test.js` | Diagram type detection, tokenizer routing, error handling |
| `tests/semantic.test.js` | Group inference, phase detection, quote stripping, keywords |
| `tests/animation.test.js` | Traveling dot colors (SSOT), direction correctness (TOPOLOGY PROOF) |
| `tests/integration.test.js` | End-to-end generation, HTML determinism, model stability |
| `tests/benchmark.js` | Stress testing 200+ edges, 60fps render timing |

## 7. Visual Regression & DOM Fidelity
Build-time logic verification (e.g., hashing the produced HTML) is insufficient for detecting visual regressions introduced by the rendering engine's dynamic behavior (e.g., Mermaid's CSS overrides).

*   **The Render-State Gap**: Tests must acknowledge that the "truth" resides in the DOM after the renderer (Mermaid) has finished its cycle.
*   **Runtime Assertions**: Implement lightweight runtime checks in the generated HTML to verify that animations (dots) successfully match their parent paths' visual properties.
*   **Manual Verification Protocol**: Until high-fidelity E2E/Headless tests are integrated, a mandatory visual checklist for "Color Harmony" (dot color == line color) is required for architectural reviews.
