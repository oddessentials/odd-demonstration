# Multi-Tokenizer Strategy (Phase 1)

To support the diverse range of Mermaid diagram types found in the `Mermaid-graphs` submodule, the animator architecture has been moved to a modular, router-based tokenization system.

## 1. Directory Structure

The core logic is organized to separate diagram-specific parsing from general semantic inference and generation:

```text
src/
├── type-router.js       # Central detection and routing
├── config.js            # Shared edge patterns and profiles
├── tokenizer.js         # Existing entry point (maintained for compat)
└── tokenizers/          # Diagram-specific logic
    ├── flowchart.js     # Refactored flowchart/graph logic
    ├── state.js         # New stateDiagram-v2 logic
    └── sequence.js      # New sequenceDiagram logic
```

## 2. Type Detection Router (`type-router.js`)

The router identifies the diagram type by checking the first lines of the Mermaid code against known headers:

*   **Flowchart**: `/^flowchart\s+(LR|TD|TB|RL|BT)/m` or `/^graph\s+(LR|TD|TB|RL|BT)/m`
*   **State**: `/^stateDiagram-v2/m` or `/^stateDiagram\s/m`
*   **Sequence**: `/^sequenceDiagram/m`
*   **C4 (Future)**: `/^C4Dynamic/m`, `/^C4Context/m`, etc.

Once detected, the router invokes the appropriate tokenizer and assigns an **Animation Strategy**.

## 3. Tokenizer Implementation Patterns

### State Diagrams (`tokenizers/state.js`)
*   **Composite States**: Tracks nesting using a parent stack to correctly assign subgraphs.
*   **Special Nodes**: Handles `<<choice>>`, `<<fork>>`, and `<<join>>` as semantic nodes.
*   **Stable Identity**: Maps transitions `State1 --> State2` to stable IDs using `hash(from, to, label, parent, ordinal)`.

### Sequence Diagrams (`tokenizers/sequence.js`)
*   **Lifeline Activation**: Parses `->>+` and `->>-` markers to track participant state.
*   **Participant Aliasing**: Resolves `participant p as Participant Name` to ensure stable connectivity.
*   **Message Ordering**: Uses `ordinal` relative to the vertical flow of the diagram to drive sequential animation timing.
*   **Message Patterns**: Supports solid/dotted lines with various arrow heads:
    *   `->>`, `-->>` (Arrow)
    *   `->`, `-->` (Open)
    *   `-x`, `--x` (Cross)
    *   `-)`, `--)` (Async)

## 4. Animation Strategy Mapping

Phase 1 focus on **Edge-Flow** charts allows for maximal code reuse of the "Traveling Dot" pattern:

| diagramType | animationStrategy | Key Marker |
| :--- | :--- | :--- |
| `flowchart` | `traveling-dot` | `marker-end` on `<path>` |
| `state` | `traveling-dot` | Transitions as `<path>` |
| `sequence` | `sequential-pulse` | Messages as `<line>` |

## 5. Technical Refinements & Regex Hurdles

During Phase 1 testing, several technical hurdles were identified and resolved to ensure parser robustness:

### State Transition Ambiguity
The initial state transition regex `(\[?\*?\]?|\w+)` was found to be too broad, potentially matching empty strings or failing on `[*]` boundaries.
*   **Fix**: Rewrote to `(\w+|\[\*\])\s*-->\s*(\w+|\[\*\])` to prioritize explicit word characters or the escaped `[*]` literal, ensuring deterministic capture of state names.

### Sequence Message Greediness
In sequence diagrams, the use of lazy matching `(.+?)` for participant names can cause collisions if multiple dashes or arrow markers are present on a single line (e.g., `A -->> B`).
*   **Hurdle**: If `A -` is captured by the first group, the second portion might incorrectly match a different arrow pattern.
*   **Pattern Ordering**: Ensuring that the most specific patterns (e.g., `->>>`, `->>+`) are checked before more generic ones (`->`, `-->`), and anchoring participant IDs to non-whitespace characters where possible.

## 6. Phase 1 Completion Summary
As of 2025-12-28, the animator successfully supports Flowchart, State, and Sequence diagrams with a unified entry point and modular parsing. The system is verified with 60 tests covering 15 suites, ensuring shared semantic and animation logic across all Phase 1 types.
