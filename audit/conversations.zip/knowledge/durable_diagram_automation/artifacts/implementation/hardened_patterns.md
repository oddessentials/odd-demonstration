# Hardened Diagram Automation Patterns

These patterns represent the concrete implementation of the "Durable Diagram Automation" principles, as applied in the `mermaid-flow-animator` project.

## 1. Modular Extraction logic
The ingestion phase must safely identify Mermaid blocks within larger markdown documents without assuming single-diagram files.

```javascript
/**
 * Safely extracts content within ```mermaid fence.
 * Returns {code, found} to allow graceful failure.
 */
export function extractMermaidBlock(markdown) {
  const match = markdown.match(/```mermaid\r?\n([\s\S]*?)```/);
  return { code: match ? match[1].trim() : '', found: !!match };
}
```

## 2. Stable Edge Identity
To prevent ID collisions and maintain stability across diagram edits, edge IDs are generated using a combination of topological and positional data.

```javascript
/**
 * Edge ID = hash(from, to, label, subgraph, ordinal)
 * ordinal is scoped to the subgraph to ensure uniqueness 
 * even if node pairs are repeated.
 */
export function edgeId(from, to, label, subgraph, ordinal) {
  return hash(`${subgraph}:${from}→${to}:${label ?? ''}:${ordinal}`);
}
```

## 3. Modular Multi-Tokenizer Architecture
Instead of a monolithic parser, the system uses a modular architecture where diagram-specific logic is isolated.

*   **Type Discovery**: A pre-tokenization phase detects titles (e.g., `flowchart`, `sequenceDiagram`) to route to the correct parser.
*   **Isolated Tokenizers**: Each diagram type has a dedicated tokenizer (e.g., `src/tokenizers/sequence.js`) that maps domain-specific syntax to the standard semantic model.
*   **Standard Interface**: All tokenizers return a unified `ParseResult` (nodes, edges, direction, warnings), allowing the semantic engine to remain diagram-agnostic.
*   **Recursive Subgraph Tracking**: Stack-based approaches track nesting (subgraphs in flowcharts, composite states in state diagrams) to correctly scope edge ordinals.

## 4. Observable Semantic Inference
Semantic groups and phases are inferred from labels and keywords using a rules-based engine.

*   **Rule Prioritization**: Explicit overrides > Numbered labels (phases) > Dotted arrows (async) > Keywords (domain-specific).
*   **Phase Extraction**: Detects phase numbers (e.g., `1.`, `2)`) from labels after stripping quotes.
*   **Keyword Detection**: Scans labels, node names, and subgraph IDs for domain keywords (e.g., `observability`, `messaging`, `data`).

```javascript
// Stripping quotes for phase detection
const cleanLabel = edge.label.replace(/^["']|["']$/g, '').trim();
const phaseMatch = cleanLabel.match(PHASE_PATTERN);
```

## 5. Multi-Tier SVG Mapping (Risk Center)
The algorithm for binding logical edges to rendered SVG `<path>` elements uses a high-confidence cascading strategy:

1.  **Label Normalization**: Labels are normalized (lowercase, whitespace collapsed) both in the model and the DOM to improve match rates.
2.  **Label Proximity**: Primary strategy matches paths closest to correctly identified label `<span>` elements.
3.  **Ordinal Fallback**: Match remaining paths by their stable internal order within subgraph containers.
4.  **Disambiguation**: Use `ordinal` as a stable key when multiple identical paths exist between the same nodes.
5.  **Visibility of Failure**: Paths not reaching the confidence threshold are tagged with `.edge-unmapped` for visual auditing.

## 6. Logic-Free HTML Shell
The generated HTML is a "dumb" container. All semantic decisions are resolved at build-time.

*   **Manifest Injection**: The HTML receives an `EDGE_ANIMATIONS` manifest containing pre-computed delays, groups, and phase info.
*   **CSS Variable Driving**: Timing and styling are applied via CSS variables (e.g., `--anim-delay`) rather than imperative JS timers.
*   **Mapping Script**: A standard, non-conditional mapping script (`mapEdgesToPaths`) runs post-render to bind logical IDs to SVG paths.

## 7. Deterministic Jitter
Non-random "jitter" is used for animation delays to ensure that the visualization remains stable across refreshes and identical in different environments.

```javascript
export function jitter01(i) {
  let x = (i + 1) * JITTER_SEED;
  x ^= x >>> 16;
  x = Math.imul(x, 2246822519);
  x ^= x >>> 13;
  x = Math.imul(x, 3266489917);
  x ^= x >>> 16;
  return (x >>> 0) / 4294967296;
}
```

## 8. High-Visibility Visual Polish
To ensure animations are effective communication tools (and not just subtle novelties), use a high-visibility styling strategy.

*   **Strong Glow Effects**: Use multiple `drop-shadow` filters for a vibrant "neon" glow that is clearly visible against dark backgrounds.
*   **Faster Flow Rhythms**: Use shorter durations (`0.7s`) and larger `stroke-dashoffset` for "flow" edges to convey momentum.
*   **Traveling Dot Animation**: Complement dashed-line animations with animated SVG `<circle>` elements that follow the path via `<animateMotion>`. This provide unmistakable directionality, especially on complex diagrams.
*   **Variable Stroke Width**: Assign higher `stroke-width` (e.g., `3.5px` for active flow, `2px` for background) using `!important` to override Mermaid's default inline styles.
*   **Group-Specific Rhythms**:
    *   **Flow**: Larger dots, dual "stream" effect (offset dots), and faster dash movement (`0.7s`).
    *   **Async/Default**: Smaller dots (single), longer durations (`1.5s - 2s`), and subtle colored glows.
*   **Performance Invariant**: Ensure that `drop-shadow` and `animateMotion` animations are GPU-accelerated. Limit filter complexity to maintain 60fps even with 200+ edges.

## 9. Robust SVG Path Injection
Since Mermaid renders SVGs dynamically, the injection of animation logic must handle the rendering lifecycle.

*   **Namespace Awareness**: Always use `http://www.w3.org/2000/svg` when creating new SVG elements (like dots or animation tags) via JavaScript.
*   **ID Sanitization**: Use a sanitized path ID (e.g., `path-${anim.id.replace(/[^a-zA-Z0-9]/g, '')}`) to ensure valid CSS/DOM identifiers when linking `<mpath>` to a `<path>`.
*   **Timing Offsets**: Apply `begin` offsets for phase-based animations or deterministic jitter to prevent "rhythmic clumping" of animations.
## 10. Single Source of Truth for Visuals
To prevent discrepancies between edge line colors (CSS) and traveling dot colors (JavaScript), the build-time generator must use a single source of truth for styles.

*   **Config-Driven Styling**: All colors, dash patterns, and durations are defined in a central `config.js` (`ANIMATION_PROFILES`).
*   **Synchronized Generation**: The HTML generator injects the *same* profile data into both the generated CSS block and the client-side JavaScript `colors` map.
*   **Verification**: Automated tests verify that the literal hex strings used in CSS match those used by the dot-creation logic inside the HTML shell.

```javascript
// Generation logic ensuring SSOT for colors
const colorsJson = JSON.stringify(
  Object.fromEntries(
    Object.entries(ANIMATION_PROFILES).map(([k, v]) => [k, v.color])
  )
);

// Injected into JS as: const colors = ${colorsJson};
// Injected into CSS via: --edge-color: ${profile.color};
```

## 11. Dynamic Visual Synchronization (Runtime Inspection)
In complex rendering environments where external directives (like Mermaid's `linkStyle`) can override build-time semantic styles, the animator must perform **Runtime Visual Synchronization**.

*   **Rendered Color Extraction**: Instead of relying solely on the build-time semantic group color, the animation initialization script should inspect the `getComputedStyle(path).stroke` of the rendered SVG element.
*   **Visual Logic decoupling**: Build-time semantics provide the **intent** (e.g., "this is an observability edge"), but runtime inspection provides the **truth** (e.g., "it is currently blue").
*   **Fallthrough Safety**: If runtime inspection fails or returns invalid colors, fall back to the build-time semantic defaults.

```javascript
// Runtime inspection ensuring dot color matches rendered line color
function createTravelingDot(svg, path, anim, svgNS) {
  // Read the ACTUAL stroke color from the rendered path
  // This ensures dot always matches the line, regardless of Mermaid linkStyle
  const computedStyle = window.getComputedStyle(path);
  let color = computedStyle.stroke || '#9370DB';
  
  // Handle fallback or invalid stroke
  if (color === 'none' || color === '') {
    color = '#9370DB'; // Fallback to async purple or group default
  }
  
  const dot = document.createElementNS(svgNS, 'circle');
  dot.setAttribute('fill', color);
  // ... apply animations
}
```
## 12. Pattern Ordering & Regex Specificity
When parsing complex, multi-layered diagram syntax, regex pattern order and specificity are critical for non-fragile parsing.

*   **Prefix Collisions**: Longer/More specific patterns (e.g., dotted `-->>`) must be evaluated before shorter patterns (e.g., solid `->>`) to prevent greedy prefix matching.
*   **Anchored Captures**: Use explicit literals (e.g., escaping `[*]`) or word boundaries to prevent ambiguity between different node/state types.
*   **Greediness Control**: In diagrams with lazy-matching participant names, evaluate "labeled paths" before "anonymous paths" to ensure labels are correctly bound to their corresponding edges.

## 13. Router-Driven Generation
The CLI is decoupled from specific diagram types via a **Type-Detection Router**.

*   **Dynamic Dispatch**: The generator accepts code, detects the type, and dynamically dispatches the parse call, enabling support for 20+ chart types through a single entry point.
*   **Strategy Matching**: Each diagram type is mapped to a high-level **Animation Strategy** (e.g., `traveling-dot` for flow-based graphs, `sequential-pulse` for temporal diagrams).
*   **Semantic Consistency**: Despite different parsing paths, the final animation manifest remains stable, ensuring consistent behavior across the entire diagram library.
