# Process Governance and Engineering Reliability

This document outlines the procedural invariants for maintaining high-fidelity engineering standards and preventing "Diagnostic Capitulation" (taking shortcuts under pressure).

---

## 1. Implementation Plan Mandate

**Goal**: Prevent regressions caused by overlooked dependencies (e.g., port mappings, network pathing, or initialization sequence).

### The Standard
For any non-trivial change (e.g., re-enabling behavioral tiers, overhauling infrastructure, or adding new services), a formal **Implementation Plan** must be documented BEFORE execution.

**Plan Requirements**:
1.  **Dependency Audit**: Explicitly check if the change requires new ports, environment variables, or volume mounts in ALL environments (local, integration, production).
2.  **Verification Steps**: List the exact commands (curl, logs, test runs) that will prove the fix works at each stage.
3.  **Rollback Strategy**: Identifying what files were modified to allow quick reversion if the fix regresses other systems.

### 1.1 The Point of Confirmation

For high-sensitivity changes—especially those involving security (Auth), cross-platform orchestration, or core state machines—the Implementation Plan must reach a **Point of Confirmation** with the user or stakeholder before execution.
- **Rationale**: Prevents "Sloppy execution" where the Assistant might proceed with an incomplete understanding of environmental side-effects (e.g., how an empty string in a K8s secret propagates to a Rust Option).
- **Mandate**: Present the technical findings and the proposed diff. Do NOT apply changes to critical files until the plan is ratified.

### Failure Mode: The "Shortcut Trap"
Taking the "lazy path"—such as skipping failing tests or assuming a single regex fix is sufficient—leads to fragmented coverage and "invisible" infrastructure gaps (like unexposed ports).

---

## 2. Root Cause Discipline (No Diagnostic Capitulation)

**Goal**: Ensure that system behavior is understood, not just bypassed.

**The "Investigation vs. Capitulation" Framework**:

| Action | Diagnostic Capitulation (Shortcut) | Root Cause Discipline (Standard) |
| :--- | :--- | :--- |
| **Test Failure** | Skip the test using `test.skip()`. | Inspect logs, trace the network path, and verify port connectivity. |
| **Environment Issue**| Work around the issue in the code (e.g., mocking). | Fix the environmental root cause (e.g., `docker-compose` port mapping). |
| **Flakiness** | Increase timeouts or retry counts indefinitely. | Profile the bottleneck; resolve resource exhaustion (e.g., WebSocket cleanup). |

### Implementation Pattern: The Port-Mapping Probe
Whenever a test failures with `ECONNREFUSED` or a timeout during a `fetch()` call:
1.  **Validate Internally**: Exec into the container and `curl` the endpoint.
2.  **Validate Externally**: `curl` the endpoint from the host.
3.  **Seal the Gap**: If Internal succeeds but External fails, the issue is **Authoritative Port Exposure (Pattern 11)**. Fix the mapping in the orchestrator file.

---

## 3. The "Interactive Gap" Paradox

In high-fidelity mirrors (like web-based terminals), the "Interactive Gap" is the delay between infrastructure readiness and client-side availability.

- **shortcut**: Adding arbitrary `sleep` commands.
- **standard**: Implementing authoritative readiness probes (HTTP `/health`) and using UI-level waits (`waitForSelector`) that verify the *state* of the connection, not just the presence of the container. 
