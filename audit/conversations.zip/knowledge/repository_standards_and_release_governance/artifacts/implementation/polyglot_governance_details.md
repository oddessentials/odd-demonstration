# Polyglot Governance Implementation Details

This document captures reusable technical patterns for bringing diverse microservice stacks into compliance with Repository Standards.

---

## 1. Stack-Specific Implementation (Rust & Go)

The framework generates targeted standards for Rust and Go, covering:
- **Linting**: `clippy` (Rust), `golangci-lint` (Go).
- **Testing**: `cargo test` (Rust), `go test` (Go).
- **Formatters**: `rustfmt`, `gofmt`.
- **Dependency Scan**: `cargo-audit`, `govulncheck`.
- **Coverage**: `cargo-tarpaulin` / `llvm-cov`, `go tool cover`.

---

## 2. Hard-Fail Coverage Enforcement (Go)

The standard Go toolchain emits coverage profiles but doesn't natively support a "fail under" threshold like `pytest-cov`.

**CI Pattern (GitHub Actions):**
```bash
go test -coverprofile=coverage.out ./...
go tool cover -func=coverage.out | grep total | awk '{print $3}' | sed 's/%//' | xargs -I{} bash -c '
  if (( $(echo "{} < 60" | bc -l) )); then 
    echo "Coverage {}% is below threshold"; 
    exit 1; 
  fi'
```

---

## 3. ESM-to-TS Migration (Node.js)

Canonical patterns for migrating Node.js ESM services to strict TypeScript.

### ESM Compatibility
- **__dirname replacement**: `const __dirname = path.dirname(fileURLToPath(import.meta.url));`
- **Default Exports (Ajv Example)**: CommonJS-style defaults in ESM require explicit `.default` access: `new Ajv.default()`.

### TSConfig Standards
- **`moduleResolution`: NodeNext**: Essential for ESM module resolution.
- **Auto-Discovery**: Rely on auto-discovery from `node_modules/@types` instead of explicit `types: []` arrays.

---

## 4. Monorepo Dependency Management

Install commands must be scoped to prevent accidental root-level bloat or path conflicts.

- **Isolation**: Use `pnpm install --filter <service>` or `cd <service> && npm install --ignore-scripts`.
- **Lockfile Maintenance**: Use `pnpm install --lockfile-only` for metadata-only updates.

---

## 5. Contract-First Drift Prevention

For multi-stack systems sharing schemas, automated repository-level gates prevent runtime drift.

- **Schema Integrity**: Scripts verifying valid JSON and required metadata (`$id`, `$version`).
- **Dual-Fixture Validation**: Testing against both Golden (positive) and Negative (failure-mode) fixtures.
- **The Operational Proof**: Mandatory integration gates verifying Ingress (Gateway), Propagation (Broker), and Observability (Prometheus).

---

## 6. Schema Validation Framework (V3)

The framework (V3) uses a strict validation layer for `standards.json`:
- **Strict Property Control**: `additionalProperties: false` enabled.
- **Semantic Validation**: Dedicated validator (`validate-schema.ts`) for composite ID uniqueness and stack consistency.
- **Deep Determinism**: `fast-json-stable-stringify` ensures byte-for-byte identical output for CI reproducibility.
