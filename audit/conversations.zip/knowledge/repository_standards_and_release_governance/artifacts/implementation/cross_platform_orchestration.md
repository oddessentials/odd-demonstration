# Cross-Platform Orchestration Hardening

This document defines standardized patterns for ensuring that orchestration scripts (typically PowerShell/pwsh) and build tools (Docker/Bazel) operate deterministically across diverse host environments, foreign shell contexts, and complex monorepo structures.

## 1. Pattern: Hardened Root Resolution

**The Hazard**: PowerShell scripts that rely on `$PSScriptRoot` to resolve the **ProjectRoot** (e.g., `$ProjectRoot = Split-Path -Parent $PSScriptRoot`) fail when invoked by external processes (e.g., Rust `std::process::Command`, Python `subprocess`) using the `-Command` flag with the `&` operator. In this context, `$PSScriptRoot` is **empty** because the script is executed as a string command, not a discrete file.

**The Strategy**: Use a multi-tiered resolution protocol with marker-based discovery.

### Implementation Pattern (PowerShell)
```powershell
# Tier 1: Canonical script path
if ($MyInvocation.MyCommand.Path) {
    $script:ProjectRoot = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
} 
# Tier 2: Standard shell context
elseif ($PSScriptRoot) {
    $script:ProjectRoot = Split-Path -Parent $PSScriptRoot
} 
# Tier 3: Foreign shell fallback (marker-based discovery)
else {
    # CRITICAL: Get-Location returns a PathInfo object. 
    # Use .Path to ensure string operations (Split-Path) behave deterministically.
    $curr = (Get-Location).Path
    # Walk upward until a repository marker (e.g., 'infra/' or '.git') is found
    while ($curr -and -not (Test-Path (Join-Path $curr "infra"))) {
        $parent = Split-Path -Parent $curr
        if ($parent -eq $curr) { break }
        $curr = $parent
    }
    $script:ProjectRoot = $curr
}

# Fail-Fast: Fatal error if root resolution fails
if (-not $script:ProjectRoot -or -not (Test-Path (Join-Path $script:ProjectRoot "infra"))) {
    Write-Error "CRITICAL: Could not resolve ProjectRoot. marker 'infra/' not found."
    exit 1
}

### 1.1 Hazard: Windows Extended Path Prefix (\\?\)

**The Hazard**: Runtimes like Rust (`std::fs::canonicalize`) or specific terminal configurations may prefix paths with `\\?\` (the Windows extended path prefix) to bypass the 260-character MAX_PATH limit. While native Windows APIs handle this, many CLI tools and PowerShell cmdlets (e.g., `Split-Path`, `Join-Path`) can exhibit non-deterministic behavior or fail to correctly resolve parents when this prefix is present.

**The Strategy**: Strip the extended path prefix before performing path arithmetic or marker discovery.

**Implementation (PowerShell)**:
```powershell
# Robust path sanitization
$cleanPath = $rawPath -replace '^\\\\\?\\', ''
$parent = Split-Path -Parent $cleanPath
```
```

## 2. Pattern: Repo-Root Build Context Standards

**The Hazard**: In polyglot monorepos, services often share root-level assets (e.g., `contracts/`, `VERSION`, `shared_libs/`). If a Docker build context is restricted to the service subdirectory, these assets are inaccessible, resulting in `file not found` errors. Conversely, if the context is the repo root but the `Dockerfile` uses service-relative paths, the build fails.

**The Standard**:
1. **Authoritative Context**: Use the repository root (`.`) as the canonical build context for all images that consume shared monorepo resources.
2. **Repo-Relative COPY Paths**: All `COPY` instructions for service-local files MUST be prefixed with the service's repository path.

### Correct Implementation
```dockerfile
# Context: Repository Root (.)
# Service: src/services/gateway

# WRONG: Expects context to be src/services/gateway
COPY package.json ./

# CORRECT: Robust against repo-root context
COPY src/services/gateway/package.json ./
COPY contracts ./contracts
```

## 3. Pattern: Orchestration State Continuity (SkipBuild Hazard)

**The Hazard**: Orchestration scripts often resolve and cache metadata (like image versions from `VERSION` files) during a "Build" step. If a user provides a `-SkipBuild` flag, this resolution step is bypassed, leaving the internal state (e.g., `$script:ImageVersions`) unpopulated. This results in downstream steps (like "Loading" or "Deploying") defaulting to incorrect or stale tags (e.g., `:latest`).

**The Standard**:
1. **Idempotent Metadata Resolution**: Functions handling distribution (Loading/Deploying) MUST be capable of resolving required metadata independently if the global cache is empty.
2. **Elimination of "Soft" Fallbacks**: Prohibit silent fallbacks (like defaulting to `:latest` if a version is missing). Use the **Fail-Fast Policy**: if a required version cannot be resolved, terminate immediately with diagnostic output.
3. **Implicit Dependency Injection**: Prefer passing resolved metadata explicitly between orchestration steps rather than relying on shared global state variables that are bypassable via CLI flags.

## 4. Pattern: The "Foreign Host" Verification Policy

**The Goal**: Prevent "Ghost Successes" where a script works in a direct shell but fails when spawned by an application.

**The Protocol**:
1. **Simulated Invocation**: Verification must include running the script via the exact same command string used by the parent application (e.g., `pwsh -NoProfile -Command "& './script.ps1'"`).
2. **Stderr Transparency**: Ensure the parent application captures and surfaces `stderr` from the orchestration script. Silent failures in the background lead to "Diagnostic Capitulation."
3. **Invariant Alignment**: All orchestration fixes must be verified against the project's **Invariant Map** (e.g., `docs/INVARIANTS.md`) to ensure cross-platform parity (X1) and zero-touch automation (A2) are maintained.

## 5. Pattern: Authoritative Subprocess Identity (Diagnostic Proofing)

**The Hazard**: In "Self-Launching" applications where errors are summarized by a UI (like a TUI or Dashboard), developers often encounter "Ghost Failures"—cases where a fix is applied to a script on disk but the UI continues to report failure due to residual artifacts, terminal lag, or incorrect binary execution paths.

**The Strategy**: Perform a manual identity check by running the EXACT command used by the application in a standalone shell session.

**The Protocol**:
1. **Isolate the Command**: Extract the command string (e.g., `docker build -t ... -f ... .`) from the application logs or source code.
2. **Standardize Context**: Execute the command in the same directory (`current_dir`) as the application's subprocess handler.
3. **Audit the Proof**:
    - If the isolated command **fails**: The bug is systemic (code/metadata).
    - If the isolated command **succeeds**: The failure is an environmental artifact (stale binary, cached shell script, or parent-process redirection lag).
4. **Resolution**: If success is proven in isolation, perform an **Authoritative Rebuild** of the parent application or refresh the environment state before re-running.

## 6. Pattern: Structured Headless Diagnostics

**The Hazard**: In applications that capture JSON output from subprocesses (e.g., TUIs using `std::process::Command`), a script that crashes with standard `Write-Error` can break the UI's parser or provide opaque error messages ("Failed to parse JSON").

**The Strategy**: Implement structured diagnostic hooks for pre-flight failures.

### Implementation Pattern
```powershell
if ($FatalError) {
    if ($OutputJson) {
        $diag = @{
            step = "preflight"
            status = "error"
            message = "FATAL: $Message. CWD='$(Get-Location)' PSScriptRoot='$PSScriptRoot'"
        }
        Write-Output ($diag | ConvertTo-Json -Compress)
    }
    Write-Host "FATAL: $Message" -ForegroundColor Red
    exit 1
}
```

## 7. Pattern: Asynchronous Infrastructure Convergence (Polling/Retry)

**The Hazard**: Orchestration scripts often trigger asynchronous side effects (e.g., `kubectl port-forward`, Docker container startup, cloud resource provisioning). If a verification probe (Connectivity Test) is executed with a fixed, insufficient delay (e.g., `Start-Sleep -Seconds 2`), it may produce a false-negative failure, triggering misleading error reports in parent applications.

**The Strategy**: Implement a bounded retry loop (polling) that allows for non-deterministic convergence times.

### Implementation Pattern (PowerShell)
```powershell
function Test-ConnectivityWithRetry {
    param(
        [string]$Url,
        [int]$MaxRetries = 5,
        [int]$WaitSeconds = 3
    )
    
    for ($i = 1; $i -le $MaxRetries; $i++) {
        try {
            $response = Invoke-WebRequest -Uri $Url -TimeoutSec 5 -UseBasicParsing -ErrorAction Stop
            if ($response.StatusCode -eq 200) {
                return $true
            }
        } catch {
            Write-Warning "Attempt $i/$MaxRetries: $Url not reachable yet..."
        }
        Start-Sleep -Seconds $WaitSeconds
    }
    return $false
}
```

### THE "PARTIAL SUCCESS" PROTOCOL
1. **Differentiate Failures**: Distinguish between "Hard Failures" (e.g., pod failed to start, build error) and "Convergence Failures" (e.g., service not reachable yet due to async port-forward lag).
2. **Warn, Don't Fatal**: For convergence failures, emit a structured `warning` status rather than an `error` status.
3. **Status State-Machine Mapping**: In TUIs that use `status: "error"` as a trigger for `p.has_error = true`, using `warning` allows the UI to display the pending state without marking the entire operation as failed.
4. **Continuous Access**: Never skip the "Access Info" (success summary) if the primary infrastructure is deployed, but qualify it with the verification status to maintain diagnostic integrity.
## 8. Pattern: The Ephemeral Tunnel Hazard

**The Hazard**: In distributed systems where the client (e.g., a TUI or Web UI) interacts with backend services through local port-forwards (e.g., `kubectl port-forward`), the connectivity state is **decoupled** from the cluster state.
- **Symptom**: The cluster/pods are `Running` (Infrastructure Health), but the local tunnel is `Dead` (Connectivity Health).
- **Cause**: Port-forwards initiated via background shell jobs (e.g., `Start-Job` in PowerShell) are typically session-scoped and expire when the spawning terminal is closed or the parent process exits.
- **The Failure**: User actions (e.g., Task Submission) fail with deceptive "Timeout" errors because the application assumes a ready infrastructure implies a ready local environment.

**The Strategy**: Implement a **Multi-Tiered Readiness Probe** within the application's loading sequence.

### The Protocol (Tiered Verification)
Applications MUST verify all levels of the stack before enabling interactive features:
1. **Tier 1 (Infrastructure)**: Verify the cluster exists (`kind get clusters`, `kubectl get nodes`).
2. **Tier 2 (Service)**: Verify target pods are in a `Running` state and healthy.
3. **Tier 3 (Local)**: Perform a direct health check on the local port (e.g., `reqwest::get("http://localhost:3000/healthz")`).

**Auto-Recovery Standard**: If Tiers 1 & 2 are satisfied but Tier 3 fails, the application SHOULD attempt to re-establish the port-forwards automatically once before reporting a fatal connectivity error.

## 9. Pattern: Windows Subprocess Job Scoping (Lifetime Hazard)

**The Hazard**: On Windows, PowerShell background jobs (`Start-Job`) are scoped to the **hosting PowerShell session**. If an application spawns a PowerShell process to execute a `Start-Job` command and then that PowerShell process exits, the job is terminated immediately.
- **Symptom**: Port-forwards or background services started via `Start-Job` from a parent application (e.g., Rust `std::process::Command`) appear to fail or "ghost" because their hosting container dies before they can establish connectivity.
- **The Failure**: The application's health check times out because the background process never actually ran to completion or stabilized.

**The Strategy**: Use truly detached processes for background tasks on Windows.

### Implementation Pattern (PowerShell)

**WRONG (Session-Scoped)**:
```powershell
# Dies as soon as the spawning pwsh/powershell.exe process exits
Start-Job -ScriptBlock { kubectl port-forward svc/gateway 3000:3000 }
```

**RIGHT (Detached)**:
```powershell
# Uses Start-Process to spawn a detached kubectl.exe process
# -WindowStyle Hidden ensures no flashing terminal windows for the user
Start-Process -WindowStyle Hidden -FilePath "kubectl" -ArgumentList "port-forward", "svc/gateway", "3000:3000"
```

**Verification**: Always verify background process persistence by checking the process list (`Get-Process kubectl`) after the spawning application has transitioned past the launch step.
## 10. Pattern: PID-Scoped Resource Lifecycle Management (Ghost Port Prevention)

**The Hazard**: Detached background processes (refer to **Pattern 9**) are robust because they persist independently of the spawning parent. However, this independence becomes a liability during application shutdown or restart ("The Ghost Port Conflict").
- **The Symptom**: Deleting a cluster or stopping a main application leaves the background processes (e.g., `kubectl port-forward`) running on the host. 
- **The Failure**: Subsequent attempts to launch the application fail because local ports (3000, 8080) are still bound by the "zombie" processes from the previous session.
- **The Collateral Damage**: Using broad cleanup commands like `pkill kubectl` or `Stop-Process -Name kubectl` can accidentally terminate unrelated work the developer is doing in other clusters.

**The Strategy**: Implement **PID-Scoped Cleanup**. The application must capture the unique Process IDs (PIDs) of background tunnels it spawns and target ONLY those PIDs for termination during shutdown.

### Implementation Pattern

#### 1. PID Capture (Windows PowerShell)
Use `Start-Process -PassThru` to obtain a process object, then extract the ID. To return it to a parent application (e.g., Rust), write it to standard output.
```powershell
# Script to be invoked via Command::new("powershell.exe")
$proc = Start-Process -WindowStyle Hidden -PassThru -FilePath "kubectl" `
    -ArgumentList "port-forward", "svc/gateway", "3000:3000"
Write-Output $proc.Id
```

#### 2. PID Capture (UNIX)
Child process PIDs are natively provided by the OS after `fork`/`exec`.
```rust
// Rust implementation example
let child = Command::new("kubectl")
    .args(["port-forward", "svc/gateway", "3000:3000"])
    .spawn()?;
let pid = child.id();
```

#### 3. Scoped Termination (Deterministic Cleanup)
Store PIDs in a registry (e.g., `Vec<u32>`). On shutdown, iterate and kill specifically by ID.

**Windows**:
```powershell
Stop-Process -Id $trackedPid -Force -ErrorAction SilentlyContinue
```

**UNIX**:
```bash
kill -TERM $trackedPid
```

**Standard**: Applications MUST implement a "Safe Shutdown" orchestrator that clears the PID registry before final exit to prevent environment pollution.
