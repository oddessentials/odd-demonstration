# Bazel Implementation Conventions

This document defines the canonical target names and CI portability standards for repositories integrated with the `@oddessentials/repo-standards` framework.

## 1. Action to Command Templates

Avoid assuming specific target labels. Generated pipelines use the following command templates by default, which can be modified via `bazelHints`. 

**All `bazelHints` are ADVISORY**. Stack-native commands remain the default execution paths. These patterns are **illustrative** and actual targets are repo-defined.

> “bazelHints are suggestions only; stack-native commands remain the default.”

| Action | Recommended Pattern | Template Example |
|--------|---------------------|------------------|
| Build  | Root wildcard       | `bazel build //...` |
| Test   | Root wildcard       | `bazel test //...` |
| Lint   | Config or Script    | `bazel test //...:lint` or `bazel run //tools/lint`|
| Format | Check target        | `bazel test //...:format_check` or `bazel run //tools/format:check`|
| Type   | Build-integrated    | `bazel build //...` (captures compilation errors) |
| Coverage | Coverage runner   | `bazel coverage //...` |

## 2. CI Portability Contract

To ensure deterministic and reliable builds across different CI environments (GHA, Azure DevOps, local), the following flags and practices are required.

### Determination Flags
- `--config=ci`: Centralize CI-specific flags (cache settings, resource limits) in `.bazelrc`.
- `--remote_cache`: Highly recommended for shared build speed.
- `--build_tests_only`: Useful for validating code without running expensive tests.

### Handling Empty Test Sets (Exit Code 4)
Bazel exits with code 4 when a test pattern matches no targets (e.g., when all tests are filtered out).
- **CI Configuration**: Ensure pipelines handle exit code 4 as non-failing.
  ```bash
  bazel test //... --config=ci || [ $? -eq 4 ]
  ```

### Azure DevOps (AzDO) Performance
AzDO agents require explicit Bazelisk installation and caching for performance.
- **Install**: Use `bazelisk` to manage versions via `.bazelversion`.
- **Caching**: Cache the `testlogs` and the `~/.cache/bazel` directory if using self-hosted agents. For Microsoft-hosted agents, focus on remote caching (`--remote_cache`).
- **Snippet**:
  ```yaml
  - script: |
      sudo apt-get install -y bazelisk
      bazel test //... --config=ci
    displayName: 'Bazel Test (CI)'
  ```

### Line Ending Normalization (Cross-Platform)
Windows (CRLF) vs. Linux (LF) line ending differences can cause `MODULE.bazel.lock` hash mismatches.
- **Requirement**: Use `.gitattributes` to enforce `eol=lf` for all Bazel files.
  ```text
  MODULE.bazel text eol=lf
  MODULE.bazel.lock text eol=lf
  BUILD.bazel text eol=lf
  *.bzl text eol=lf
  ```

## 3. Hermetic Toolchains

All repositories MUST use pinned toolchain versions in `MODULE.bazel` to prevent "works on my machine" issues.
- **Go**: Pin specific SDK version (e.g., `1.22.x`).
- **Python**: Pin `python_version` and use a locked `requirements_lock.txt`.
- **Rust**: Use `rust-toolchain.toml` to pin the channel and version.

## 4. Finalized Type Definitions

The framework uses the following TypeScript interfaces (in `src/types.ts`) to model Bazel integration:

```typescript
/**
 * Bazel execution hints for individual checklist items.
 * Commands are actual Bazel invocations (e.g., "bazel test //..."),
 * NOT assumed pattern labels.
 */
export interface BazelHints {
  /** Bazel commands to run (e.g., "bazel test //...", "bazel run //tools/lint") - MUST use commands, not assumed targets */
  commands: string[];
  /** Recommended target conventions (documentation only, not assumed to exist) */
  recommendedTargets?: string[];
  /** Usage notes for this check in Bazel context - MANDATORY */
  notes: string;
}

// Global meta field for advisory notice
// meta.executorHints.bazel.advisoryNotice: "bazelHints are suggestions only; stack-native commands remain the default."

// Extend existing StackHints
export interface StackHints {
  // ... existing fields ...
  bazelHints?: BazelHints;
}
```

## 5. Root-Level Detection & Opt-Out

To prevent false positives from vendored deps or subtrees, detection is pinned to the repository root.

### Detection Rules
Repos are detected as Bazel-managed if the root contains:
1. `MODULE.bazel` (bzlmod, preferred)
2. `WORKSPACE.bazel` or `WORKSPACE` (legacy)
3. Optional markers: `.bazelrc`, `.bazelversion`

### Opt-Out Mechanism
If a repository contains Bazel files but should not use Bazel as the build executor for quality checks, teams can explicitly opt-out in their local configuration:

```json
{
  "meta": {
    "executorHints": {
      "bazel": {
        "enabled": false
      }
    }
  }
}
```

## 6. Hybrid Execution & Environment
For repositories in transition, the framework follows an "executor precedence" rule:
1. **Bazel Detected**: If root markers (`MODULE.bazel`, etc.) exist AND the checklist item has `bazelHints`, use Bazel commands.
2. **Fallback**: If not detected or hints are missing, fall back to native runners (e.g., `npm run lint`).
3. **Derived Property**: Precedence is computed during generation; it is not a required manual config.

### Build Process Independence
The generation of standards artifacts (`standards.*.json`) **must not** depend on having Bazel installed on the builder machine. The generator only emits hints and metadata; it does not execute Bazel.

## 7. Canonical Hint Patterns

The following patterns are recommended for `bazelHints.commands` to ensure robust CI across different language stacks. 

**Advisory Note**: These commands are illustrative templates. They are not guaranteed to work unless the repository has been explicitly configured with the corresponding Bazel rules and targets.

### Linting Patterns

| Stack | Recommended Bazel Command |
|-------|--------------------------|
| **TypeScript / JS** | `bazel test //... --aspects=//tools:lint.bzl%eslint_aspect --output_groups=report` |
| **C# / .NET** | `bazel build //... --aspects=@rules_dotnet//dotnet:analyzers.bzl%analyzer_aspect` |
| **Python** | `bazel test //...:ruff_test` or `bazel run //tools/lint:ruff -- check .` |
| **Rust** | `bazel build //... --aspects=@rules_rust//rust:defs.bzl%clippy_aspect --output_groups=clippy_checks` |
| **Go** | `bazel test //... --@io_bazel_rules_go//go/config:nogo=@//:nogo` |

### Unit Testing Patterns

| Stack | Recommended Bazel Command |
|-------|--------------------------|
| **TypeScript / JS** | `bazel test //...` (discovers all `ts_test`, `jest_test` targets) |
| **C# / .NET** | `bazel test //...` (discovers all `dotnet_test` targets) |
| **Python** | `bazel test //...` (discovers all `py_test` targets) |
| **Rust** | `bazel test //...` (discovers all `rust_test` targets) |
| **Go** | `bazel test //...` (discovers all `go_test` targets) |

### Code Formatting Patterns

| Stack | Recommended Bazel Command |
|-------|--------------------------|
| **TypeScript / JS** | `bazel run //tools/format:check` or `bazel test //...:format_test` |
| **C# / .NET** | `bazel run //tools/format:dotnet_format -- --verify-no-changes` |
| **Python** | `bazel run //tools/format:black -- --check .` |
| **Rust** | `bazel build //... --aspects=@rules_rust//rust:defs.bzl%rustfmt_aspect --output_groups=rustfmt_checks` |
| **Go** | `bazel run @go_sdk//:bin/gofmt -- -d .` |

### Coverage Reporting Patterns

| Stack | Recommended Bazel Command |
|-------|--------------------------|
| **All Stacks** | `bazel coverage //...` |

**Aggregated Reports**: Use `--combined_report=lcov` to generate a single coverage report across all targets.

### Type Checking Patterns

| Stack | Recommended Bazel Command |
|-------|--------------------------|
| **TypeScript / JS** | `bazel build //...` (errors surface during compilation with rules_ts) |
| **C# / .NET** | `bazel build //...` (errors surface during compilation with rules_dotnet) |
| **Python** | `bazel test //...:mypy_test` or `bazel run //tools/typecheck:mypy` |
| **Rust** | `bazel build //...` (type safety is inherent to compilation) |
| **Go** | `bazel build //...` (type safety is inherent to compilation) |

### Quality Gate Patterns (Consolidated CI)

| Stack | Recommended Bazel Command |
|-------|--------------------------|
| **All Stacks** | `bazel build //...` AND `bazel test //...` |

**Consolidation**: For the `ci-quality-gates` item, the framework recommends running both a full build and a full test suite. Bazel's internal dependency graph ensures that work is not duplicated if both commands are run in sequence (or if `bazel test` triggers the builds).


### General Execution Guidance
- **Aspects**: Prefer aspects for linting as they can be applied to all targets in the dependency graph without modifying individual `BUILD` files.
- **Test vs Build**: Use `bazel test` for checks that produce pass/fail results (lint, tests). Use `bazel build` for checks that surface errors during compilation (type checking).
- **Output Groups**: Use `--output_groups` to isolate check reports or specific compilation artifacts.

## 8. Root-Level Detection Contract

The framework identifies Bazel-managed repositories using a deterministic, root-level detection strategy prioritizing stability and preventing false positives.

### Detection Strategy
To prevent false positives from vendored dependencies or nested subprojects, the detector focuses exclusively on the **repository root**.

- **Primary (bzlmod)**: `MODULE.bazel` (preferred)
- **Primary (Legacy)**: `WORKSPACE.bazel` or `WORKSPACE`
- **Optional**: `.bazelrc`, `.bazelversion`

### Implementation Details
The `detectBazel(repoRoot: string)` function scans the provided root and returns a `BazelDetectionResult` object containing the detected mode (`bzlmod` or `workspace`) and all found markers.

### Test Fixtures for Detection
- **`hybrid-monorepo`**: Root-level `MODULE.bazel` with nested `BUILD.bazel` files. Verifies that nested files do not trigger root detection incorrectly.
- **`nested-build-only`**: Contains `src/BUILD.bazel` but NO root markers. Verifies the "repo-root markers only" contract (returns `detected: false`).

## 9. Deterministic Bazel CI Availability (High-Fidelity Mirroring)

To prevent CI failures caused by external network issues (e.g., TLS certificate expiry on `releases.bazel.build`), repositories MUST implement deterministic Bazel availability by hosting mirrored toolchains on controlled infrastructure.

### The Mirroring Pattern

Relying on GitHub Actions caches is insufficient for high-integrity pipelines because the first "warm-up" run still depends on external availability.

**The Solution**: Host the Bazel binary as a GitHub Release asset within the organization and force Bazelisk to download from this mirror.

#### Pre-setup Asset Validation

To prevent noisy tooling failures when the infrastructure mirror hasn't been provisioned, CI MUST perform a lightweight preflight check to verify the existence of the GitHub Release asset before invoking Bazelisk.

```yaml
- name: Verify Bazel mirror asset exists
  run: |
    BAZEL_VERSION=$(cat .bazelversion | tr -d '[:space:]')
    ASSET_URL="https://github.com/oddessentials/odd-demonstration/releases/download/bazel-binaries-v1/bazel-${BAZEL_VERSION}-linux-x86_64"
    echo "Checking asset: $ASSET_URL"
    
    HTTP_CODE=$(curl -sL -o /dev/null -w "%{http_code}" --head "$ASSET_URL" || echo "000")
    
    if [ "$HTTP_CODE" != "200" ] && [ "$HTTP_CODE" != "302" ]; then
      echo "::error::PREREQUISITE MISSING: Bazel mirror asset not found (HTTP $HTTP_CODE)"
      exit 1
    fi
    echo "✓ Mirror asset verified (HTTP $HTTP_CODE)"
```

#### 1. Configure internal mirror

Standard Bazel mirrors (like Artifactory) often follow the official structure, but **GitHub Releases** use flat asset paths. To support this, use `BAZELISK_FORMAT_URL` for full control over the destination URL.

```yaml
- name: Set up Bazelisk
  uses: bazel-contrib/setup-bazel@0.9.0
  env:
    # Forces Bazelisk to download from repo-controlled GitHub Release
    # FORMAT_URL bypasses the default /{VERSION}/{FILENAME} append logic
    # Pattern: bazel-%v-%o-%m (version, os, machine)
    BAZELISK_FORMAT_URL: https://github.com/oddessentials/odd-demonstration/releases/download/bazel-binaries-v1/bazel-%v-%o-%m
  with:
    bazelisk-cache: true  # Correct input for bazel-contrib/setup-bazel
    disk-cache: ${{ github.workflow }}
    repository-cache: true
```

#### 2. Deterministic SHA256 Verification

Integrity MUST be verified against an in-repo source of truth (`tools/bazel/SHA256SUMS`) which MUST contain official checksums from the upstream provider (e.g., Bazel's GitHub releases) to ensure end-to-end provenance. The check MUST resolve the *actual downloaded binary* within the Bazelisk cache (not the launcher).

```yaml
- name: Verify Bazel binary integrity (SHA256)
  run: |
    # Read version from .bazelversion
    BAZEL_VERSION=$(cat .bazelversion | tr -d '[:space:]')
    BINARY_NAME="bazel-${BAZEL_VERSION}-linux-x86_64"
    echo "Looking for: $BINARY_NAME"
    
    # Locate the actual downloaded binary in Bazelisk cache
    # Use size filtering (>1MB) to skip wrapper scripts or partial downloads
    BAZEL_BINARY=$(find ~/.cache/bazelisk ~/.bazelisk -type f \( -name "$BINARY_NAME" -o -name "bazel-$BAZEL_VERSION*" \) 2>/dev/null | while read f; do
      if [ $(stat -c%s "$f" 2>/dev/null || echo 0) -gt 1000000 ]; then
        echo "$f"
        break
      fi
    done)
    
    if [ -z "$BAZEL_BINARY" ] || [ ! -f "$BAZEL_BINARY" ]; then
      echo "::error::Cannot locate Bazel $BAZEL_VERSION binary in Bazelisk cache"
      echo "Diagnostic: cache contents follow..."
      find ~/.cache/bazelisk ~/.bazelisk -type f 2>/dev/null | head -n 20
      exit 1
    fi
    echo "Found binary: $BAZEL_BINARY ($(stat -c%s "$BAZEL_BINARY") bytes)"
    
    # Extract expected SHA (ignore comments, match exact filename)
    EXPECTED_SHA=$(grep -v '^#' tools/bazel/SHA256SUMS | grep "$BINARY_NAME" | awk '{print $1}')
    
    if [ -z "$EXPECTED_SHA" ]; then
      echo "::error::No checksum found for $BINARY_NAME in tools/bazel/SHA256SUMS"
      exit 1
    fi
    
    ACTUAL_SHA=$(sha256sum "$BAZEL_BINARY" | awk '{print $1}')
    echo "Expected: $EXPECTED_SHA"
    echo "Actual:   $ACTUAL_SHA"
    
    if [ "$EXPECTED_SHA" != "$ACTUAL_SHA" ]; then
      echo "::error::Bazel binary checksum MISMATCH - integrity violation"
      exit 1
    fi
    echo "✓ Bazel binary integrity verified"
```

#### 3. Network-Based Mirror Enforcement

Pipelines MUST fail if any resolution fallback to `releases.bazel.build` occurs. This is verified by capturing Bazelisk debug output and inspecting the download URLs.

```yaml
- name: Resolve Bazel binary (preflight)
  run: |
    # Enable debug to capture download URLs
    export BAZELISK_DEBUG=1
    bazel version 2>&1 | tee bazelisk_debug.log || true
    echo "✓ Bazel resolution check complete"

- name: Enforce mirror-only (no releases.bazel.build)
  run: |
    # Fail if the external domain is found in any download metadata
    if grep -q "releases.bazel.build" bazelisk_debug.log 2>/dev/null; then
      echo "::error::EXTERNAL FALLBACK DETECTED - releases.bazel.build was used"
      cat bazelisk_debug.log
      exit 1
    fi
    
    # Verify our GitHub mirror was used (if any download occurred)
    if grep -q "Downloading" bazelisk_debug.log 2>/dev/null; then
      if ! grep -q "github.com/oddessentials" bazelisk_debug.log; then
        echo "::error::Download occurred but not from unauthorized domain"
        cat bazelisk_debug.log
        exit 1
      fi
      echo "✓ Download verified from GitHub mirror"
    else
      echo "✓ No download needed (cache hit)"
    fi
```

### Implementation Hazards

When implementing this mirroring pattern, avoid these common failure modes:

*   **Launcher Resolution vs. Binary Hashing**: Do not attempt to hash the result of `which bazel` or `readlink -f`. In environments where Bazelisk is installed via `npm`, these paths resolve to the Bazelisk launcher (`bazelisk.js`), not the Bazel binary.
*   **BAZELISK_BASE_URL vs. Flat Release Paths**: `BAZELISK_BASE_URL` appends `/{VERSION}/{FILENAME}` to the base URL. GitHub Releases use flat asset paths (e.g., `.../releases/download/v1/bazel-7.1.0-linux-x86_64`), leading to 404 errors. Use `BAZELISK_FORMAT_URL` with a pattern like `bazel-%v-%o-%m` to handle flat paths.
*   **Invalid Action Inputs**: Some versions of `bazel-contrib/setup-bazel` (e.g., v0.9.0) may flag `use-bazelisk` as an invalid input. This action detects Bazelisk automatically from `.bazelversion`. Providing invalid inputs can cause IDE/Schema warnings or CI failures. **Remediation**: Use `bazelisk-cache: true` for caching downloads.
*   **Missing Pre-flight Command**: The Bazelisk cache is only populated when a Bazel command is executed. You MUST run `bazel version` or similar *before* attempting SHA verification.
*   **Provisioning vs. Tooling Errors**: Without a pre-setup asset check, a missing GitHub Release asset surfaces as a cryptic "404 Not Found" inside the `setup-bazel` action. Always use an explicit `curl --head` check to surface the missing prerequisite clearly.
*   **Brittle Path Searching**: Do not use generic `find` commands that might pick up partial downloads or stale binaries. Always match the exact expected filename (e.g., `bazel-7.1.0-linux-x86_64`) and verify file size (>1MB).

### Mandates for High-Integrity CI

1.  **Repository-Controlled Binaries**: Mirror binaries for all supported OS/arch combinations (Linux, macOS, Windows) to the internal release.
2.  **OS Scoping**: If a mirror does not yet cover all platforms, the respective CI jobs MUST be explicitly restricted (e.g., `runs-on: ubuntu-latest`) until mirror coverage is complete.
3.  **No Silent Fallback**: Any network activity toward `releases.bazel.build` during toolchain resolution MUST trigger a hard CI failure, verified via `BAZELISK_DEBUG` logs.
4.  **Deterministic Resolution**: Checksums MUST be computed on the actual downloaded binary residing in the Bazelisk cache (found by exact filename match), rather than on the launcher or symlink chains which may point to Bazelisk itself.
5.  **Prerequisite Gating**: Toolchain resolution MUST be preceded by an explicit asset-existence check (e.g., `curl --head`) to distinguish between provisioning failures and toolchain bugs.
6.  **Preflight Validation**: Run `bazel version` and integrity checks immediately after setup to fail fast on infrastructure drift.

## 10. Bazel Central Registry (BCR) Availability

In addition to the Bazel binary, modern Bazel projects (Bzlmod) depend on the **Bazel Central Registry (BCR)** at `https://bcr.bazel.build/` for module metadata. This represents a secondary major point of network failure in high-integrity pipelines.

### BCR Availability Mitigation

To ensure pipelines do not fail due to BCR outages, TLS-intercepting proxies, or certificate validation errors (`CertPathValidatorException`):

#### 1. Deterministic Lockfiles
All repositories MUST commit a complete `MODULE.bazel.lock` file. Set `common --lockfile_mode=error` in `.bazelrc` to ensure the build fails if the lockfile is out of sync, preventing silent dependency drift.

#### 2. Lockfile-Unchanged Verification (Scalable Fix)
The most durable and low-maintenance way to verify dependency integrity in CI without hitting `bcr.bazel.build` is to verify that the lockfile remains in the intended state via a direct file check.

**Strategy**:
1.  Enforce `--lockfile_mode=error` globally via `.bazelrc`.
2.  In CI, replace `bazel mod deps` (which may consult registries) with `git diff --exit-code MODULE.bazel.lock`.
3.  This ensures the quality invariant ("lockfile matches repo state") is satisfied without triggering registry connectivity.
4.  If the check fails, developers must run `bazel mod deps --lockfile_mode=update` locally in a trusted environment and commit the result.

**CAVEAT: Registry Patch Files**: 
Even with a verified lockfile, `bazel build` or `bazel test` may still attempt to download **patch files** (e.g., `.patch`) from the BCR if they are specified in a module's `source.json` (as seen in `bazel_features`). These patches are not typically cached in the lockfile structure. If these downloads fail due to TLS issues, the build will stall during "Computing main repo mapping".

#### 3. Local BCR Mirroring (Hermetic Fix)
For absolute air-gapped hermeticity or high-security environments, repositories can maintain a repo-local or organization-level registry mirror.

**Implementation**:
1.  **Registry Structure**: Create a minimal structure (e.g., `//tools/bcr`) containing `bazel_registry.json`, `modules/`, and `source.json` for every dependency.
2.  **Automation**: Use scripts (e.g., Python) to sync the mirror metadata with the `MODULE.bazel.lock`.
3.  **Config**: Point to the local registry via `common:ci --registry=file://%workspace%/tools/bcr`.

*Note: This approach has high maintenance overhead for large dependency graphs and is typically reserved for environments where Lockfile-Unchanged verification is insufficient.*

#### 4. GitHub Raw Mirror (Interim Workaround)
Bypass primary domain (`bcr.bazel.build`) issues by pointing to the official BCR GitHub mirror's raw content:
`common:ci --registry=https://raw.githubusercontent.com/bazelbuild/bazel-central-registry/main/`.
*Note: This still involves an external network dependency (GitHub CDN) and is not a 100% hermetic solution.*

#### 5. Vendoring All Dependencies (Absolute Hermeticity)
For absolute air-gapped or network-independent builds (including patches), use Bazel's vendor mode. This creates a local copy of ALL external dependencies, including patches and registry metadata, within the repository itself.

**Implementation**:
1. Run `bazel vendor --vendor_dir=vendor` locally with network access.
2. Commit the `vendor/` directory to source control (Note: This can be a large commit).
3. Configure `.bazelrc` to use the vendor directory for all builds:
   ```bash
   common --vendor_dir=vendor
   ```

### Registry-Specific Mandates

7.  **Lockfile Fidelity**: `MODULE.bazel.lock` MUST be committed to version control and enforced in CI via `--lockfile_mode=error`.
8.  **Verification Isolation**: Registry-dependent gates like `bazel mod deps` SHOULD be replaced in CI with registry-independent checks (`git diff`) to decoupling quality gates from domain availability.
9.  **Clear Failure Attribution**: Audit CI logs for `bcr.bazel.build` or `raw.githubusercontent.com`. Production-grade pipelines MUST implement a hard guard (e.g., `grep`) that fails the build if external registries are consulted during a build intended to be hermetic.
