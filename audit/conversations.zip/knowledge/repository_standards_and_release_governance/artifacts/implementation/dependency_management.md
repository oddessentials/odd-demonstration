# Dependency Management Standards

The Repository Standards Framework includes a comprehensive strategy for automated dependency management and governance across all supported stacks. This ensures repositories stay secure and up-to-date while minimizing manual maintenance overhead.

## Schema Version 2

The framework moved from a major architectural block to an additive schema increment (Version 2). This version introduces:

- **`anyOfFiles`**: Metadata for downstream consumers to evaluate either-or compliance (e.g., Renovate OR Dependabot satisfies the requirement).
- **`pinningNotes`**: Human-readable guidance for locking tool versions in CI to ensure deterministic builds.
- **`recommended` Checklist Items**: New items for update automation (`dependency-update-automation`) and architecture rules (`dependency-architecture-rules`), ensuring backward compatibility for existing core compliance.

### Governance vs. Security Controls

The framework distinguishes between **Vulnerability Scanning** (Supply Chain Security) and **Architecture Boundary Checks** (Architecture Rules).

| Stack | Update Automation | Security (Vuln Scan) | Architecture (Rules) |
| :--- | :--- | :--- | :--- |
| **JS/TS** | Renovate / Dependabot | `npm audit`, `Snyk` | `dependency-cruiser` |
| **Python** | Renovate / Dependabot | `pip-audit`, `safety` | `import-linter` |
| **.NET** | Renovate / Dependabot | `dotnet list package --vulnerable` | `NsDepCop`, `ArchUnitNET` |
| **Rust** | Renovate / Dependabot | `cargo-audit` | `cargo-deny check bans` |
| **Go** | Renovate / Dependabot | `govulncheck` | `depaware`, internal pkgs |

## CI System Implementation

### GitHub Actions (GHA)
- **Native**: Dependabot via `.github/dependabot.yml`.
- **Flexible**: Renovate via `renovate.json` or GHA self-hosted runner.
- **Workflow Phase**: Quality or Security jobs.

### Azure DevOps (AzDO)
- **Primary**: Renovate (provider-agnostic).
- **Execution Model**: Standardize on **scheduled pipeline jobs** or **container-based jobs** running the Renovate CLI.
- **Permissions Required**: Personal Access Token (PAT) with `Code (Read & Write)` and `Pull Requests (Read & Write)` scopes.
- **Strategy**: Use Renovate to maintain parity with GitHub-native workflows.

## Governance Rules

1. **Security Scanning (Core)**: Mandatory for all repositories. Fail CI on new high-severity issues.
2. **Automated Updates (Recommended)**: Encouraged for all repositories but treated as "recommended" to avoid forcing onboarding/token management immediately.
3. **Required Files OR Logic**: Compliance is satisfied by the presence of **either** `renovate.json` (or variants) **OR** `.github/dependabot.yml`. This is captured in the schema via the `anyOfFiles` metadata field.
4. **Enforcement Scope**: The framework is a **policy catalog**, not an enforcement engine. Fields like `anyOfFiles` and `pinnedVersions` are provided as metadata for downstream compliance-checking tools (e.g., Odd Hive Mind).
5. **Tool Integrity & Pinning**: Commands like `dotnet list package --vulnerable` and `go mod tidy` are **examples**. Determinism should be achieved via pinned tooling containers or stable versions, documented in the `pinningNotes` field.
6. **Lockfile Policy**: Mandatory for reproducible builds. Definition per stack:
   - **JS/TS**: `package-lock.json`, `pnpm-lock.yaml`, or `yarn.lock`.
   - **Python**: `poetry.lock`, `Pipfile.lock`, or `requirements.txt` (pinned).
   - **Rust**: `Cargo.lock`.
   - **Go**: `go.sum`.
   - **.NET**: `packages.lock.json` or Central Package Management files.
7. **Architecture Rules**: Use tools like `dependency-cruiser` (JS/TS) or `import-linter` (Python) to enforce module boundaries. For Python, architecture rules require verification of either `.importlinter` or `pyproject.toml` with `[tool.importlinter]` section.
8. **Strict Version Pinning for API Stability**: In environments where automated release tools (e.g., `semantic-release`) run manifest updates (like `cargo update --workspace` or `npm install`), loose versioning (e.g., `version = "0.24"`) can pull in incompatible minor/patch versions that break the build if the upstream API changes unexpectedly.
   - **Pattern**: Use strict equality pins (e.g., `ratatui = "=0.24.0"`) for critical TUI or infrastructure libraries to prevent "Release-time Drift" when the lockfile is effectively bypassed by an automated update command.
9. **Automation-induced Lockfile Mutation (Hazard)**: Automation scripts often include commands intended to "refresh" or "sync" manifests (e.g., `cargo update`, `npm update`, `go mod tidy`). These commands are **destructive to lockfile stability** because they run *after* the PR has been merged and the stability has been verified. 
   - **Risk**: A release-time `cargo update` might pull in a breaking dependency that was never tested in CI, causing the release build to fail or, worse, producing a broken binary.
   - **Mitigation**: Prefer targeted updates (e.g., `cargo update -p some-package`) or ensure that release scripts use `--locked` / `--frozen` versions of commands. For purely updating the package version in Rust manifests, use `cargo generate-lockfile` instead of `cargo update --workspace` to prevent unintentional dependency version drift.

## Implementation Verification

The implementation was verified through:
- **Automated Tests**: 8 tests in `src/index.test.ts` covering schema versioning, item presence, `anyOfFiles` logic, and item scope isolation.
- **Build Pipeline**: Successful generation of 16 stack and CI-specific JSON artifacts in `dist/config/`.
- **Formatting**: Full compliance with Prettier formatting across all config and spec files.
- **Manual Inspection**: Confirmed `standards.typescript-js.json` and other generated files correctly include Version 2 metadata.
