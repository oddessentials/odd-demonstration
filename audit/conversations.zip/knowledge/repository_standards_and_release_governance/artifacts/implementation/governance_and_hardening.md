# Governance and Schema Hardening (High-Integrity Spec)

This document outlines the solidified governance policies and schema hardening constraints for the Repository Standards Framework (`repo-standards`). These rules ensure that generated artifacts are deterministic, validated, and maintainable across polyglot stacks.

## 1. Unit Testing and Coverage Policy

*   **Coverage Threshold Unit**: The `meta.defaultCoverageThreshold` field is strictly defined as a **ratio (0.8 = 80%)**, not a percentage.
*   **Validation**: Schema validation enforces that this value is a number between `0` and `1`.
*   **Documentation**: All generated metadata must explicitly note the "ratio" status to avoid consumer ambiguity.

## 2. File Presence Semantics

To drive automated verification, the `stackHints` object uses three distinct keys with deterministic semantics:

*   **`requiredFiles`**: (Array of strings) **All** listed files must exist for the checklist item to be considered passing.
*   **`anyOfFiles`**: (Array of strings) **At least one** of the listed files must exist. Used for linters or test configs that support multiple naming conventions (e.g., `.eslintrc.js` OR `eslint.config.js`).
*   **`optionalFiles`**: (Array of strings) Purely informational; presence is noted but not required for validation.

## 3. Rust Cargo.lock Policy

To resolve the mismatch between library and application requirements:
*   **Libraries**: `Cargo.lock` is typically excluded from version control or treated as optional.
*   **Binaries/Services**: `Cargo.lock` is **required** for deterministic builds.
*   **Enforcement**: The framework handles this via `anyOfFiles` or stack-specific profiles (`rust-library` vs `rust-app`) if high granularity is needed. By default, it is treated as optional/informational for general "Rust" stack hints unless the repo is identified as a service.

## 4. Bazel Detection Contract

*   **Scope**: Detection is limited to **repo-root markers only**.
*   **Trigger Markers**: `WORKSPACE`, `WORKSPACE.bazel`, or `MODULE.bazel` at the repository root.
*   **Exclusions**: Repositories containing only nested `BUILD` or `BUILD.bazel` files (without root markers) will **not** enable Bazel hints. This prevents accidental activation in monorepos where only specific packages use Bazel.

### 5.1 Strictness vs Compatibility
*   **Gated Rollout**: The introduction of `additionalProperties: false` is treated as an intentional but breaking change. It is gated by a schema/config version bump (or `meta.schemaVersion`) to provide consumers with a clear migration boundary.

### 5.2 JSON Schema Configuration
*   **Location**: Standardized at `config/standards.schema.json`.
*   **Validation Core**: Uses Ajv in **strict mode** with `ajv-formats` enabled and `allErrors: true`.
*   **ID Uniqueness**: Checklist IDs are validated as unique across **all combined sections** (Core, Recommended, and Optional Enhancements).
*   **Reference Safety**:
    *   `migrationGuide[*].focusIds[]` must refer to existing checklist item IDs.
    *   `appliesTo.stacks[]` must reference keys defined in the `stacks` top-level object.
*   **CI Portability**: `ciSystems[]` values and `ciHints` keys are validated against a known enum (e.g., `azure-devops`, `github-actions`).

## 6. Enforcement and Severity

Checklist items now include explicit enforcement meta-data:

*   **`severity`**: `error`, `warn`, or `info`.
*   **`enforcement`**: `required`, `recommended`, or `optional`.
*   **Default Rules**:
    *   **Core**: Defaults to `required` / `error`.
    *   **Recommended**: Defaults to `warn`.
    *   **Optional**: Defaults to `info`.
    *   Explicit overrides in `standards.json` take precedence.

## 7. Determinism Contract

All generation scripts must produce **byte-for-byte identical** output for the same input. This is verified by:
*   **Deep Sorting**: Using a stable stringify (e.g., `fast-json-stable-stringify`) to ensure keys at all depths are sorted consistently. Surface-level sorting of `Object.keys()` is insufficient.
*   **Stable Default Application**: Applying defaults during normalization and validating the result to ensure consistency.
*   **Independence**: The generator **never shells out** to Bazel or other build tools during artifact creation. All output is derived from the master spec and filesystem markers.
*   **Verification**: A dedicated unit test that runs the validator/generator twice and asserts identical results.
## 8. Scope and Abstraction Discipline

To maintain the quality and focus of the repository standards, the following discipline is enforced:

*   **No Enforcement Leakage**: Generation logic must remain pure. It must not assume specific targets exist in a repository and must **never shell out** to external build tools (Bazel, npm, etc.) to verify state.
*   **Advisory-Only execution**: Build substrate hints (like `bazelHints`) are documented as advisory representations of execution patterns, not mandated implementations.
*   **Scope Guarding**: The framework uses a generic `executorHints` container to manage execution-hint patterns (e.g., `executorHints.bazel`), allowing extensibility for other monorepo executors without breaking schema integrity.
*   **Stable Fieldset**: Core structure names like `meta.executorHints` remain stable to prevent breaking changes for consumers established on previous v3 iterations.

---

## 9. Automated Testing and Validation Suite

The framework includes a comprehensive test suite (in `src/index.test.ts`) to ensure the integrity of dependency governance metadata and schema versioning.

### Core Validations
- **Schema Versioning**: Ensures `standards.json` matches the current major version of the npm package.
- **Item Presence**: Verifies that new recommended items (e.g., `dependency-update-automation`) correctly appear in the generated checklists.
- **Logic Validation (`anyOfFiles`)**: Confirms that compliance metadata for tools like Renovate/Dependabot is correctly populated.
- **Documentation Sync**: Prevents README version references from drifting out of sync with the actual schema version via automated matches.
- **Executor Hints**: Validates that root markers for monorepo executors (like Bazel) are correctly defined and that the `configPath` for opt-out mechanisms is consistent.
- **Build-time Invariants**: Enforces strict alignment between the internal schema version and the published package version during the build process.

### Deep Determinism Verification
A dedicated unit test runs the validator/generator twice and asserts that the resulting artifacts are **byte-for-byte identical**, ensuring stable output for CI and source control.

 ## 10. External Reference and Contamination Auditing
 
 To maintain repository hygiene and prevent unauthorized dependency drift, administrators periodically audit the codebase for "weird" or external references. 
 
 ### Audit Strategy
 *   **Discovery**: Search for external repository URLs, organization names, or project-specific keys that do not belong to the current workspace.
 *   **False Positive Mitigation**: Short search strings (e.g., 3-character prefixes like `ado`) frequently produce high noise. Auditors MUST distinguish between:
     *   **Substrings of safe words**: `Adopt`, `Shadow`, `Radon`, `Readonly`.
     *   **System Hashes**: SHA integrity fields in lockfiles (e.g., `package-lock.json`, `pnpm-lock.yaml`).
     *   **Common boilerplate**: Standard ESLint globals or JSDoc strings.
 *   **Remediation**: 
     *   Intentional but non-production references (e.g., diagnostic reproduction cases) MUST be stored in a dedicated `repro/` or `diagnostic/` directory.
     *   Once a diagnostic task is complete, the scaffolding and all associated external references SHOULD be removed from the master branch to avoid future confusion.
     *   Historical notes in lockfiles or comments detailing *why* a dependency was removed are acceptable but should be periodically pruned if they reference external private infrastructure.

## 11. High-Fidelity Documentation Reconciliation

To maintain the integrity of "authoritative" repository documentation (e.g., `INVARIANTS.md`, `TESTING.md`), administrators must ensure documentation remains in parity with the physical implementation state.

### 11.1 Divergence Auditing
*   **Budget/Timeout Drifts**: Periodically verify that numeric constants (integration budgets, poll intervals) mentioned in documentation match the hardcoded values in automation scripts (e.g., `run-all-tests.ps1`).
*   **Status Staleness**: Ensure "Planning phase" or "Internal-only" tags are removed as soon as features are verified in CI/Main.
*   **Ministerial Status Reconciliation**: Authoritative status descriptors (e.g., "Blocked", "Verified", "✅ CI") in governance tables must be audited against actual CI job triggers and outcomes to prevent misinformation about system enforcement.
*   **Terminology Purge**: When an architectural component is replaced (e.g., Web UI to Web Terminal), legacy descriptive terms (e.g., "glassmorphic") must be purged repository-wide from structural diagrams, READMEs, and test suites to prevent architectural confusion.
*   **Historical Trace Preservation**: Distinguish between "Current State" documentation (which must be accurate) and "Audit Logs" (which are historical records). Audit logs (e.g., session summaries) should retain their original values to preserve the historical implementation trace, even if those values are now obsolete.

### 11.2 Verification
*   Utilize repository-wide greps to identify residual terminology or stale constant values during major release cycles.
