# High-Integrity Polyglot Testing Patterns

These patterns enable fast, reliable, and deterministic testing across polyglot microservice repositories (e.g., Node.js, Python, Go, Rust). They were hardened during the ODTO Phase 17 optimization cycle and expanded in Phase 31.

---

## 1. Unified Coverage Enforcement

**Goal**: Establish a single source of truth for coverage thresholds across all services and prevent "threshold drift" in individual CI jobs.

### Pattern: Centralized Config + Unified Checker

1.  **`coverage-config.json`**: A root-level configuration file.
2.  **`check-coverage.py`**: A portable Python script that enforces the config.

### Sub-Pattern: Robust Coverage Extraction

CI environments are fragile. Directly parsing shell command output for coverage percentages can lead to empty values if tools fail silently or change formats.

**Hardened Extraction Pattern (Shell)**:
```bash
# FAIL-CLOSED: Initialize to 0 so checker catches it as a failure
coverage_pct="0"

# EXTRACT: Use robust regex or grep with terminal error handling
pytest --cov=. --cov-report=term tests/ > coverage_output.txt 2>&1 || true
cat coverage_output.txt

# Extract from TOTAL line
coverage_pct=$(grep -E '^TOTAL' coverage_output.txt | awk '{print $NF}' | tr -d '%' || echo "")

# FALLBACK logic
if [ -z "$coverage_pct" ]; then
  coverage_pct=$(grep -oE '[0-9]+%' coverage_output.txt | tail -1 | tr -d '%' || echo "")
fi

# FAIL if extraction failed entirely (prevents silent passing with 0%)
if [ -z "$coverage_pct" ]; then
  echo "::error::Coverage extraction FAILED - missing or corrupt output"
  exit 1
fi

# VALIDATE
python scripts/check-coverage.py processor "$coverage_pct"
```

### Sub-Pattern: Entrypoint Masking (Library-Only Verification)

In architectures where entrypoints (e.g., `main.rs`, `main.go`, `index.ts`) are inherently side-effect heavy (orchestrating event loops or global singletons), valid code coverage goals are often unreachable for the entrypoint itself.

**Pattern**: Redirect coverage measurement to the internal library modules (`--lib`) and explicitly exclude the orchestrator to reveal the "True Logic Coverage".

1.  **Rust (Tarpaulin)**: Use `--lib` to focus on the crate library and `--exclude-files` to remove the bin entrypoint.
    - *Risk*: Tarpaulin's `--lib` may still include `main.rs` if not explicitly excluded.
    - *Example*: `cargo tarpaulin --lib --exclude-files src/main.rs --out Xml`
2.  **Go (Cover)**: Use package-level targeting to exclude the `main` package while enforcing 80%+ on internal logic packages (e.g., `validator/`).
3.  **Governance**: Thresholds for "Masked" services (e.g., TUI at 31%) must be documented in `coverage-config.json` with a rationale (e.g., "Rendering glue in main.rs is not unit-testable") to prevent future developers from misinterpreting the low number as a quality gap.

### Sub-Pattern: Behavioral Coverage Protocol (Pass/Fail)

When unit coverage is structurally limited by entrypoint side-effects, "Completeness" is measured via **Behavioral Coverage** in the integration/visual tier instead of "Code Coverage %" in the unit tier.

**Pattern**: Supplement low unit coverage with an explicit "Passing/Failing" badge and a **Scope Matrix** that maps tests to user-visible behaviors.

1.  **Metric Displacement**: Avoid reporting a combined coverage percentage if the measurement method for the "glue" is not deterministic. Instead, use binary status (Pass/Fail).
2.  **Scope Mapping**: Maintain a `tests/<tier>/README.md` or equivalent that explicitly lists the **Protected Behaviors**. This allows reviewers to verify that logic excluded from unit coverage is indeed captured by the behavioral suite.
3.  **Badge Protocol**:
    *   `![Service Unit](.../badge/Service%20Unit-30%25-orange)` (Honest measurement)
    *   `![Service Behavioral](.../badge/Service%20Behavioral-Passing-blue)` (Authority)
4.  **Failure Semantics**: A regression in a behavioral test should be treated with the same severity as a unit coverage drop, even if it doesn't move a percentage needle.

## 2. WebSocket Constructor Mocking (Failure Injection)

**Goal**: Reliably test "WebSocket Offline" fallback UI states in browser environments where `page.route()` fails to intercept WebSocket handshakes (common in proxied or high-parameterized environments).

### The Challenge: Unrouted Handshakes
Standard route interception in testing frameworks often prioritizes `fetch` and `XHR`. WebSockets, due to their unique upgrade protocol, can sometimes bypass these filters if they are proxied via non-standard ports or if the testing engine lacks deep protocol hooks for the specific browser version. This results in "The Fallback Trap," where a test intended to verify a failure state instead reports a successful connection.

### The Solution: Prototype Injection
Instead of intercepting the network at the browser-engine boundary, override the `WebSocket` constructor within the page context BEFORE the application code executes.

### Implementation (Playwright `addInitScript`)
```typescript
await page.addInitScript(() => {
    class FakeWebSocket {
        readyState = 3; // CLOSED
        onopen: (() => void) | null = null;
        onclose: ((event: CloseEvent) => void) | null = null;
        onerror: ((event: Event) => void) | null = null;
        onmessage: (() => void) | null = null;
        
        constructor() {
            // Simulate an immediate connection failure
            setTimeout(() => {
                if (this.onerror) {
                    this.onerror(new Event('error'));
                }
                if (this.onclose) {
                    this.onclose(new CloseEvent('close', { 
                        code: 1006, 
                        reason: 'Mock connection failure' 
                    }));
                }
            }, 100);
        }
        
        send() {}
        close() {}
    }
    // authoritatively replace binary-API
    (window as any).WebSocket = FakeWebSocket;
});

await page.goto('/');
// ASSERT: Fallback is visible because the constructor itself guaranteed failure
await expect(page.locator('#fallback-container')).toBeVisible();
```

**Key Advantages**:
- **Authoritative**: Guaranteed to work regardless of routing rules or proxy configurations.
- **Protocol-Agnostic**: Does not require the test runner to understand the WebSocket upgrade handshake.
- **Synchronous Control**: Enables deterministic testing of retry logic by toggling the `FakeWebSocket` behavior based on global flags injected into the page.

### Pattern: Server-Side Failure Injection (Preferred for High-Hedge)
While Prototype Injection is useful for UI-only tests, it can be unreliable or brittle when the application bundle initializes WebSockets before the injection script completes. For mission-critical fallback verification, **Server-Side Failure Injection** is the preferred Tier 3 strategy:
- **Implementation**: The service (e.g., PTY Broker) implements a test-only mode (guarded by `env: PTY_TEST_MODE=fail` or a query param like `?test_mode=fail`) that authoritatively rejects connections.
- **Example**: In ODTO, the `web-pty-server` supports `PTY_TEST_MODE=fail` (global rejection), `PTY_TEST_MODE=delay:<ms>` (global latency), and URL-based `?test_mode=fail` (per-request rejection).
- **Frontend Passthrough Mandate**: For per-request injection to work, the frontend (e.g., `terminal.js`) MUST explicitly detect relevant query parameters in its own `window.location.search` and append them to the WebSocket connection URL.
- **Authoritative Rejection**: To prevent infinite reconnection loops during tests, the frontend MUST treat specific codes (e.g., `INTERNAL_ERROR`) as terminal signals that trigger fallback and suppress the `auto-reconnect` logic.
- **Benefit**: Zero client-side timing races; exercises the true networking failure path in the frontend library.

---

## 3. CI Performance Guardrails (The Budget Mandate)

**Goal**: Prevent "Infrastructure Bloat" from silently slowing down CI pipelines and ensure that integration harnesses are both fast and diagnostic-rich.

### Pattern: Explicit Elapsed Time Budgets

Integration test harnesses (e.g., `integration-harness.ps1`) MUST implement a strictly enforced time budget.

1.  **Fail-Fast Budgeting**: The harness tracks the total elapsed time of the test suite. If the time exceeds the configured `$BUDGET_SECS`, the harness MUST fail the build, even if all tests passed.
2.  **Explicit recalibration**: Budgets are not static. When significant features (e.g., more services, real binaries instead of mocks) are added, the budget must be explicitly reviewed and updated in the code.

**Hardened Implementation (PowerShell)**:
```powershell
# CONFIG: Budget for the integration tier
$BUDGET_SECS = 180 

# EXECUTE
$startTime = [DateTime]::Now
./run-tests.ps1
$elapsed = ([DateTime]::Now - $startTime).TotalSeconds

# VALIDATE
if ($elapsed -gt $BUDGET_SECS) {
    Write-Error "[BUDGET EXCEEDED] ${elapsed}s > ${BUDGET_SECS}s. Either optimize the harness or explicitly increase the budget in code."
    exit 1
}
```

### Why Enforcement Matters:
- **Detects Environmental Stalls**: If the runner environment (e.g., GitHub Actions) is under-provisioned or experiencing networking stalls, the budget violation provides immediate signal.
- **Prevents Test Bloat**: Engineers are forced to justify why a test suite that once took 60s now takes 180s. 
- **Deterministic SLA**: Ensures that CI turnaround times stay within acceptable developer-loop limits.


---

## 4. Double-Handle WebSocket Hygiene (CI Resilience)

**Goal**: Prevent `Error: Maximum sessions per IP reached` in CI environments by ensuring that all WebSocket handles created during a test (whether by the application bundle or the test harness) are authoritatively closed. (Standard ODTO limit: **5 sessions per IP**).

### Pattern: The Robust `afterEach` Cleanup

Every test suite that instantiates a WebSocket through the browser page MUST implement a mandatory cleanup block to explicitly close the connection.

**Implementation (Playwright)**:
```typescript
test.afterEach(async ({ page }) => {
    // Deterministic teardown: close WebSocket to free session slot
    try {
        await page.evaluate(() => {
            // Force close using exposed handles (Standard 15)
            // @ts-ignore - Handle for terminal.js bundle
            if (window.__odtoWs) {
                window.__odtoWs.close(1000, 'test cleanup');
            }
            // @ts-ignore - Handle for state-preservation tests
            if (window.ws) {
                window.ws.close();
            }
        });
    } catch (e) {
        // Log cleanup errors but don't fail the test
        // Usually means the page was already closed or navigated away
    }
    // Explicitly close the page to speed up resource freeing
    await page.close().catch(() => {}); 
});
```

> **Crucial Insight**: Playwright's `page.route()` does NOT intercept WebSocket connections. This is a common source of "Mocking Leakage" where tests appear to be isolated but continue to establish live connections to the backend. Always verify connection hygiene by monitoring the PTY broker's session logs.

### Why Enforcement Matters:
- **Avoids "ESM Isolation Trap"**: Modern bundles (esbuild/Vite) encapsulate variables. If the frontend code doesn't explicitly do `window.__odtoWs = ws`, the cleanup script will always see `undefined`, the connection will remain open, and the session limit will be hit within seconds in a fast test suite.
- **Prevents Session Exhaustion**: Standard browser page closure may not immediately drop the WebSocket connection to the broker.
- **Enables Behavioral Testing**: Allows non-visual tests (Session States, Metrics) to run reliably in CI without being skipped due to resource limits.
- **Protocol Determinism**: Ensures every test starts with a "Clean Slate" broker state.
- **Mandatory for Smoke Tests**: This pattern must be applied even to "deterministic" smoke tests that only inspect DOM elements. Because the page load initiates a WebSocket connection at the library level (`terminal.js`), every test instance consumes a session slot. Without teardown, a suite of 6+ smoke tests will baseline-fail in CI.

### The "Per-IP Session Cap" Hazard
Even with cleanup, high-repetition tests can hit server-side limits.
- **The Limit**: PTY brokers typically enforce a `PTY_PER_IP_CAP` (default: 5).
- **The Symptom**: `Error: Maximum sessions per IP reached` (code 1005/1006).
- **Diagnostic Tool**: Proactive metrics monitoring during test failures.
  ```powershell
  # Query broker metrics to see active vs idle sessions
  curl -s http://localhost:9001/metrics | Select-String "pty_sessions"
  ```
- **Remediation**: 
  1. Increase the cap in the integration environment (e.g., `PTY_PER_IP_CAP=30`).
  2. Implement an aggressive idle-timeout for sessions in the broker.
  3. Force-restart the broker container (`docker restart <container>`) to clear the session pool.
  4. **Nuclear Option**: If sessions are re-grabbed by "Zombie" reconnecting clients, perform a full `docker compose down && up` to drop the virtual network and terminate all active connections.

---

## 5. Metrics Assertions: Presence over Exact Values

**Goal**: Prevent behavioral test failures caused by "Metric Accumulation" in stateful services or shared CI environments.

### The Challenge: Cumulative State
Stateful services (like PTY brokers or metrics engines) often maintain cumulative counters (e.g., `total_sessions_connected`). In CI, where containers might restart or tests run in parallel/sequence without a full data wipe, asserting an exact value (e.g., `expect(connected).toBe(1)`) is highly fragile.

### The Solution: Flexible Matching (Regex)
Instead of exact value matching, use regular expression assertions to verify the *presence* and *format* of the metric, or use relative assertions (e.g., `greaterThan(0)`).

**Hardened Implementation (Playwright)**:
```typescript
// ❌ WRONG: Fragile, fails if a session leaked from a previous test
expect(metrics).toContain('pty_sessions_connected 1');

// ✅ RIGHT: Robust, verifies the metric exists and is a number
expect(metrics).toMatch(/pty_sessions_connected \d+/);
```

### Why Enforcement Matters:
- **Reduces CI Flakiness**: Decouples test success from the absolute state of the infrastructure.
- **Focuses on Behavior**: Verifies that the service is correctly *emitting* the data, which is the primary goal of an integration test.
- **Handles Parallelism**: Allows multiple test workers to hit the same service without tripping over each other's session counts.

---

## 6. The Tiered Visual Test Strategy (v3.1.5)

To resolve the tension between continuous integration speed and visual regression depth, ODTO enforces a formal three-tier separation:

1.  **Tier 1: CI-Safe (PR Gate)**:
    - **Scope**: Behavioral logic and Bundle Smoke Tests (verifying asset delivery and basic page load).
    - **Constraint**: No live WebSocket dependencies (or highly stable, mocked connections).
    - **Parallelism**: High (e.g., `workers: 4+`).

2.  **Tier 2: Visual Regression (Nightly/Scheduled)**:
    - **Scope**: Screenshot-heavy tests (Theme fidelity, Dashboard layout, Resizing).
    - **Environment**: Specialized nightly workflow in an isolated, stable runner.
    - **Parallelism**: Serialized (`workers: 1`) to eliminate rendering jitter and session-limit overlaps.
    - **Maintenance**: Supports `--update-snapshots` via manual workflow dispatch.

3.  **Tier 3: Protocol Fallback (Mocked/Injection)**:
    - **Scope**: Edge cases like "Server Offline" or "Handshake Timeout".
    - **Enforcement**: Uses the **Server-Side Failure Injection** pattern to ensure deterministic fallback triggering.

### Why Enforcement Matters:
- **Reduces Merging Friction**: Prevents blocking developers on "pixel differences" unrelated to their changes.
- **Isolates Brittle Environments**: Moves tests that depend on unstable features (like Playwright WebSocket interception) out of the critical path until they are hardened.
- **Clean Signal**: A failure in Tier 1 always indicates a broken contract or logic; Tier 2 indicates visual divergence or environmental drift.

### Pattern: The Local Test Cycle
To maintain the integrity of Tier 1 & 3 while allowing for visual drift in Tier 2, developers should use matched filters:
- **Default (Pre-Commit)**: `npx playwright test --grep "Tier 1|Tier 3"`
- **Authoritative (Visual)**: `npx playwright test --grep "Tier 2" --workers=1`

 
---

## 7. Infrastructure Heat Hazard (Resource Fatigue)

**Goal**: Minimize false failures caused by container engine saturation or network interface exhaustion during high-volume testing (e.g., stress testing or high `--repeat-each` values).

### The Challenge: Cumulative Overhead
Automated browser tests (Playwright/Selenium) are resource-intensive. Running a large suite with high parallelism or repetition can lead to:
1.  **Service "Unhealthiness"**: Internal health-check probes fail because the service process is starved of CPU/Network cycles.
2.  **502/503 Gateways**: Nginx or other proxies return errors when the backend PTY broker or API gateway cannot handle the rapid succession of browser-driven WebSockets.
3.  **IO Race Conditions**: Filesystem or socket cleanup lags behind the test runner's churn.

### Remediation Strategy:
- **Reset on Heat**: If 502/503 or "Unhealthy" states appear during a high-volume run, perform a full `docker compose down && docker compose up` reboot of the environment. Stale socket handles in the bridge network can cause persistent failure after the first saturation event.
- **Worker Calibration**: Parallelism MUST be calibrated to the host resources. Over-subscription (e.g., 8 workers on a 4-core machine) significantly increases the risk of "target page closed" race conditions.
- **Hygiene Mandate**: Robust `afterEach` cleanup (Pattern 4) is the only reliable way to prevent cumulative resource exhaustion.


---

## 8. The Zero-Tolerance Flake Protocol

**Goal**: Eradicate non-deterministic test behavior to maintain the integrity of the CI gate. "Flaky" tests are treated as failures, not environmental artifacts.

### The Standard: "Stop and Fix"

1.  **No Exceptions**: A test failure, even if intermittent or suspected of being environment-dependent (e.g., path resolution, timing races), MUST be addressed before a feature branch is merged to `main`.
2.  **Policy**: "I don't care if it's flaky. We stop to discuss and fix it right." (Project Governance Standard v3.1.14).
3.  **Containment**:
    *   **Isolate**: Use test filters (e.g., `cargo test <test_name> -- --nocapture`) to prove the failure in isolation.
    *   **Root Cause**: Identify if the flake is caused by global state (shared directories/ports), non-deterministic execution order, or environment sensitivity (e.g., `find_project_root` failing based on CWD).
    *   **Remediation**: Hardened the logic to be invariant of the environment. Avoid `sleep()` as a fix; prefer explicit polling or setup/teardown isolation.

### Common Flake Patterns & Fixes

| Pattern | Flaw | Hardened Solution |
| :--- | :--- | :--- |
| **CWD Dependency** | Test assumes a specific working directory for path resolution. | Use marker-based discovery (e.g., `find_project_root`) or manifest-relative paths. |
| **Socket Collision** | Multiple tests trying to bind to the same port. | Use ephemeral ports (port 0) or serial execution for sensitive tests. |
| **Global State** | Tests modifying shared environment variables or files. | Use mutexes or unique temporary directories for each test run. |
| **Timing Races** | Asserting on async effects with `sleep`. | Use bounded polling with `Eventually` patterns or signal channels. |

---

## 9. Orchestration & Entrypoint Integrity

**Goal**: Prevent "Environmental Blind Spots" where tests pass in a specialized CI context but fail in production/release environments due to bypassed orchestration logic.

### Pattern: The Authoritative Wrapper Invariant (v3.1.15)

In high-integrity monorepos, a single entrypoint (e.g., `run-all-tests.ps1`) is designated as the **Sole Authority** for test execution. This script is responsible for setting up the environment (CWD, PATH, Env Vars) required for the tests to succeed.

**The Failure Pattern**: Developers add specialized CI jobs (e.g., `tui-build`) that invoke toolchain commands directly (`cargo test`) to save time or isolate failures. This bypasses the wrapper's environment setup, leading to a state where tests pass in CI (because the runner has a specific checkout) but fail in other contexts where the wrapper's logic is missing.

**The Governance Rule**:
1.  **Zero Direct Calls**: CI YAML configurations MUST NOT invoke toolchain-specific test commands (e.g., `go test`, `pytest`, `cargo test`) for components covered by the authoritative wrapper.
2.  **Wrapper-First Execution**: If a component needs verification in CI, it MUST be invoked via the wrapper (e.g., `pwsh ./scripts/run-all-tests.ps1 -Target tui`).
3.  **Local/CI Symmetry**: If a test fails in the wrapper locally, it MUST fail in CI. Reversely, if it passes in CI via a direct call but fails in the wrapper, the DIRECT CALL is the bug.

### Pattern: Negative Discovery Resilience (Hardened v3.1.16)

Tests that identify the "Project Root" by searching for specific directory markers (e.g., `scripts/`, `infra/`) are inherently brittle. They produce false negatives in isolated checkouts and fail silently if markers are missing but a "root" is still found.

**Hardened Discovery Protocol**:
- **Prefer Standardized Env Vars**: Always prefer toolchain-provided variables (e.g., `CARGO_MANIFEST_DIR` in Rust, `__dirname` in Node) over manual filesystem scanning.
- **Fail-Fast with Metadata**: If discovery fails, the error message MUST include `env::current_dir()`, `env::vars()`, and the list of probed paths.
- **Hermetic Synthetic Testing**: DO NOT rely on the host repository layout for unit tests. Instead, use a temporary directory library (e.g., `tempfile`) to construct a synthetic project layout at runtime. This allows verifying that discovery correctly handles both "full repo", "missing markers", and "nested" scenarios in a deterministic way.
- **Avoid Ambiguous Path Assertions**: When testing discovery behavior in specialized modes (e.g., Server/Container mode), assert on the *behavior* (e.g., "bypasses FS walk and returns the configured root") rather than hardcoding absolute Unix paths (like `/app`), which are non-portable to Windows/macOS runners.
- **Integration Test Designation**: Tests that *do* require the real host filesystem (e.g., checking for real scripts) MUST be marked as `#[ignore]` or equivalent to prevent them from running in isolated build/release pipelines where they are expected to fail.

### Pattern: Isolation & Parallelism Hygiene (The RAII Guard)

**Goal**: Prevent "Mutation Races" where parallel tests modify global state (CWD, Environment Variables) and cause random CI failures.

**The Rule**:
1. **Mandatory Restoration**: Any test that modifies `std::env::set_current_dir` or process-wide environment variables MUST restore the original state before exiting.
2. **RAII Wrapper**: Prefer a Guard object that restores state in its `Drop` implementation to handle panics.
3. **Serial Enforcement**: Tests that mutate global state SHOULD be marked for serial execution (e.g., `#[serial]`/`serial_test` crate in Rust) to prevent racing with other tests that rely on a stable environment.
4. **Force Single-Threading**: In release-critical jobs or crates with high mutation counts, enforce `test-threads=1` globally at the runner level as a safeguard against accidental parallelism.

**Hardened Implementation (RAII Guard Example)**:
```rust
struct EnvGuard {
    original_cwd: PathBuf,
    vars: Vec<(String, Option<String>)>,
}

impl Drop for EnvGuard {
    fn drop(&mut self) {
        std::env::set_current_dir(&self.original_cwd).unwrap();
        for (k, v) in &self.vars {
            if let Some(val) = v { std::env::set_var(k, val); }
            else { std::env::remove_var(k); }
        }
    }
}
```

