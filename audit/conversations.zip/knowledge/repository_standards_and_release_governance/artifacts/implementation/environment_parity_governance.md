# Environment Parity Governance

Maintaining behavioral and compilation parity between local developer environments and CI/CD runners is a core challenge in polyglot monorepos. Deviation often leads to "Silent Breakages"—where code passes local checks but fails in production pipelines.

## 1. Dependency Drift Analysis

Dependency drift occurs when different environments resolve the same manifest (e.g., `package.json`, `Cargo.toml`) to different artifact versions.

### 1.1 Root Causes
- **Loose Semantic Versioning**: Using ranges like `^1.2.0` or `1.x` allows runners to pull the latest "compatible" version, which may contain breaking API changes or subtle logic shifts.
- **Lockfile Volatility**: If CI runners perform "fresh" builds without a pre-existing lockfile (or if the lockfile is ignored/replaced), they will resolve to the absolute latest versions allowed by the manifest.
- **Binary vs. Library Policy**: A common anti-pattern is ignoring `Cargo.lock` or `pnpm-lock.yaml` in the root `.gitignore`. While libraries should often ignore lockfiles to test against ranges, **binaries must track them** to ensure the exact environment used by the developer is replicated in CI and the final release.
- **Platform-Specific Resolution**: Some package managers resolve differently depending on the host OS or CPU architecture.
- **Default Value Drift**: Many services define fallback configuration values (e.g., `POSTGRES_URL = os.getenv('URL', 'localhost:5432')`) in code. If these defaults differ from the actual infrastructure provided by the orchestrator (e.g., a service expects `postgres:5432` but the orchestrator provides `odto-integ-postgres:5432`), the service may silently connect to the wrong database or fail logic checks despite appearing "healthy".

## 2. Hardening Patterns

### 2.1 Exact Version Pinning
For mission-critical components (UI libraries, orchestration drivers, cryptographic modules), move from loose ranges to exact pins.
- **Rust**: `ratatui = "=0.24.0"` instead of `ratatui = "0.24"`
- **Node.js**: `"dependency": "1.2.3"` (without tilde or caret)
- **Python**: `package==1.2.3`

### 2.2 Locked Build Enforcement
CI workflows must enforce the use of the committed lockfile to prevent auto-upgrades during the build process.
| Language | Enforcement Flag | Purpose |
| :--- | :--- | :--- |
| **Rust** | `cargo build --locked` | Fails if `Cargo.lock` needs update. |
| **Node (pnpm)** | `pnpm install --frozen-lockfile` | Reproducible install from `pnpm-lock.yaml`. |
| **Python** | `pip install -r requirements.lock` | Uses exact hashes/pinnings. |

### 2.3 Infrastructure Port Drift
A subtle form of drift occurs when the **internal configuration** of infrastructure components (e.g., database UIs, caching proxies) changes in a new image version, but the external orchestration (Kubernetes manifests, Terraform) remains static.
- **The Risk of `:latest`**: Using floating tags for infrastructure (e.g., `image: redislabs/redisinsight:latest`) creates a non-deterministic environment. A major version bump in the image (e.g., v1 to v2) can change the default listening port (e.g., 8001 to 5540), leading to silent connectivity failures.
- **False-Positive Readiness**: Kubernetes reported "Ready" status often relies on the process existing, not necessarily the port mapping being correct. 
- **Governance Standard**: 
    1.  **Pin Infrastructure Versions**: Use specific version tags for all 3rd-party infrastructure images.
    2.  **Explicit Dependency Management**: Treat the internal ports of dependencies as a contract. Any change to the image version must include a verification of port mapping and security origins (CORS).
    3.  **Cross-Port Origins**: Ensure `RITRUSTEDORIGINS` or equivalent security filters are updated to include both the container-internal and port-forwarded origins to prevent origin-mismatch stalls.

## 3. High-Integrity Build Gates

A distributed system is only as stable as its weakest component. Every distributable artifact must be independently verified.

### 3.1 Component-Level Isolation
- **PR Gates**: Every Pull Request must trigger a compilation check (`check`, `lint`, or `test`) for *every* subdirectory that contains a standalone binary or library.
- **Fail-Fast Parity**: If a component (e.g., a Rust TUI in a Node.js project) is skipped in CI, it effectively has zero verification until the final release stage, increasing the risk of "Post-Merge Failure."

### 3.2 Sanity Verification
The release pipeline should perform a "Clean Build" sanity check on the actual merge commit *before* performing high-stakes actions like npm publishing or Git tagging. This prevents "Broken Tag" scenarios.

## 4. Delivery Infrastructure Reliability

"Last-mile" failures occur when the build is solid, but the automation that delivers it is fragile.

### 4.1 Reliable Version Detection
- **Avoid Fragile Parsing**: Do not rely on piping CLI output to `grep` or `awk` for critical version orchestration (e.g., extracting version from `semantic-release` logs).
- **Official Actions Pattern**: Use official, platform-maintained GitHub Actions (e.g., `cycjimmy/semantic-release-action`) which provide structured outputs directly to the Runner context.
- **Fail-Closed Releases**: Automation should verify that all outputs from a build matrix exist before creating a global release object.

### 4.2 GitHub Action Permissions
- **Principle of Least Privilege**: Explicitly define the `permissions:` block in the workflow YAML.
- **Critical Capability**: Automated tagging and release creation require `contents: write`. Relying on default settings is a primary cause of "Last-mile" production failures (e.g., `EGITNOPERMISSION`).
- **Checkout Identity**: Ensure `persist-credentials: true` is set if the release tool needs to push back to the repository.

## 5. Hermetic Build Contexts (Ignore Hygiene)

In polyglot monorepos, local developer artifacts (coverage profiles, binary builds, temp files) must be strictly excluded from the repository history and Docker build contexts.

### 5.1 Standardized Ignore Patterns

Consistency between `.gitignore` and `.dockerignore` prevents "Ghost Files" (files that exist locally but not in the container) and keeps build stages deterministic.

| Language | Artifact Type | Pattern |
| :--- | :--- | :--- |
| **Go** | Coverage Profiles | `coverage.out`, `**/coverage.out`, `**/coverage` |
| **Python** | Coverage & Cache | `.coverage`, `htmlcov/`, `__pycache__/` |
| **Node.js** | Dependencies | `node_modules/` |
| **Rust** | Build Targets | `target/` |
| **Bazel** | Convenience Symlinks | `bazel-*` |

### 5.2 Performance & Cache Integrity

Failing to mirror `.gitignore` logic in `.dockerignore` causes Docker to include unnecessary files in the build context. In large repositories, this leads to:
1.  **Context Bloat**: Slower upload times to the Docker daemon.
2.  **Cache Invalidation**: Changing a local coverage file (which should be irrelevant to the build) triggers a full context re-upload and often invalidates early build layers.

**Governance Standard**: Every root-level ignore file must explicitly exclude high-volume test artifacts and platform-specific binary outputs.

### 5.3 Git Ignore Cache Invalidation ("Funny Status" Bug)

In polyglot monorepos where artifact directories are rapidly created and destroyed (e.g., `integration-artifacts/`), the Git index can occasionally display ignored directories as untracked (`??`) even when they match a `.gitignore` pattern.

- **Symptom**: `git status` shows an ignored directory as untracked, while `git check-ignore -v <path>` confirms the pattern is active.
- **Root Cause**: This typically happens when a file inside the directory was accidentally staged/tracked in the past, or if the Git cache is out of sync with recent `.gitignore` modifications.
- **Hardened Remedy**:
  1. **Audit**: `git check-ignore -v <path>` to confirm no typo in the ignore file.
  2. **Purge Cache**: `git rm -r --cached <path>` to ensure the index is clean.
  3. **Verification**: `git status` should no longer show the directory.

### 5.4 OCI Build Context Governance (Monorepo Pattern)

In monorepos, OCI images for individual services often require shared resources (e.g. standard contracts, proto definitions, or common library code) located outside the service's subdirectory.

- **The Context Conflict**: Standard `docker build` commands are restricted to the context directory. If a Dockerfile in `src/services/a/Dockerfile` tries to `COPY ../../shared ./shared`, the build will fail because the shared directory is outside the context.
- **Pattern 1: Repo-Root Context**: Run the build from the repository root using the service directory as a sub-path (`docker build -f src/services/a/Dockerfile .`). This effectively makes the entire monorepo available to the `COPY` command.
    - **Pros**: Zero artifact duplication.
    - **Cons**: Local `.dockerignore` becomes complex (must ignore all other services to keep context small); cache invalidation happens if *any* file in the root context changes. 
    - **Warning (Pathing Idiom)**: Dockerfiles must be written using repo-relative paths (e.g., `COPY src/services/a/index.js ./`), which breaks idiomatic service-local builds.
- **Pattern 2: Context Preparation (Copy-in)**: A wrapper script (PowerShell/Bash) or CI job copies the required shared resources into the service directory before building.
    - **Pros**: Clean, service-isolated context. Small, deterministic builds. Maintain idiomatic service-local Dockerfiles.
    - **Cons**: Requires cleanup; potential for "Stale Artifacts" if cleanup fails.
    - **Verdict**: Endorsed as the **authoritative standard** for mature polyglot systems to ensure local developer workflows and CI build logic remain identical.
- **Governance Standard**: 
    1.  **Authoritative Context Documentation**: Every Dockerfile must explicitly state its intended build context (e.g., "Context: Repo Root" or "Context: Service Local").
    2.  **Symmetric Context Handling**: Orchestration scripts (like `start-all.ps1`) and CI jobs must use the same context logic to ensure build parity.
    3.  **Ignore Parity**: Shared folders copied into service directories for Pattern 2 builds MUST be added to `.gitignore`.

### 5.5 Git Hygiene: Verifying Tracked vs Ignored Files

**Goal**: Confirm that heavy dependency directories (e.g., `node_modules/`, `venv/`, `target/`) are correctly ignored and not tracked by Git, even if they are present locally.

**Pattern: Authority Verification**:
1.  **Tracked Check**: `git ls-files --cached -- "<path>/**"` (should return nothing).
2.  **Status Check**: `git status <path> --short` (should return nothing, not even `??`).
3.  **Ignore Resolution**: `git check-ignore -v <path>` (should return the specific `.gitignore` line that matches).
4.  **Tree Search**: `git ls-tree -r HEAD --name-only | grep "<path>"` (authoritative check against the current commit).

### 5.6 Semantic Proliferation of Ignored Directories
In monorepos with multiple sub-packages, nested artifact directories (e.g., `node_modules` in subfolders) may be created by CI tools like `semantic-release`. 
- **Guideline**: Global ignore patterns in the root `.gitignore` (e.g., `node_modules/`) are recursive by default in modern Git.
- **Verification**: Use `git check-ignore -v path/to/nested/node_modules` to verify fallback to root rules.

## 6. Refined build context Invariants (B1a/B1b)

The relationship between build context and Dockerfile `COPY` assumptions is a general project principle.

### 6.1 B1a: Local Development context
- **Standard**: Local orchestration (e.g., `start-all.ps1`) uses the **Repo-Root Context** (`.`).
- **Rationale**: Simplest for developers; no artifact duplication requires.
- **Implementation**: Context = `.` in all local build commands.

### 6.2 B1b: CI Optimized Context (Service-Local)
- **Standard**: CI workflows MAY use **Service-Local Context** for cache efficiency, provided shared assets are synchronized.
- **Rationale**: Speeds up PR verification by limiting context size.
- **Enforcement**: CI jobs must explicitly sync required assets (e.g., `cp -r contracts src/services/gateway/`) before building to satisfy repo-relative `COPY` paths in the Dockerfile.


## 6. Non-Interactive Automation

To prevent "Hanging CI" scenarios, all automation tasks (Git commits, artifact pushes, dependency updates) must be strictly non-interactive.

- **Non-Interactive Flags**: Always use `-m` for `git commit`, `-y` for package managers, and `--non-interactive` or equivalent for CLI tools.
- **Credential Pre-authorization**: Rely on environment variables (e.g., `GITHUB_TOKEN`) or credential helpers rather than assuming a TTY is available for password prompts.
- **Timeouts**: Wrap indeterminate tasks in timeouts to prevent orphaned processes from consuming runner resources indefinitely.

## 7. Container-Safe Probing (Pattern 7)

Tools designed for high-interactivity often probe for host-level dependencies (Docker, kubectl, kind) to provide remediation hints. In containerized environments (CI mirrors, web terminals), these probes trigger subprocess timeouts, permission errors, or infinite loops.

- **The Zero-Probe Mandate**: Implementation of an explicit opt-in flag (e.g. `ODD_DASHBOARD_SERVER_MODE=1`) to bypass host-level command probing.
- **Stratified Verification**: In "Server Mode", tools must switch from expensive/unavailable host-level command probing to service-level detection (e.g. HTTP GET `/stats`).
- **Configuration Propagation**: API detection depends on configuration (URLs) being injected into the container. Failure to propagate these from the orchestrator (Compose/K8s) leads to silent state-detection failure within the mirrored interface.
- **Endpoint Abstraction**: Tools must avoid hardcoded `localhost` endpoints for infrastructure dependencies (e.g. Prometheus, DBs). Use environment variables (e.g. `PROMETHEUS_URL`) to allow seamless resolution within container networks where services are referenced by service name.

## 8. Viewport-Driven Scaling (Pattern 8)

When high-fidelity terminal interfaces (TUIs) are mirrored via a PTY broker (web-terminal), the traditional "Server owns the size" model fails due to the dynamic nature of browser viewports.

- **The Reverse-Propagation Contract**: PTY dimensions (cols/rows) MUST be driven by the client. The server merely applies these dimensions to the PTY instance using `winsize` ioctls.
- **Atomic Initialization**: To prevent visual truncation of large artifacts (ASCII logos, tables), the client MUST perform its initial sizing calculation (e.g., `fit()`) and propagate these dimensions to the server *before* or *immediately upon* the initial TUI draw.
- **Fidelity Impact**: Failure to propagate sizing leads to "Broken Frames" where the TUI layout engine computes a grid that doesn't match the available pixel space in the browser shell.

## 9. The Authoritative Fidelity Audit (Pattern 9)

In polyglot systems where a lightweight "Mirror Environment" (e.g., Docker Compose) is used to verify an "Authoritative Environment" (e.g., Kubernetes), architectural drift is inevitable.

- **The Symmetric Deployment Audit**: Maintain a canonical list of service deployments in the authoritative environment and perform periodic gap analysis against the mirror. 
- **The "No Shortcuts" Mandate**: Improvements designed specifically for the mirror (e.g. API health checks, Server Mode) MUST NOT break the native orchestration paths of the primary tool.
- **Observability Parity**: Critical observability providers (e.g. Prometheus) should be included in the mirror if their absence triggers non-standard visual states (like warning banners) that degrade the fidelity of visual regression snapshots.
- **Fidelity vs. Speed**: The mirror environment is optimized for **Mean Time to Proof (MTTP)**, while the authoritative environment is optimized for **Production Integrity**. Patterns that bridge this gap (like Zero-Probe Server Mode) must be explicitly documented and versioned.

#### Implementation Pattern: Manifest-to-Key Mapping Audit (v3.0.1)
To automate the fidelity gap analysis:
1. **Source of Truth**: Gather all manifest filenames in the authoritative provider directory (e.g., `infra/k8s/*.yaml`).
2. **Mirror Keys**: Extract all top-level service keys from the mirror configuration (e.g., `docker-compose.yml` services).
3. **Logic**: Perform a cross-match using substring or regex comparison. 
4. **Outcome (Zero-Gap Mandate)**: Fail CI if *any* manifest exists without a corresponding Mirror key (excluding explicit whitelists). This ensures that infrastructure changes for production are never "forgotten" in the verification mirror, maintaining a high-integrity, zero-drift verification signal.

#### Implementation Pattern: Declarative Provisioning Mirroring (v3.0.1)
To ensure that complex observability or dashboard infrastructure in the mirror matches the authoritative environment without drift or manual setup:

1. **Volume-Mapped Symmetery**: Mount authoritative configuration files (e.g., `infra/prometheus/prometheus.yml`) directly into the mirror containers via Docker Compose volumes.
2. **Auto-Provisioning**: For tools like Grafana, use standardized provisioning directories (e.g., `/etc/grafana/provisioning/datasources`) to pre-load datasources and dashboards.
3. **Immutable Identity**: Ensure service names in the mirror (e.g., `odto-integ-prometheus`) are reflected in these provisioned configs to allow seamless resolution within the mirror's network.
4. **Fidelity over Snapshots**: Prefer declarative provisioning over pre-baked image snapshots to ensure that every CI run reflects the *current* state of the repository's configuration files.

---

## 10. CI Timeout Sync Invariant (The 60s Buffer)

**Goal**: Prevent "False Failures" where a healthy integration harness is killed by the CI orchestrator because the job-level timeout is too tight.

### Pattern: Explicit Budget + Buffer Sync

The CI job-level timeout MUST be strictly greater than the harness runtime budget plus a buffer for startup and teardown.

1. **Harness Budget**: Defined in the test script (e.g., `RuntimeBudgetSec = 180`).
2. **Buffer**: Minimum 60 seconds for Docker container creation and teardown.
3. **CI Timeout**: Set in `.github/workflows/ci.yml` (e.g., `timeout-minutes: 5`).

### Verification Script (`check-timeout-sync.py`)

Implementation of an automated gate that extracts values from the codebase and validates the invariant:

```python
# Invariant: CI timeout >= (harness budget + 60s buffer)
harness_budget = extract_harness_budget() # from .ps1
ci_timeout = extract_ci_timeout()       # from .yml
required = harness_budget + 60

if ci_timeout < required:
    sys.exit(1) # Fail build
```

### Why Enforcement Matters:
- **Prevents Resource Wastage**: Avoids killing jobs that are 99% complete.
- **Diagnostics Isolation**: Ensures that failures are due to test logic, not infrastructure-level signals.
- **Contract Transparency**: Makes the relationship between harness performance and CI configuration explicit and verifiable.
---

## 11. Authoritative Port Exposure for Harness Probes

**Goal**: Ensure that external test runners (e.g., Playwright/Vitest running on the host) can reach internal service endpoints (e.g., Metrics, Health) within the integration container network.

### The Challenge: The "Invisible Endpoint"
Integration harnesses often rely on ephemeral orchestrators like Docker Compose. While services within the container network can reach each other via service names (e.g., `http://metrics-engine-integ:9001`), an **external test runner** (running on the CI host) requires explicit port mapping in the compose file to reach those same endpoints via `localhost`.

### The Pattern: Explicit Ingress Mapping
Every endpoint intended for verification by a host-resident probe MUST be explicitly mapped in the integration compose file.

1.  **Metric Probes**: Metrics endpoints (e.g., Prometheus `:9001`) must be exposed if the test suite performs behavioral assertions on counter accumulation.
2.  **Health Probes**: If the harness owns the readiness wait, the health ports must be exposed to the host.
3.  **Visual Discovery**: In visual regression tiers, the web UI port (e.g., `:8081`) must be exposed to allow Playwright's browser to navigate to the "Mirror Interface."

### Why Enforcement Matters:
- **Prevents Silent Connection Failures**: Avoids `ECONNREFUSED` errors in tests that appear to have the correct URL but lack a network path.
- **Enables Host-Resident Verification**: Allows the use of lightweight host tools (curl, fetch) to verify container state without requiring "Tests-in-Containers" complexity.
- **Symmetry with Production**: Maps the "Ingress" concept of Kubernetes to the "Port Mapping" concept of Compose, maintaining architectural parity in the verification signal.
## 12. Canonical Verification Priority (The "Local Pass" Standard)

**Goal**: Prevent pushing logic-sound changes that trigger environment-specific regressions or cross-job failures in CI.

### 12.1 The Canonical Suite Mandate
Before assuming a targeted change (e.g., a visual test or a specific service fix) is safe to merge, developers SHOULD execute the **Canonical Test Suite** (`./scripts/run-all-tests.ps1`) locally.
- **Why**: Many failures (like the "Everything is Broken" incident in Phase 31.5) are caused by desyncs in shared configurations (Rust `Config` structs) or lockfiles (`Cargo.lock`, `package-lock.json`) that are only detectable when the full repository lifecycle is executed.
- **Strict Mode**: The canonical script should be maintained to mirror CI’s strictness (e.g., enforcing `--locked` where appropriate).

### 12.2 Fix Branch Isolation
When a regression occurs that passes locally but fails in CI, the authoritative remediation step is the creation of a dedicated `fix/` branch.
- **Purpose**: Decouples the investigation of environment-specific drift from the main feature line.
- **Standard**: No merge to `main` should occur until the fix branch successfully clears all CI status checks, regardless of local "100% pass" status.
## 13. Cross-Platform Orchestration Hardening (PowerShell)

**Goal**: Ensure that orchestration scripts (setup, build, test) behave identically whether run from a direct terminal or spawned by an external application (TUI, CI Agent, Orchestrator).

### 13.1 The $PSScriptRoot Resolution Hazard

In PowerShell, `$PSScriptRoot` is the standard variable for locating the directory of the currently executing script. However, this variable is **not populated** when a script is invoked as part of a command string (e.g., `pwsh -Command "& 'myscript.ps1'"`). This frequently occurs when scripts are spawned by foreign languages like Rust or Go.

- **The Failure**: Scripts relying on `$PSScriptRoot` for relative pathing (e.g., finding the project root or manifest files) will fail or fall back to incorrect default paths (like the CWD or drive root), leading to non-deterministic behavior.
- **The ODTO Standard (v3.1.8)**: Orchestration scripts MUST use a multi-tiered resolution to ensure deterministic execution across all shell hosts.
- **Remediation (Authoritative Pattern)**:
    ```powershell
    # Hardened Root Resolution Pattern
    # 1. Primary: Resolve from the actual script file path
    $ScriptPath = $MyInvocation.MyCommand.Path
    if ($ScriptPath) {
        $script:ProjectRoot = Split-Path -Parent (Split-Path -Parent $ScriptPath)
    } 
    # 2. Secondary: Fallback to $PSScriptRoot (standard shell)
    elseif ($PSScriptRoot) {
        $script:ProjectRoot = Split-Path -Parent $PSScriptRoot
    } 
    # 3. Tertiary: Fallback to CWD with marker-based discovery
    else {
        $script:ProjectRoot = Get-Location
    }

    # Marker-Based discovery loop (walk upward until 'infra/' is found)
    while ($script:ProjectRoot -and -not (Test-Path (Join-Path $script:ProjectRoot "infra"))) {
        $parent = Split-Path -Parent $script:ProjectRoot
        if ($parent -eq $script:ProjectRoot) { $script:ProjectRoot = $null; break }
        $script:ProjectRoot = $parent
    }

    # Fail-Fast Guard: Prevent cascading errors from unresolved roots
    if (-not $script:ProjectRoot -or -not (Test-Path (Join-Path $script:ProjectRoot "infra"))) {
        Write-Error "Project root could not be resolved. Ensure the script is run from within the repository."
        exit 1
    }
    ```

### 13.2 The "-File" vs "-Command" Semantic

- **-File**: Safest for standalone execution. Correctly populates `$PSScriptRoot`. 
- **-Command**: Often necessary for TUI/JSON parsing because it allows multiple commands or specific execution policies. Requires the hardening steps in 13.1.

**Standard**: All critical repository scripts MUST be audited for `$PSScriptRoot` dependencies and hardened against empty-string values to ensure stable cross-platform orchestration.

## 14. Monorepo Docker Build Context Standards

**Goal**: Ensure that Docker images can be built reliably across different monorepo services that share common resources (like contracts, shared libraries, or schemas).

### 14.1 The Repo-Root Context Invariant

In a monorepo, services often depend on shared assets located at the repository root. To ensure these assets are available to the Docker daemon, the **Repository Root (`.`)** must be used as the build context.

- **The Hazard**: When the build context is shifted from the service directory to the repo root, any `COPY` instructions in the Dockerfile that use relative paths (e.g., `COPY package.json ./`) will fail because those files are no longer at the context root.
- **The Standard (v3.1.8)**: Dockerfiles in monorepos with shared dependencies MUST be authored to use **Repo-Relative Paths** for all service-local assets.
- **Implementation**:
    - **Incorrect**: `COPY VERSION ./VERSION` (Assumes service-dir context)
    - **Authoritative**: `COPY src/services/gateway/VERSION ./VERSION` (Assumes repo-root context)
- **Shared Assets**: Assets located at the repo root (e.g., `contracts/`) continue to use their root-relative paths (e.g., `COPY contracts ./contracts`).

**Requirement**: CI pipelines and local orchestration scripts MUST enforce the Repository Root as the build context for all services identified as "Shared-Dependency Consumers".
