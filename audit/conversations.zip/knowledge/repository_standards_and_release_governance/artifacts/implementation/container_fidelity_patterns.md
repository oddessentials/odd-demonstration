# Container Fidelity Patterns

When polyglot systems use containerized "Mirrors" for integration testing or web-based accessibility (e.g., PTY brokers), maintaining fidelity while ensuring rapid CI execution requires specific structural patterns.

## 1. Pattern: Build-time Mode Selection (Mocking for CI)

To balance the conflicting needs of high-fidelity visual testing and fast CI feedback loops, use a parameterized Dockerfile.

- **The Strategy**: Use a build argument (`ARG PTY_TUI_MODE=real`) to select between a heavy production binary and a lightweight mock script.
- **The Contract**: Both paths MUST output a binary/script to the SAME canonical location (e.g., `/app/binary`).
- **Benefit**: CI can verify the entire "plumbing" (WebSocket connectivity, shell injection, session survival) using the lightweight mock, while release images bundle the full feature set.

### 1.1 Pattern: Hybrid Sourcing (Integration Fidelity)
In monorepos where a "Mirror" (e.g. Web PTY) embeds another component (e.g. TUI), using pre-built images from Docker Hub for everything can create a **PR Lag Gap**. 

- **The Problem**: A PR modifies the TUI source. If the integration test uses a pre-built PTY server image from the last `main` push, the visual test will verify the *old* TUI, missing the PR's changes.
- **The Strategy**: Use **Hybrid Sourcing**. High-level services (DBs, Backend APIs) use pre-built images for CI speed, but "Edge/Mirror" services (Web UI, PTY Server) are **built locally from source** during integration tests.
- **Benefit**: Ensures 100% visual fidelity for PR-level changes without sacrificing the speed of using pre-built infrastructure.

## 2. Pattern: Authoritative Asset Bundling (One Source of Truth)

In containerized environments, dynamic path discovery (e.g., "Find project root to locate config files") often fails due to flattened container filesystems.

- **Anti-Pattern**: Duplicating configuration or service lists as hardcoded strings in the binary for "graceful degradation".
- **The Strategy**: Explicitly `COPY` authoritative contracts and registries from the repository into a standardized container path (e.g., `/app/contracts/`).
- **Hardening**: Tools must be environment-aware. In "Server Mode", they should default to the container-internal path (e.g., `/app`) instead of performing expensive or restricted host-level path walking. Discovery logic must be hardened to recognize container-specific markers when the traditional repo-root markers (like `.git`) are absent.

## 3. Pattern: The Zero-Probe Mandate

Command-line tools that perform diagnostic "prerequisite checks" on startup (e.g., checking for `docker`, `kubectl`, or `kind`) can crash or hang in minimal containers.

- **The Pattern**: Implement an explicit `SERVER_MODE` environment variable.
- **The Requirement**: Bypassing ALL host-probing logic. If dependencies are required, their status must be determined via service-level API probes (HTTP health checks) rather than subprocess spawning.
- **Verification**: Symmetric unit tests must verify that "Normal Mode" still performs necessary host checks while "Server Mode" is strictly zero-probe.

## 4. Pattern: Viewport-Driven Scaling (Reverse Propagation)

Traditional terminal sessions assume the server dictates the dimensions. In web-mirrored TUIs, the browser viewport is the authority.

- **The Strategy**: The client (xterm.js) MUST calculate and emit its dimensions (`cols`, `rows`) before the TTY process is spawned or the initial frame is drawn.
- **Containment**: Use a flexbox-driven column layout (`flex-direction: column`) where the terminal element uses `flex: 1` and `min-height: 0`. This ensures the terminal fills the viewport even when elements like "Keyboard Hint Footers" are present.
- **Integrity**: Failure to prioritize resize messages results in "Logo Truncation" where large ASCII visuals are rendered incorrectly on the first frame.

## 5. Pattern: Parallelism-Aware Resource Partitioning (Session Caps)

When running automated visual tests against a containerized mirror (PTY broker), the testing framework (e.g., Playwright) can inadvertently trigger security or throttle mechanisms designed for human users.

- **The Hazard**: Concurrent test workers each establish a full session (WebSocket + PTY + TUI). If the number of workers exceeds the broker's safety limits (e.g., `PTY_PER_IP_CAP`), tests will be rejected with "Maximum sessions reached" errors.
- **The Sequential Accumulation Hazard**: Even with a single worker (`--workers=1`), sessions can accumulate if the broker implements a **Disconnect Grace Period**. If test N starts before session N-1 has been reaped (during its 30s grace window), the total session count from the same IP will eventually hit the cap.
- **The Strategy**:
    1. **Structural Alignment**: Configure the testing harness to respect or configure the broker's limits.
    2. **Worker Capping**: Explicitly limit test parallelism (`--workers=N`) to remain within the safety threshold.
    3. **Grace Period Coordination**: For CI environments, reduce the `PTY_DISCONNECT_GRACE_SECS` to near-zero OR increase `PTY_PER_IP_CAP` to accommodate the total count of the test suite (e.g. 15 if there are 13 tests).
    4. **Lifecycle Hygiene**: Explicitly restart or clear the state of the mirror between heavy test suites to ensure non-leaking session cleanup.
- **Benefit**: Ensures that security features (anti-DDoS session caps) do not become false-positive blockers for integration pipelines.

## 6. Pattern: Greedy Route Simulation (Failure Injection)

When testing failure modes (e.g., "WebSocket Unavailable") in systems with multiple proxy layers or session identifiers, simple exact-match routes often fail to intercept traffic.

- **The Issue**: A browser-side connection logic that appends tokens (e.g., `?auth=...`) or hits a secondary backend port (e.g., `:9000`) will bypass a standard `**/ws` block.
- **The Strategy**:
    1. **Greedy Globs**: Use high-entropy glob patterns (e.g., `**/ws**`) to catch all permutations of the WebSocket path.
    2. **Port-Aware Blocking**: Explicitly block the authoritative backend port (e.g., `**:9000/**`) to prevent accidental bypass of the primary proxy.
- **Benefit**: Ensures that "No Connection" fallbacks can be verified deterministically without environmental leakage.

## 7. Pattern: Hermetic Tier 1.5 Verification (Build-time Proof)

To satisfy the **Root Cause Discipline** mandate, containerized mirrors must verify their deployment feasibility before entering the integration phase.

- **The Hazard**: A PR adds a dependency or a local file required by the `Dockerfile`'s `COPY` instructions but fails to update the build context or `.dockerignore`. This results in a "silent failure" that is only discovered when the integration cluster fails to start.
- **The Strategy**: Implement a dedicated CI job (e.g., `web-ui-build`) that runs a full `docker build` on any PR touching the service's source directory (`Tier 1.5`).
- **The Constraint**: Use `npm ci` (or equivalent) in the builder stage. The build MUST fail if the lockfile is out of sync or if required build-time binaries (e.g., esbuild) cannot be resolved.
- **Benefit**: Shifts failure detection to the earliest possible point. Ensures that the builder stage "contract" is valid and that all required inputs are present in the repository.
## 8. Pattern: Build Context Parity (v3.1.10)

In polyglot monorepos, Dockerfiles often reside in service subdirectories but depend on parent-level assets (contracts, versions). To ensure reliability, the `docker build` context MUST be consistent across all environments (local development, CI, and release).

- **The Standard**: 
    1. **Mandatory Parity**: CI build contexts MUST match local dev (`start-all.ps1`) contexts. If a service is built from the repo root locally, it must be built from the repo root in CI.
    2. **The Latent Path Conflict Hazard**: Divergent contexts (e.g., CI using service-local while local-dev uses repo-root) lead to "phantom" CI successes. These occurs when CI passes while using legacy cached images, but is unable to perform a valid source-driven build because the runner's context structure does not match the Dockerfile's `COPY` paths.
    3. **Anti-Pattern: Divergent Optimization**: Attempting to maximize Docker layer cache hits by using service-local contexts in CI is prohibited if the Dockerfile uses repo-relative paths (e.g., `COPY src/services/gateway/...`).
    4. **Verified Parity Gate**: Use automated validation (e.g., `validate-dockerfile-context.py`) to ensure that CI workflow `context` definitions remain synchronized with the path assumptions encoded in the Dockerfiles.
    5. **Fail-Fast Incremental Probes**: Orchestration scripts must perform sequential builds. The "Load" step into a cluster (e.g., `kind load`) must never proceed if the "Build" step for that specific image failed.
- **Benefit**: Ensures deterministic environment setup and prevents cryptic "file not found" errors that only appear during cluster bootstrap.
    
- **The Enforcement**: This ensures that the validation script sees and verifies every service against the B1/B2 invariants. Services missing from the CI matrix effectively bypass the high-integrity verification chain, creating a risk of structural drift.

#### 8.2 Trigger/Matrix Synchronization (The Omission Hazard Part 2)
In monorepos using path-based filtering (e.g., `dorny/paths-filter`) to optimize CI execution, a secondary "Governance Gap" occurs when the build matrix is expanded but the job-level trigger is not updated.
- **The Risk**: If a new service `B` (living in `src/interfaces/`) is added to a matrix job that only triggers on `src/services/**`, changes to `B` will never trigger the job. This leads to **Stale Registry Drift** where the Docker Hub image for `B` is never updated.
- **The Strategy**: Mandate **Total Trigger Coverage**. The job's entry condition (`if: ...`) must perform a logical OR across all path-filters that represent services in the build matrix.
- **Verification**: Post-implementation audits should verify that every path defined in the matrix (the `dockerfile:` paths) has a corresponding entry in the `paths-filter` definition and the job's conditional logic.

## 9. Pattern: Deterministic Tag Alignment (Manifest Parity)

In complex monorepos, multiple actors define image tags: Dockerfiles (labels), build scripts (tags), and deployment manifests (K8s/Compose). Inconsistency between these actors leads to deployment failures or, worse, silent stale-code execution.

- **The Hazard**:
    - **Build/Deploy Mismatch**: A script builds `service:0.1.0` but the manifest pulls `service:latest`.
    - **Stale Cache Pull**: A pod pulls `:latest` from a remote registry or local cache instead of the freshly built `:0.1.0` intended by the developer.
- **The Standard**:
    1. **Authoritative Tag Source**: The project must define a single source of truth for versions (e.g., a root `VERSION` file or per-service `VERSION` files).
    2. **Manifest Synchronization**: Deployment manifests (`infra/k8s/*.yaml`, `docker-compose.yml`) MUST have their `image:` tags synchronized with the build protocol.
    3. **Automated Parity Checks**: Integration harnesses should include a sanity check that verifies the built image tag exists and matches the tag defined in the manifests being applied.
    4. **CI Enforcement**: To prevent "shortcut regression," CI must include a gate that greps manifests for the pattern `image: <service>:<tag>` and confirms that `<tag>` matches the version exported by the monorepo's versioning protocol.
    5. **Authoritative Cache Pruning**: To prevent the **Stale Image Cache Hazard** (v3.0.3), development protocols should enforce the removal of stale `:latest` tags once a service transitions to explicit versioned tags. This ensures that the orchestration layer cannot inadvertently load are pull a stale artifact if the tagging logic becomes ambiguous.
- **Benefit**: Eliminates `ErrImagePull` issues and ensures that the cluster exactly reflects the code built in the previous step.

