# Metadata Integrity & G2 Pre-commit Enforcement

In large polyglot monorepos, keeping metadata (versions, schemas, CI configurations) in sync is as critical as code quality. "G2 Enforcement" refers to metadata-level gates that catch drift before it enters the principal branch.

## 1. Pattern: G2 Pre-commit Sanity (Metadata Gates)

Catch errors in the local developer environment to prevent "Metadata Noise" or broken builds in CI.

### Key Gate Categories:
1.  **Contract Sanity**: Ensures that JSON/Protobuf schemas load as valid descriptors and conform to project-wide requirements (e.g., must have `$version`).
2.  **Version Sync**: Verifies that authoritative versions (e.g., in `package.json` or `Cargo.toml`) match across all manifests, Docker labels, and manual documentation.
3.  **CI Workflow Consistency**: Validates YAML syntax and checks for "Action Drift" (using deprecated actions or unpinned versions).
4.  **Language Boundary Hygiene**: Ensures that build artifacts from one language don't leak into another (e.g., `.js` files appearing in strict TypeScript service directories).

### Implementation Pattern (PowerShell `pre-commit.ps1`):

```powershell
# G2 Enforcement Loop
$checks = @(
    @{ Name = "Contract Sanity"; Script = "scripts/test-contracts-sanity.py" },
    @{ Name = "Version Sync";    Script = "scripts/verify-version-sync.ps1" },
    @{ Name = "CI Validation";   Script = "scripts/validate-ci.ps1" }
)

foreach ($check in $checks) {
    Write-Host ">> Running $($check.Name)..."
    & $check.Script
    if ($LASTEXITCODE -ne 0) { 
        Write-Host "[FAIL] $($check.Name) failed" -ForegroundColor Red
        exit 1
    }
}
```

## 2. Pattern: Authoritative Version Synchronization

Prevent "Ghost Versions" where a binary reports one version in its CLI but is tagged differently in the registry.

1.  **Central Version Source**: Define a single file (e.g., root `package.json` or a `VERSION` file) as the source of truth.
2.  **Verification Script**: A script that parses all manifests (`Cargo.toml`, `pyproject.toml`, `package.json`) and fails if any differ from the authoritative version. **Monorepo Best Practice**: The script (e.g., `verify-version-sync.ps1`) must check not just the primary package, but also the root `package.json` and all critical service-level manifests (e.g., `src/services/gateway/package.json`, `packages/npm-shim/package.json`). This **4-source check** ensures consistency across the polyglot monorepo and prevents "Ghost Versions" where build metadata drifts from runtime artifacts.
3.  **Image Labeling**: Automate the injection of these versions into Docker labels (`org.opencontainers.image.version`) during build to ensure parity in production dashboards.

### Polyglot Manifest Synchronization (Semantic Release)
In environments with multiple ecosystems (npm, Cargo, etc.) and nested service structures, use the `semantic-release/exec` plugin to propagate the next version across all manifests in a single atomic commit.

**Critical Requirement**: In monorepos, ensure the root `package.json` is synced even if it is not the primary publish target (e.g., if publish happens from `packages/foo`). Failing to sync the root manifest leads to "Ghost Versions" where developers see one version locally but the released artifacts report another.

**Pattern implementation (`.releaserc.json`):**
```json
{
  "plugins": [
    "@semantic-release/commit-analyzer",
    [
      "@semantic-release/exec",
      {
        "prepareCmd": "echo ${nextRelease.version} > src/interfaces/tui/VERSION && sed -i 's/^version = \".*\"/version = \"${nextRelease.version}\"/' src/interfaces/tui/Cargo.toml && cd src/interfaces/tui && cargo generate-lockfile && cd ../../../packages/npm-shim && npm version ${nextRelease.version} --no-git-tag-version --allow-same-version && cd ../.. && npm version ${nextRelease.version} --no-git-tag-version --allow-same-version && cd src/services/gateway && npm version ${nextRelease.version} --no-git-tag-version --allow-same-version"
      }
    ],
...
**Release Best Practice: Safe Metadata Sync**
When updating the version in `Cargo.toml`, avoid using `cargo update --workspace` in release scripts. If dependencies are loosely defined (e.g., `^0.24`), a full workspace update can pull in breaking upstream versions (like `ratatui 0.29.0`) that were never tested in the PR phase.
- **Pattern**: Use `cargo generate-lockfile` to strictly update the package version in `Cargo.lock` while respecting the existing dependency tree.
    [
      "@semantic-release/git",
      {
        "assets": [
          "CHANGELOG.md",
          "src/interfaces/tui/VERSION", 
          "src/interfaces/tui/Cargo.toml", 
          "src/interfaces/tui/Cargo.lock", 
          "packages/npm-shim/package.json", 
          "package.json", 
          "src/services/gateway/package.json"
        ],
        "message": "chore(release): ${nextRelease.version} [skip ci]"
      }
    ]
  ]
}
```

## 3. Pattern: Contract Sanity Checks

Before validating *data* against a schema, validate the *schema itself* for governance compliance.

- **Load Test**: Attempt to load the schema with the target validator (e.g., AJV, Pydantic).
- **Mandatory Fields**: Use a simple script to verify that every schema file includes a `$version`, `$id`, and an entry in any central version manifest (e.g., `VERSIONS.md`).
- **Fixture Reflection**: Verify that for every schema, there is at least one "Golden" (must pass) and one "Negative" (must fail) fixture in the `tests/fixtures` directory.

## 4. Pattern: CI Workflow Isolation Sanity

Ensure that workflows intended for specific branches or paths don't trigger unnecessarily or use dangerous privilege combinations.

- **Trigger Audit**: Script that parses workflow files and warns if a high-privilege runner (e.g., Mac/Windows) is used without a tight `paths` filter.
- **Action Pinning**: Enforce the use of commit SHA instead of tags for third-party actions to prevent supply chain tampering.
