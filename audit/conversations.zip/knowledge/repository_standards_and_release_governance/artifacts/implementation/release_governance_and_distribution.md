# Release Governance and Distribution Patterns

These patterns ensure that compiled artifacts (Rust binaries, Go binaries, Node.js packages) are distributed with high integrity, atomic consistency, and platform parity.

---

## 1. Safety Gates Inventory

The release pipeline implements a multi-layered defense strategy with 56+ "Safety Gates":

### I. Source of Truth & Synchronization
- **Gate 11**: `verify-version-sync.ps1` compares version sources (Cargo, npm, CHANGELOG).
- **Gate 24**: Fails release if git tag does not match authoritative `VERSION` file.
- **Gate 56**: `prepareCmd` must include `cargo update --workspace` to refresh all lockfiles before release.

### II. Infrastructure & Runner Parity
- **Gate 37**: Shift to `latest` runner tags (e.g., `macos-latest`) to avoid retired image failures.
- **Gate 59**: Use `pwsh` for all artifact movement to ensure cross-platform path reliability (prevents "Bash Backslash Trap").
- **Gate 60**: Use pure-language implementations (e.g., `rustls`) to avoid system-level dependency failures in cross-compilation.

### III. "Ghost Release" Prevention
- **Gate 26**: Use literal string equality checks (e.g., `== 'true'`) for job conditions (GH Actions boolean serialization).
- **Gate 32 / 53**: Remove GitHub plugin from `semantic-release`. Create tag first, then publish Release object only after assets are verified.
- **Gate 63**: Use a `flat/` staging directory for downloads to prevent `mv` collisions with artifact names.
- **Gate 64**: `cargo test` (or equivalent) MUST run in the same job context as `cargo build`. For side-effect-heavy suites, enforce `--test-threads=1` and require `--locked` to pass (ensuring lockfiles are included in the package).
- **Gate 64.1 (Lockfile Sync)**: If manifest changes are made (e.g., adding dev-deps), the lockfile MUST be updated before committing. Failure to do so causes "Context Inconsistency" when `--locked` is enforced in the next pipeline run.
- **Gate 65**: Workspace MUST be clean before packaging. Use `git status --porcelain` to ensure no untracked or modified files (including line-ending/generated drift) contaminate the artifact.
- **Gate 66 (Invariant R1)**: Before production release, run tests against the extracted `.crate` or `.tar.gz` package in an isolated context (e.g., `/tmp/packaged-test`). This ensures the "Fragmented Checkout" hazard is permanently mitigated.

### IV. Permission & Branch Protection
- **Gate 46**: Grant release bot bypass rights in Rulesets to prevent `GH013` (Permission Deadlock).
- **Gate 50**: Include a permission-full dry-run step on `main` immediately before publication.

---

## 2. High-Integrity Distribution Patterns

### Pattern: Artifact Validation Gate (The Asset Counter)
- **Goal**: Prevent "Partial Releases" where some platform builds succeed but others fail.
- **Strategy**: Before publication, a dedicated job must count artifacts in the staging area against expected glob patterns. If `ActualCount != ExpectedCount`, halt the pipeline.

### Pattern: Manifest Synchronization (Multi-Manifest Commit)
- **Goal**: Prevent version drift between `VERSION`, `Cargo.toml`, and `package.json`.
- **Strategy**: Use `@semantic-release/exec` to propagate the version string and refresh all lockfiles in the same commit.

### Pattern: Decoupled Publication
- **Goal**: Avoid the "Timing Trap" where an empty release exists before binaries are built.
- **Strategy**: Use `semantic-release` ONLY for versioning/tagging. Delegate Release object creation to the final `upload-assets` job after all binaries are cached.

### Pattern: The Canonical Preflight Gate (High-Fidelity Context)
- **Goal**: Prevent "Context Drift" where code passes in a full-checkout CI job but fails in an isolated binary-build checkout.
- **Strategy**: Release workflows MUST include a pre-flight test step executed in the **exact filesystem context** of the final artifact.
- **The "Artifact Mirror" Rule**: Test the *exact* packaged artifact (e.g., build from `cargo package` output). Extract the tarball to a neutral location (`/tmp`) and run tests there.
- **Lockfile Integrity**: For library crates where `Cargo.lock` is normally excluded, they MUST be configured to include it in the package to allow for strict `--locked` verification during the release gate. Never use `--locked` fallbacks (e.g., `|| cargo test` without it), as this silently masks dependency regressions.

---

## 3. Release Recovery Patterns

### Pattern: The "Double PATCH" Recovery
- **Scenario**: Release succeeded in versioning but failed in binary publication (Ghost Release).
- **Remediation**: Fix CI issue, push a new `fix: ...` commit, and trigger a new PATCH version. Never re-run a failed tag job.

### Pattern: Manual Release Creation (Orphan Tags)
- **Scenario**: Git tags exist but no GitHub Release was created.
- **Remediation**: Manually finalize the release in the UI, selecting the existing tag and attaching assets from CI artifacts.

### Pattern: Version Authority Alignment
- **Scenario**: Code manifests have a higher version than the latest tag.
- **Remediation**: Revert manifests to match the highest tag and restart from that converged point.

---

## 4. Distribution Case Studies

### Case Study: The "Ghost Release" (ODTO v0.3.2)
- **Symptom**: Release created successfully but NO binaries were attached.
- **Root Cause**: `upload-assets` was not gated on build completion.
- **Remediation**: Implemented the **Artifact Validation Gate**.

### Case Study: The "Permission Deadlock" (GH013)
- **Symptom**: Release pipeline failed with "Repository rule violation".
- **Root Cause**: Strict branch protection vs `GITHUB_TOKEN`.
- **Remediation**: Standardized on **Admin Bypass Secrets**.

### Case Study: The "Bash Backslash Trap"
- **Symptom**: Binary paths corrupted in Windows installers.
- **Root Cause**: Shell expansion differences in Linux bash runners.
- **Remediation**: Standardized on **PowerShell Core (pwsh)** for path orchestration.
---

## 5. Lockfile & Dependency Promotion

### Pattern: The Locked-Verify Loop
- **Goal**: Prevent dependency drift and CI failures in high-integrity environments.
- **Strategy**: 
    1. Developers MUST run `cargo update` locally after changing `Cargo.toml`.
    2. The commit MUST contain both the updated manifest AND the synchronized lockfile.
    3. CI runners MUST use `--locked` to guarantee that the verified dependency graph is identical to the developer's environment.

### Pattern: Transitional Promotion (The "Relaxed Probe")
- **Scenario**: Adding a new dependency in a branch.
- **Remediation**: If a specialized gate (like `test-packaged`) fails due to lockfile mismatch, the fix MUST be applied to the branch's primary lockfile, not by relaxing the CI gate.
