# Strategic Roadmaps & Initiatives

This document consolidates the key strategic initiatives for the expansion and hardening of the Repository Standards Framework.

---

## 1. Bazel Integration as a Build Executor Substrate

The goal is to treat Bazel as a *build/execution substrate* while maintaining existing CI platforms (GitHub Actions, Azure DevOps).

### Core Concepts
- **Build Executor Model**: Introduce an `executionModel` derived property. Prefer Bazel if root-level markers are detected.
- **Repo Detection**: Root-level and deterministic (`MODULE.bazel`, `WORKSPACE`).
- **Target Mapping**: Recommended conventions for `bazel test //...`, `bazel coverage //...`, etc.

### Status (v2.0.0 Launched)
- **Schema Extensions**: Added `BazelHints` and `bazelIntegration` metadata.
- **Detection Harness**: Implemented `detect-bazel.ts` with regression fixtures.
- **Command Templates**: Integrated stack-specific templates (lint, test, build).
- **CI Portability**: Standardized flags (`--config=ci --build_tests_only`) and artifact collection.

---

## 2. Rust and Go Stack Extension

Expanding the framework to provide first-class governance artifacts for Rust and Go.

### Objectives
1. **Extended Registry**: Add `rust` and `go` to `StackId`.
2. **Idiomatic Tooling**: Map authoritative tools (`clippy`, `rustfmt`, `golangci-lint`, `go test`).
3. **CI Templates**: Provide Azure DevOps and GitHub Actions stage definitions.

### Status (Phase 3 Completed)
- **Master Spec**: Populated with 15+ hints per stack.
- **Build Pipeline**: Generates 6 new artifacts per stack.
- **Unified Checklist**: Items like "Git and Docker Ignore Files" or "Semantic Versioning" are updated with language-specific guidance.

---

## 3. Schema Hardening & Versioning Strategy

Ensuring the `standards.json` specification is machine-verifiable, deterministic, and version-safe for downstream consumers.

### Structural Integrity (v3)
- **Strict Mapping**: Transition to `anyOfFiles` for conditional requirements (e.g., Renovate OR Dependabot).
- **Ratio Policy**: Move from percentages to ratios (0.8 = 80%) for coverage thresholds to prevent scale ambiguity.
- **Uniqueness**: Enforce globally unique checklist item IDs across all sections.

### Implementation Status
- **Strict Validation**: AJV-based strict mode validation in `scripts/validate-standards.ts`.
- **Manifest Sync**: Automated build-time synchronization with `package.json` version.
- **Stable Stringify**: Deep-sorting logic ensures byte-for-byte identical output for CI reproducibility.

---

## 4. Dependency Management Automation

Integrating automated dependency management (Renovate/Dependabot) into the governance checklist.

### Requirements
- **anyOfFiles**: Support either `renovate.json` OR `.github/dependabot.yml`.
- **Platform Agnostic**: Recommend Renovate for non-GitHub environments (Azure DevOps).
- **Governance**: Added `dependency-update-automation` to the recommended checklist.

### Status
- **Detection Patterns**: Established `isRenovateConfig` and `isDependabotConfig` patterns.
- **CI Integration**: Provided self-hosted runner snippets for Azure DevOps.
