# Agent Safety Criteria for Repositories

To be considered a "Safe Operating Environment" for autonomous agents, a repository should implement the following hardened patterns and safety gates. See `dapr_repository_analysis` for a real-world gold-standard example.

## 1. Resource & Lifecycle Isolation
- **PID-Scoped Cleanup**: Use authoritative process tracking (like Invariant B4) to ensure all sidecar processes (e.g., port-forwards, proxies) are terminated by PID. This prevents "Ghost Ports" and environment pollution.
- **Deterministic Shutdown**: Implement a multi-stage shutdown protocol (e.g., `Ctrl+Q` Safe Shutdown) that explicitly tears down tunnels, infrastructure, and core services in order.
- **Hermetic Build Mirrors**: Avoid external registry drift or TLS failures by using repo-local or internal mirrors with SHA256 integrity verification (e.g., Bazel GitHub Releases mirror).

## 2. CI/CD Safety Gates
- **Lockfile Enforcement**: Mandatory validation that lockfiles (e.g., `npm-lock.json`, `MODULE.bazel.lock`) match the repository state to prevent supply chain drift during autonomous operations.
- **Dockerfile Context Parity**: Enforce that Docker build contexts match expectation (B1 Invariant) to prevent accidental inclusion of host-sensitive files or incorrect build inputs.
- **Cross-Platform Verification**: Scripts (especially those using platform-specific shell logic like PowerShell) must be verified on all target OSs in CI to ensure consistent behavior regardless of the agent's host.

## 3. Observability & Feedback
- **Self-Diagnostics**: Include "Doctor" commands or health-checks that allow an agent to verify the sanity of its environment before starting a task.
- **Structured Progress Streaming**: Tools should provide machine-readable feedback (JSON logs, progress indices) so agents can detect stalls or failures without parsing raw stdout.

## 4. Documentation & Constraints
- **Invariants**: Explicitly document system invariants (safety constraints) that must hold true at all times.
- **Schema-First Contracts**: Use JSON Schema or similar contract layers to define valid system states and event envelopes, allowing agents to validate their outputs before submission.

## 5. Durable Documentation & Visualization
- **Semantic Rendering**: Decouple visual styling (link indices, colors) from semantic intent in diagrams. Documentation tools should infer meaning from graph structure or tokenizer-first strategies rather than fragile rendering hacks or unstable internal ASTs.
- **Architectural Traceability**: Maintain a 1:1 mapping between code structure (imports, exports) and visual documentation to ensure 'Architecture as Source of Truth'.
- **Resilient Tooling**: Documentation generators should treat formats like Mermaid as compiler targets, ensuring output remains stable and directional even across tool version upgrades.
