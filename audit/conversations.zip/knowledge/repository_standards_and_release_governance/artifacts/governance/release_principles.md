# Release and Versioning Principles

The following principles govern the automated release and versioning strategy for all high-integrity @oddessentials projects.

## 1. Commit-Driven Versioning
Versioning must be driven purely by commit history using **Conventional Commits** (`feat:`, `fix:`, `feat!:`, etc.). Manual version bumps are prohibited to ensure that changelogs and SemVer are always in sync with actual changes.
- **Trigger Logic**: `feat:` triggers a MINOR bump; `fix:` triggers a PATCH bump.
- **Pre-1.0 Behavior**: In `0.x.y` releases, a `BREAKING CHANGE:` footer typically triggers a MINOR bump rather than a MAJOR bump, standardizing safety during the bootstrap phase.
- **Consolidation**: Both features and breaking changes in a single branch merge will trigger the highest applicable version increase (MINOR).

## 2. Manifest Synchronization
In polyglot monorepos, multiple manifests (e.g., `package.json`, `Cargo.toml`, `pyproject.toml`) and plain-text metadata (e.g., `VERSION`, `install.sh`) must be kept bit-for-bit identical. Use `@semantic-release/exec` in the `prepare` phase to automate this propagation.

## 3. Explicit Job Gating
Release publication must be gated on binary builds, and binary builds must be gated on the successful detection of a new release.
- **Principle**: Never build artifacts unless a release is guaranteed.
- **Hardening**: Use explicit string equality checks for job conditions (e.g., `if: needs.release.outputs.new_release_published == 'true'`) to avoid the Boolean String Trap.

## 4. Permission Hermeticity
Release workflows require explicit permission scoping to avoid "Last-mile" delivery failures.
- **Principle of Least Privilege**: Grant only `contents: write`, `issues: write`, and `pull-requests: write`.
- **Admin Bypass**: If branch protection is strict, use a Personal Access Token (PAT) with a clear bypass actor in GitHub Rulesets to avoid `GH013` (Repository Rule Violation) deadlock.

## 5. Metadata Visibility
Every release job must unconditionally echo its inputs and gated variables to the log before beginning. This ensures that "skipped" jobs are diagnosable as either logic errors (version not bumped) or infra errors (condition mismatch).

## 6. Atomic Commits
Manifest bumps and their respective lockfiles (e.g., `Cargo.lock`, `pnpm-lock.yaml`) must be committed atomically in the release commit. Automated tools must be configured to refresh and stage all relevant lockfiles to prevent `--locked` build failures in downstream CI.

## 7. Shell Standardization (PowerShell)
Given the project's cross-platform requirements, **PowerShell (`pwsh`)** is the authoritative shell for CI/CD orchestration and manual maintenance scripts. This ensures that path handling, environment variable expansion, and string manipulation remain consistent across Windows, macOS, and Linux runners, preventing environment-specific escaping vulnerabilities (e.g., the Bash Backslash Trap).
