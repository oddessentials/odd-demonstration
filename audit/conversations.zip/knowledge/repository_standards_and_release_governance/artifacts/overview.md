# Repository Standards & Release Governance Overview

This Knowledge Item consolidates the **Repository Standards Framework** (`@oddessentials/repo-standards`) and the **Automated Release Governance** standards. It provides a polyglot-first governance model for managing multi-stack repositories, ensuring consistency in quality gates, and maintaining high-integrity binary distribution.

## Core Philosophical Pillars

1.  **Consistency**: Multi-stack repositories (TypeScript, Rust, Python, Go, etc.) MUST follow a baseline set of quality, security, and rendering rules.
2.  **Container Parity**: Environments MUST achieve 1:1 service parity (Prometheus/Grafana) and authoritative asset bundling to ensure visual regression fidelity.
3.  **Release-First Distribution**: Distribution integrity is a fundamental architectural invariant. Releases must be **Atomic**, **Fail-Closed**, and **Traceable**.
4.  **Hermetic Verification**: CI harnesses MUST be self-contained (Docker Compose), resource-disciplined, and hardened against parallelism hazards (e.g. Session Cap Hazards).

## Key Framework Components

-   **Master Specification**: An authoritative JSON file managing checklists, stack-specific hints, and meta-policies.
-   **Hardened Testing Patterns**: Authoritative strategies for WebSocket Mocking (Failure Injection), Parallelism-Aware Resource Partitioning, and Viewport-Driven Scaling.
-   **Release Safety Gates**: 66+ exhaustive security and integrity gates preventing "Ghost Releases" and permission deadlocks.
-   **Execution Model**: Standardized execution substrates, prioritizing **Bazel** for hermetic builds and **pwsh 7+** for cross-platform parallel execution.

## Navigation

### General Repository Standards
- [Architecture: Generation Pipeline](./architecture/generation_pipeline.md)
- [Implementation: Hardened Testing Patterns](./implementation/hardened_testing_patterns.md)
- [Implementation: Container Fidelity Patterns](./implementation/container_fidelity_patterns.md)
- [Implementation: Metadata Integrity Patterns](./implementation/metadata_integrity_patterns.md)
- [Implementation: Automated Documentation Sync](./implementation/automated_documentation_sync.md)
- [Implementation: Polyglot Adoption Patterns](./implementation/polyglot_adoption_patterns.md)
- [Implementation: Environment Parity Governance](./implementation/environment_parity_governance.md)
- [Implementation: Cross-Platform Orchestration Hardening](./implementation/cross_platform_orchestration.md)

### Release Governance & Integrity
- [Architecture: Multi-Job Release Cycle](./architecture/release_cycle_architecture.md)
- [Governance: Release Principles](./governance/release_principles.md)
- [Implementation: Safety Gates Inventory](./implementation/safety_gates_inventory.md)
- [Implementation: Binary Distribution Patterns](./implementation/distribution_patterns.md)
- [Implementation: Distribution Case Studies](./implementation/distribution_case_studies.md)
- [Implementation: Release Recovery Patterns](./implementation/recovery_patterns.md)
