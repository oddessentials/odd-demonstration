# Architecture: Generation Pipeline

The framework uses a "Master to Artifact" pattern to ensure consistency across polyglot environments while providing focused documentation for developers.

## 1. Master Specification (`standards.json`)

The master JSON follows a hierarchical structure:
- **`meta`**: Defines global constants like `defaultCoverageThreshold` and high-level policies.
- **`stacks`**: Registry of supported languages (e.g., `typescript-js`, `python`).
- **`checklist`**: Grouped into `core`, `recommended`, and `optionalEnhancements`.
    - Each item contains common `description` and `label`.
    - **`stackHints`**: Language-specific details (tools, config files, verification commands, scripts).

## 2. Generation Logic (`generate-standards.ts`)

The generation script filters the master spec based on two dimensions:
1. **Target Stack**: Only items that apply to the stack are included, and the relevant `stackHints` are promoted to the top level.
2. **CI System**: Filters `ciHints` (stage/job names) for the specified provider (e.g., GitHub Actions vs. Azure DevOps).

## 3. Build Process (`scripts/build.ts`)

The build process automates the creation of all permutations:
- For each stack:
    - Generates `standards.{stack}.json` (generic).
    - Generates `standards.{stack}.{ci}.json` for each supported CI system.
- **Deterministic Output**: The build script recursively sorts JSON keys to ensure that git diffs remain clean when the master spec is updated.
