# Automated Release Architecture

The release pipeline utilizes a high-integrity, multi-job GitHub Actions workflow (`release.yml`) integrated with `semantic-release`. This architecture ensures atomic versioning, artifact consistency, and CI efficiency.

## 1. Core Workflow Stages (release.yml)

To maximize parallelism and resource efficiency, the workflow is partitioned into distinct functional jobs.

```mermaid
sequenceDiagram
    participant SR as semantic-release job
    participant Build as Build job (5-10 min)
    participant Upload as upload-assets job
    
    Note over SR: High-Integrity "Workflow-as-Publisher"
    SR->>SR: Analyze commits, determine next version
    SR->>SR: Update VERSION, Cargo.toml, package.json
    SR->>SR: Create git tag v0.x.x
    SR-->>Build: Job completes, triggers build
    Build->>Build: Build binaries for all platforms
    Build->>Upload: Artifacts ready
    Upload->>Upload: softprops/action-gh-release runs
    Note over Upload: Job CREATES the Release object<br/>with all binaries attached
```

### 1.1 Version Detection & Tagging (`release`)
- **Engine**: `cycjimmy/semantic-release-action`
- **Responsibility**:
  - Inspects commit history using Conventional Commits.
  - Automatically calculates the next version and creates the Git tag.
  - Generates release notes.
- **Output**:
  - `new_release_published`: Boolean signal for subsequent jobs.
  - `new_release_version`: Calculated SemVer (e.g., `0.3.3`).
  - `new_release_git_tag`: Canonical tag (e.g., `v0.3.3`).
  - `new_release_notes`: Automated changelog notes.
- **Benefit**: Replaces fragile manual output parsing with a robust, action-maintained interface.

### 1.2 Multi-Platform Build (`build`)
- **Matrix**: Parallel builds across all supported targets (Windows x64, macOS x64/ARM64, Linux x64/ARM64).
- **Metadata**: Injects build-time info (`BUILD_COMMIT`, `BUILD_TIMESTAMP`) via language-specific build scripts (e.g., Rust `build.rs`).
- **Parity Strategy**: The `--locked` or `--frozen` flags are often omitted during release builds to ensure success across the matrix without requiring OS-specific lockfile commits for every minor version bump, provided a "Shift-Left" gate has verified parity on the authoritative OS.

### 1.3 Manifest Generation (`checksums`)
- **Responsibility**: Collects all binaries from the `build` job and generates a unified `SHA256SUMS` manifest.

### 1.4 Artifact Validation (`verify`)
- **Responsibility**: High-integrity gate that checks the staging area for the exact expected artifact count. It fails the pipeline if any build failed or disappeared, preventing "Partial Releases."

### 1.5 Global Publication (`upload-assets` & `npm-publish`)
- **GitHub Release Assets**: Attaches verified binaries and manifests to the newly created tag. **Pattern**: The workflow uses `softprops/action-gh-release` to *create* the GitHub Release object with all binaries attached. This job takes full responsibility for publication, ensuring binaries are present BEFORE the release is visible to users.
- **Registry Publication**: Updates and publishes package versions (e.g., npm) asynchronously but keyed to the same SemVer.

## 2. Version Authority & Propagation

The system enforces a **Single Source of Truth** pattern:

1.  **Input**: Commit history determines the SemVer.
2.  **Manifest Update**: The `release` job (Stage 1.1) propagates this number via `@semantic-release/exec` to:
    - `VERSION` files (plain text).
    - `Cargo.toml` / `package.json` / `pyproject.toml`.
3.  **Bootstrap Synchrony**: Audit scripts verify that all installers and binaries correctly reference or derive from this authority.

## 3. Key Invariants

- **Atomic Release**: All distribution channels are updated in a single workflow run, with GitHub Release creation deferred until binaries are built.
- **Decoupled Publication (Workflow-as-Publisher)**: The `@semantic-release/github` plugin is **excluded** from `.releaserc.json` to prevent the "Timing Trap" where an empty release is created before builds finish.
- **Dry-run Gating**: No platform binaries are built unless a new version is confirmed.
- **Environment Protection**: Secrets (e.g., `RELEASE_TOKEN`, `NPM_TOKEN`) are scoped to a protected `release` environment restricted to official tag patterns.
- **Checkout depth**: `fetch-depth: 0` is mandatory for correct history analysis.
