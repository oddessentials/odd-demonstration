# ODTO Governance, Contracts, and Invariants

This document serves as the authoritative source for the Distributed Task Observatory (ODTO) governance principles, contract authority, and invariant management. It consolidates the feature coverage matrix, core engineering standards, and historical audits.

## 1. Core Governance Principles

ODTO operates under a high-integrity engineering model where specification precedes implementation.

- **Contract-First**: Contracts (`/contracts`) are the single source of truth. Services do not define their own APIs.
- **Commit-Driven SemVer**: Versioning is strictly driven by Conventional Commits (`feat:`, `fix:`, `BREAKING CHANGE:`).
- **Shell Standardization**: **PowerShell Core (pwsh 7+)** is the authoritative shell for cross-platform CI/CD orchestration.
- **Implementation Plan Mandate**: Non-trivial changes require a formal documented plan before execution. For critical bug fixes, a **Just-in-Time (JIT) Plan** must precede the fix to ensure invariant verification is not bypassed.
- **Shortcut Elimination Policy**: Usage of `:latest` or `:local` tags is prohibited for core services. Every component MUST have an authoritative `VERSION` file.
- **Root Cause Discipline**: All failures must be traced to their mechanical or environmental root causes.

## 2. Invariant & Enforcement Map

| ID | Category | Invariant | Automated Check | Status |
|----|----------|-----------|-----------------|--------|
| **C1-5** | **Contracts** | Messages/Jobs conform to schema, versioning, documentation. | `validate-contracts.ps1`, `test-contracts-sanity.py`, `check-schema-compat.py` | ✅ CI |
| **X1-4** | **X-Platform** | Linux pwsh execution, no hardcoded paths/bashisms. | CI `shell: pwsh`, manual review. | ✅ CI |
| **V1-7** | **Coverage** | Service-specific coverage floors (80% for critical paths). | `check-coverage.py`, `vitest`, Playwright. | ✅ CI |
| **I1-7** | **Integration**| Gate on change, self-contained, <180s budget, parity validation. | `integration-harness.ps1`, `validate-compose-k8s-parity.ps1` | ✅ CI |
| **A1-3** | **Automation** | Hermetic Bazel builds, no manual intervention, single entrypoint. | Bazel lockfile, `run-all-tests.ps1`. | ✅ CI |
| **B1-4** | **Docker Context**| Repo-root context, repo-relative paths, no :latest fallback, script root resolution. | `start-all.ps1` fail-fast logic. | ✅ CI |

### 2.1 Authoritative Budget Baseline
The **Integration Runtime Budget (Invariant I4)** is established as **180 seconds** (wall-clock). This baseline is enforced across `INVARIANTS.md`, `TESTING.md`, and all orchestration scripts.

## 3. Contract Authority Model

The `/contracts` directory contains the authoritative JSON schemas for the entire system.

- **Event Envelope**: `/contracts/schemas/event-envelope.json`. Standard wrapping for RabbitMQ traffic.
- **Job Domain Model**: `/contracts/schemas/job.json`. Central entity tracking task state.
- **UI Registry**: `contracts/ui-registry.json`. Service discovery map for dashboard access points.

## 4. Feature Coverage Matrix (v3.1.15)

Tracks the alignment between claimed features and automated verification.

| Component | Feature | Verification Status | Proof Location |
|-----------|---------|---------------------|----------------|
| **TUI** | Guided Setup | ✅ Covered | `doctor.rs` (331+), `install.rs` |
| **TUI** | Cluster Launcher | ⚠️ Partial | `cluster.rs:289` (Implementation exists; unit tests pending) |
| **TUI** | Real-time Stats | ✅ Covered | `types.rs:531` |
| **Web** | Session Reconnect | ✅ Covered | `session.rs::test_reconnect_*` |
| **Web** | Fallback Dashboard| ✅ Covered | `terminal.spec.ts:163` |
| **PTY** | Resource Limits | ✅ Covered | `session.rs::test_per_ip_cap` |
| **PTY** | Authentication | ✅ Covered | `auth.rs::test_auth_*` |
| **PTY** | Keepalive (R6) | ✅ Covered | `main.rs:330-469` (Ping/Pong) |
| **PTY** | Coalescing (R9) | ✅ Covered | `main.rs:336-450` (16ms buffer)|
| **Web** | Capabilities (R7)| ✅ Covered | `pty.rs` (TERM=xterm-256color) |

## 5. Coverage & Verification Lifecycle (Paradox Management)

### 5.1 The TUI Coverage Paradox
The TUI (`src/interfaces/tui`) reports ~31% coverage because its massive entrypoint (`main.rs`)—containing ~33% of the codebase—is excluded from `cargo tarpaulin` due to high side effects. Business logic in modules (`types`, `cluster`, `doctor`, `install`) approaches 100% coverage. Invariant **V4 (TUI lib coverage ≥ 31%)** reflects this split.

### 5.2 Tiered Verification Hierarchy
To achieve full high-fidelity verification without flakiness:
- **Tier 1 (CI)**: Fast Bundle Smoke Tests.
- **Tier 2 (Nightly)**: Visual regression suite in `tests/visual/`.
- **Tier 3 (Fallback)**: Protocol-level edge cases via server-side failure injection.

## 6. Audit & Reconciliation Records

### 6.1 2025-12-27 Feature Reconciliation
- **Feature Gap Correction**: Discovered that 7 features previously marked as "Gap" (Stats, Alerts, Clipboard) were actually implemented and tested.
- **Dependency Isolation**: Verified root `.gitignore` correctly anchors `node_modules/`, `target/`, and `__pycache__/`.
- **Lockfile Policy**: Confirmed `Cargo.lock` is tracked for binary crates (Invariant **A1**) for reproducible release builds.

### 6.2 2025-12-28 Architecture Audit
- **Requirement Audit**: Identified and corrected six semantic errors in Mermaid diagrams where data flow arrows were reversed (Read Model pulls from Postgres/Mongo/Redis, Grafana pulls from Prometheus, Prometheus scrapes Metrics Engine, and Metrics Engine consumes from RabbitMQ).
- **Verified Paths**: Confirmed **Processor → PostgreSQL** write flow and **Processor → RabbitMQ** completion emission are correctly documented.
