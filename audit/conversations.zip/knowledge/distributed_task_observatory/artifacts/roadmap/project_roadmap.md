# Project Implementation Roadmap

This document tracks the phased execution of the Distributed Task Observatory (ODTO), ensuring the Contract Authority and Platform Infrastructure are established before microservice scaling.

## 1. High-Level Status

| Phase | Milestone | Status | Key Outcomes |
|---|---|---|---|
| **0-1** | Foundation & Contracts | [DONE] | Bazel, JSON Schemas, K8s cluster, RabbitMQ/Postgres/Redis baseline. |
| **2-4** | Core Flow & Read Model | [DONE] | Node.js Gateway, Python Processor, Go Metrics Engine, Go Read Model. |
| **5-10**| Interfaces & Hardening| [DONE] | Rust TUI, Web UI, Diagnostic logging, Error taxonomy. |
| **11-20**| Vers. & Orchestration | [DONE] | SemVer alignment, TUI Cluster Launcher, Integrated UI Launcher. |
| **21-22**| Release & Distribution| [DONE] | Semantic-release, Multi-platform binaries, npm shim, SHA256 verification. |
| **23-26**| Global Coverage Cycle | [DONE] | Processor (88%), Gateway (87%), TUI lib (32%) coverage targets met. |
| **27-31**| xterm.js Web Terminal | [DONE] | PTY Multiplexing, Durable sessions (reconnect), Visual regression suite. |
| **32-33**| Build context & Vers. | [DONE] | Docker build context normalization, CI version alignment enforcement. |
| **34** | Feature Gap Coverage | [DONE]  | Hardened TUI error paths and verified 15/15 features. |
| **35** | Document Alignment | [DONE]  | 2025-12-28 Architecture Audit (fixed 4 reversed data flows). |

---

## 2. Phase 34: Feature Gap Coverage Checklist

### Phase 1: Planning & Verification [COMPLETE]
- [x] Review `audit/` directory for feature claims.
- [x] Verify source code existence for all 15 core features.
- [x] Audit existing test suite (`types.rs`, `install.rs`, `doctor.rs`).
- [x] Correct inaccurate gap claims in `docs/FEATURES.md`.

### Phase 2: Execution - Quality Hardening [COMPLETE]
- [x] Add `open_browser()` error path tests to `src/interfaces/tui/src/cluster.rs`.
- [x] Add terminal environment variable tests to `src/services/web-pty-server/src/pty.rs`.
- [x] Add output coalescing buffer test to `src/services/web-pty-server/src/main.rs`.
- [x] Enable `Web Terminal Visual Tests` in nightly workflow.
- [x] **2025-12-28 Architecture Audit**: Fixed reversed arrows for ReadModel/Postgres, Grafana/Prometheus, Metrics/Prometheus, and Metrics/RabbitMQ.

---

## 3. Implementation History Summary

- **Phase 21 (Distribution)**: Transformed TUI into a high-integrity distributed binary with doctor/install automation.
- **Phase 27 (xterm.js)**: Replaced legacy mirror with high-fidelity terminal emulator using PTY multiplexer and Bearer auth.
- **Phase 29 (Durable Sessions)**: Integrated `Connected→Disconnected→Idle→Reaping` state machine for PTY survival.
- **Phase 32 (Docker Context)**: Established "Mixed-Context Build Lifecycle" standard mapping services to specific build contexts (`.` vs service-dir).
