# Distributed Task Observatory — Overview

The **Distributed Task Observatory** is a self-contained, local-first demonstration platform that shows how modern, production-grade distributed systems are built, operated, and understood.

## Core Mission
The platform makes the "invisible visible." While the task being processed is deliberately simple, the complexity and value lie in the surrounding infrastructure:
- **Contracts**: Ensuring interoperability across polyglot services using versioned JSON schemas.
- **Observability**: Real-time metrics via Prometheus, historical audit logs via MongoDB, and visual dashboards via Grafana and high-performance UIs.
- **Platform Discipline**: Using industry-standard tools (`kind`, `kubectl`, Docker) for local development that mirrors production-grade Kubernetes topologies.

## Implementation Guides

- [Implementation: Infrastructure & Orchestration](./implementation/infrastructure_and_orchestration.md)
- [Implementation: Service Credentials & Access Points](./implementation/service_credentials.md)
- [Implementation: Build Context Verification](./implementation/build_context_verification.md)
- [Implementation: Port-Forward Recovery](./implementation/port_forward_recovery_implementation.md)
- [Implementation: TUI Shutdown Feature](./implementation/shutdown_implementation_plan.md)
- [Implementation: Troubleshooting & Operations](./implementation/troubleshooting_and_ops.md)

## Audits & Verification

- [Audit: Architecture Diagram Verification](./audit/architecture_diagram_verification.md)
- [Audit: Feature Reconciliation](./audit/feature_reconciliation_2025_12_27.md)
- [Audit: Session Analysis](./implementation/complete_session_audit.md)

## Performance & Visibility
- **Polyglot Stack**: Node.js, Python, Go, and Rust services.
- **Current Status**: All core implementation phases (0-33) are complete. This includes the unified `odd-dashboard` binary with high-integrity installers and a **modularized TUI architecture**. The Phase 27 **Modernized Web Interface** replaces the legacy dashboard with a high-fidelity **xterm.js PTY Mirror**, achieving 1:1 visual parity with the terminal via a Rust-based PTY multiplexer. Phase 29 finalized **Durable Session Mirroring**, achieving zero-flicker restoration through sequence-aware persist-and-replay. Phase 31 (v3.1.5) established **High-Fidelity Tiered Verification**, finalizing the **Container Contract (W11)** with Zero-Probe Server Mode, Authoritative **Registry Bundling**, and **Server-Side Failure Injection** (?test_mode=fail). Phase 32/33 (v3.0.2) resolved critical **Docker Build Context** and **Image Tag Drift** failures, standardizing **Mixed-Context Build Lifecycles** and the **Shortcut Elimination Policy** (:latest removal). The repository maintains strict coverage targets: **88%** Processor, **32%** TUI Lib, **87%** Gateway, and **81.12%** PTY Server. Visual testing is stabilized via a **Tiered Test Strategy** (Smoke, Nightly, Fallback), eliminating CI flakiness and environment races.
- **Repository Naming**: While the repository is named `odd-demonstration`, it functions as the definitive `odd-dashboard` platform. The naming is preserved for historical context while the binary and UI reflect the "Dashboard" identity.
- **Hybrid Build Strategy**: Primarily Docker-native with root-context builds for local development, and **Docker Hub Pre-built Images** for CI integration tests to ensure deterministic performance and artifact capture (Invariants I3-I5). The **Phase 19 Integration Hardening** cycle successfully stabilized the CI pipeline, achieving a 19.2s total wall-clock runtime through **Symmetric Dependency Retries** and **Bounded State Polling**. The build system is further hardened by the **Deterministic Tag Alignment** (I7) invariant—enforced via the **Shortcut Elimination Policy**—and the **Mixed-Context Build Lifecycle** pattern.
- **Multi-Layer Data stack**: 
    - **PostgreSQL**: Relational authoritative state.
    - **Redis**: Fast-access aggregated metrics.
    - **MongoDB**: Raw event document store for historical audit trails.
- **UI**: High-performance Rust TUI (ratatui) and an xterm.js-based terminal mirror for the browser.

## Key Differentiators
- **Zero Cloud Dependency**: Runs entirely in the terminal/local machine using `kind`.
- **Integrity Gates**: Includes automated PowerShell scripts to verify the entire system, from message bus throughput to multi-database consistency.
- **Observability-First**: Metrics and audit logs are not afterthoughts; they are the primary drivers for system reliability.
- **Developer Experience (DX) Focus**: Beyond standard CI/CD, the platform emphasizes a "Zero-Touch" onboarding experience where the UI itself (TUI/Web) can detect environmental gaps and automate the entire Kubernetes cluster initialization and deployment cycle.
- **Self-Launching Application Pattern**: A dedicated architectural pattern where orchestration is integrated into the application's runtime, providing real-time progress via structured JSON streaming.
- **Two-Tier Documentation**: A concise, advanced-user `README.md` focusing on the TUI launcher, supported by a detailed `README_beginner.md` for full manual walkthroughs.

---

> **Note on Phase Numbering**: The project audit logs (e.g., `/audit/session-summary.md`) refer to the Add Task/UI Launcher work as **Phase 13**, Distribution as **Phase 14**, TUI Modularization as **Phase 15**, Testing Optimizations as **Phase 17**, and Go Coverage Remediation as **Phase 18**. This Knowledge Item tracks them as **Phase 20**, **Phase 21**, **Phase 22**, **Phase 23** etc. respectively.
