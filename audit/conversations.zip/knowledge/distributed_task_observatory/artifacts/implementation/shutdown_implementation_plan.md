# Shutdown Feature Implementation Plan

Add a "Shutdown" feature to the TUI dashboard and web mirror that safely stops the cluster, cleans up port-forwards, and exits the TUI.

## 1. Authoritative Requirements

> [!IMPORTANT]
> **Key Binding**: Use **Ctrl+Q** for Shutdown. 'Quit' (plain `Q`) remains non-destructive.
>
> **Web Mirror Behavior**: Disconnected status is intended upon shutdown. A **test is required** to prove the retry button works or that a safe auto-retry interval (e.g., every 20s) triggers the reconnect path without hanging.
>
> **Confirmation Prompt**: A confirmation prompt will be added **later** (not in the first pass), and it **must have a test**.

---

## 2. Shared Configuration (Source of Truth)

To prevent drift between cluster creation, status checking, and deletion, the cluster name must be centralized in `src/interfaces/tui/src/types.rs`:

```rust
// ============================================================================
// Cluster Configuration Constants (Single Source of Truth)
// ============================================================================

/// Cluster name used by Kind - must match start-all.ps1 and all kubectl commands
pub const CLUSTER_NAME: &str = "task-observatory";

/// Kubectl context derived from cluster name
pub const KUBECTL_CONTEXT: &str = "kind-task-observatory";
```

---

## 3. Proposed Changes

### 3.1 types.rs (IMPLEMENTED)

Add `AppMode::ShutdownProgress`, `ShutdownProgress` tracking, and the `PortForwardRegistry` for PID-scoped cleanup:

```rust
pub enum AppMode {
    Loading,
    Launcher,
    SetupProgress,
    Dashboard,
    TaskCreation,
    UiLauncher,
    PrerequisiteSetup,
    ShutdownProgress,  // Cluster shutdown in progress
}

/// Port-forward process tracking for clean shutdown
#[derive(Debug, Clone, Default)]
pub struct PortForwardRegistry {
    /// PIDs of port-forward processes started by this TUI instance
    /// (service_name, PID)
    pub processes: Vec<(String, u32)>,
}

// New struct for shutdown progress tracking
#[derive(Debug, Clone, Default)]
pub struct ShutdownProgress {
    pub current_step: String,      // e.g., "ports", "cluster"
    pub message: String,           // Status message
    pub is_complete: bool,
    pub has_error: bool,
    pub error_message: Option<String>,
    pub start_time: Option<std::time::Instant>,
}
```

### 3.2 cluster.rs (IMPLEMENTED)

Implement safe, PID-scoped cleanup and orchestrate the shutdown sequence.

**1. Scoped `stop_port_forwards()`:**

```rust
pub fn stop_port_forwards(registry: &Arc<Mutex<PortForwardRegistry>>) -> Result<(), String> {
    let pids: Vec<(String, u32)> = {
        let reg = registry.lock().map_err(|e| format!("Lock error: {}", e))?;
        reg.processes.clone()
    };
    
    if pids.is_empty() { return Ok(()); }

    #[cfg(target_os = "windows")]
    {
        for (_service, pid) in &pids {
            let ps_script = format!("Stop-Process -Id {} -Force -ErrorAction SilentlyContinue", pid);
            let _ = Command::new("powershell.exe")
                .args(["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", &ps_script])
                .output();
        }
    }

    #[cfg(not(target_os = "windows"))]
    {
        for (_service, pid) in &pids {
            let _ = Command::new("kill").args(["-TERM", &pid.to_string()]).output();
        }
    }

    if let Ok(mut reg) = registry.lock() { reg.processes.clear(); }
    Ok(())
}
```

**2. PID Tracking implementation (`start_port_forward_tracked`):**

The system uses a tracked version of port-forwarding to enable deterministic cleanup. A legacy bridge is maintained for backwards compatibility.

```rust
/// Start a kubectl port-forward as a background process (legacy compatibility)
fn start_port_forward(service: &str, port: u16) -> Result<(), String> {
    let dummy_registry = Arc::new(Mutex::new(PortForwardRegistry::default()));
    start_port_forward_tracked(service, port, &dummy_registry)
}

/// Start a kubectl port-forward as a background process and track its PID
pub fn start_port_forward_tracked(
    service: &str, 
    port: u16,
    registry: &Arc<Mutex<PortForwardRegistry>>,
) -> Result<(), String> {
    let port_arg = format!("{}:{}", port, port);
    
    #[cfg(target_os = "windows")]
    {
        let ps_script = format!(
            r#"$proc = Start-Process -WindowStyle Hidden -FilePath kubectl -PassThru -ArgumentList 'port-forward','svc/{}','{}','--context','{}'
Write-Output $proc.Id"#,
            service, port_arg, KUBECTL_CONTEXT
        );
        let output = Command::new("powershell.exe")
            .args(["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", &ps_script])
            .output()
            .map_err(|e| format!("Failed to start port-forward {}: {}", service, e))?;
        
        if let Ok(pid_str) = String::from_utf8(output.stdout) {
            if let Ok(pid) = pid_str.trim().parse::<u32>() {
                if let Ok(mut reg) = registry.lock() {
                    reg.processes.push((service.to_string(), pid));
                }
            }
        }
    }
    // ... Unix implementation uses child.id()
    Ok(())
}
```

**2. `delete_cluster()` using constant:**

```rust
pub fn delete_cluster() -> Result<(), String> {
    let output = Command::new("kind")
        .args(["delete", "cluster", "--name", crate::types::CLUSTER_NAME])
        .output()
        .map_err(|e| format!("Failed to run kind: {}", e))?;

    if output.status.success() {
        Ok(())
    } else {
        let stderr = String::from_utf8_lossy(&output.stderr);
        if stderr.contains("no clusters found") || stderr.contains("does not exist") {
            Ok(())
        } else {
            Err(format!("Failed to delete cluster: {}", stderr))
        }
    }
}
```

### 3.3 main.rs (IMPLEMENTED)

1. **Dashboard Input**: Capture **Ctrl+Q** (KeyCode::Char('q') with KeyModifiers::CONTROL) in `AppMode::Dashboard`. (Implemented with modifier precedence).
2. **Help Bar**: Update help text to include `^Q Shutdown`. (Implemented with Color::Red).
3. **Shutdown View**: Implement `render_shutdown_progress` and exit the application on completion if a key is pressed. (Implemented inline in main.rs).
4. **Exit Logic**: Exits the TUI on any key press once the `is_complete` flag is true in `ShutdownProgress`.

### 3.4 lib.rs (IMPLEMENTED)

Exported new types and functions to allow usage in `main.rs`:
- Types: `ShutdownProgress`, `PortForwardRegistry`, `CLUSTER_NAME`, `KUBECTL_CONTEXT`.
- Functions: `start_port_forward_tracked`, `stop_port_forwards`, `delete_cluster`, `run_shutdown`.

---

## 4. Web Mirror & Verification

### 4.1 terminal.js Enhancements (COMPLETE)

Implement a 20s auto-retry interval and manage it via `showTerminal` and `showFallback`:

```javascript
// CONFIG update
autoRetryInterval: 20000, 

// State update
let autoRetryTimer = null;

// showFallback enhancement
function showFallback() {
    // ...
    autoRetryTimer = setInterval(() => {
        console.log('Auto-retry: attempting reconnect...');
        retryConnection();
    }, CONFIG.autoRetryInterval);
}

// showTerminal enhancement
function showTerminal() {
    // ...
    if (autoRetryTimer) {
        clearInterval(autoRetryTimer);
        autoRetryTimer = null;
    }
}
```

**Exposed test hooks for Playwright:**

```javascript
// Test exposure
if (typeof window !== 'undefined') {
    window.__odtoTestHooks = {
        getConnectionStatus: () => ({
            connected: ws && ws.readyState === WebSocket.OPEN,
            sessionActive,
            reconnectAttempts,
            intentionalClose,
            autoRetryActive: autoRetryTimer !== null,
        }),
        simulateDisconnect: () => {
            if (ws) {
                intentionalClose = false;
                ws.close(1000, 'test-disconnect');
            }
        },
        triggerRetry: () => retryConnection(),
        getAutoRetryInterval: () => CONFIG.autoRetryInterval,
    };
}
```

### 4.2 Playwright Verification (`tests/visual/retry-on-disconnect.spec.ts`) (IMPLEMENTED)

Implemented deterministic tests using `__odtoTestHooks`:
- **State Exposure**: `getConnectionStatus()` returns live PTY and WebSocket state.
- **Disconnect Simulation**: `simulateDisconnect()` tests the fallback interval.
- **Retry Trigger**: `triggerRetry()` verifies button-to-backend connectivity without PTY lifecycle dependencies.


```typescript
test('auto-retry triggers after 20s interval', async ({ page }) => {
    await page.goto('/');
    await expect(page.locator('.connection-status.connected')).toBeVisible();
    
    await page.evaluate(() => (window as any).__odtoTestHooks.simulateDisconnect());
    await expect(page.locator('.connection-status.disconnected')).toBeVisible();
    
    // Wait for auto-retry
    await page.waitForTimeout(21000);
    const attempts = await page.evaluate(() => 
        (window as any).__odtoTestHooks.getConnectionStatus().reconnectAttempts);
    expect(attempts).toBeGreaterThan(0);
});
```

---

## 5. Verification Status

### 5.1 Automated Visibility (COMPLETE for TUI)
- [x] Unit tests in `types.rs` for `ShutdownProgress`, `PortForwardRegistry`, and cluster constants. (Verifies data structures and configuration single source of truth).
- [x] Unit tests in `cluster.rs` for `stop_port_forwards` and `delete_cluster`.
- [x] Compilation verify: `cargo check` and `cargo test` passing in `src/interfaces/tui`.
- [x] **Final Test Suite Result**: 167 passed, 0 failed, 1 ignored. (v3.1.20)
- [x] Verified `main.rs` event handling loop for destructive vs non-destructive quit.

### 5.2 Manual Verification (COMPLETE for TUI)
1. **Bootstrap**: Run TUI, launch cluster.
2. **Execution**: Press **Ctrl+Q** in Dashboard.
3. **Audit**: 
   - [x] Verify cluster is deleted via `kind get clusters`.
   - [x] Verify ONLY app-started port-forward processes (PIDs in registry) are gone.
   - [x] Verify TUI process exits cleanly after completion on any key press.

### 5.3 Web Mirror Verification (COMPLETE)
- [x] **Auto-Retry Test**: `retry-on-disconnect.spec.ts` verifies the 20s interval triggers reconnect logic.
- [x] **Manual Integration**: Verified that Ctrl+Q in the mirror (via PTY passthrough) triggers cluster shutdown, TUI exit, and browser disconnect state correctly.
- [x] **Documentation**: `README.md` updated with "Cleanup" instructions recommending TUI shutdown.

---

## 6. Final Delivery

- **Branch**: `feat/stop-cluster`
- **Commit Message**: Detailed message enumerating all TUI, web, and test changes.
- **Verification Status**: 167 tests passing (v3.1.20).
- **Status**: ✅ MERGED/COMMITTED

