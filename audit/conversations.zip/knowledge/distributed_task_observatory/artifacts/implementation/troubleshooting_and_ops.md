# Operational Insights & Troubleshooting

This document captures recurring patterns and solutions for issues encountered during the development of the Distributed Task Observatory.

## Kubernetes (kind) Dev Workflow

### Updating Images in a Running Cluster
When rebuilding a local image (e.g., `docker build -t gateway:latest ...`) and loading it into `kind`, common issues include:

1.  **Image Pull Errors**: Kubernetes might try to pull the image from a remote registry if the `imagePullPolicy` is not set correctly.
    - **Fix**: Always set `imagePullPolicy: Never` for local-only images.
2.  **Stale Pods**: Even after running `kind load docker-image`, existing pods continue to run the **previously loaded** version of the image.
    - **Fix**: Force a replacement of the pods to pick up the new image digest using `kubectl rollout restart`:
      ```powershell
      kubectl rollout restart deployment gateway processor
      ```
3.  **Endpoint 404s**: If a new route or metrics endpoint is added to the code but returns a 404 after deployment, it is often a sign that the pod is still running the old image version.

### Cascading Failures in Chained Commands
When running multiple build commands in a single line (e.g., `docker build ...; docker build ...`), shells like PowerShell execute them sequentially even if the first one fails. 
- **Incident**: A build failure in the first service went unnoticed because the second service built successfully, leading to a "Not Found" error during `kind load`.
- **Recommendation**: In PowerShell, use `if($?) { ... }` or separate the commands. In bash/PWSH, use `&&` to ensure the chain stops on the first error. Always verify image presence with `docker images` before attempting to load into `kind`.
- **Resolution**: Fix all compiler errors/warnings that Go 1.21+ treats as fatal. Verify the build result before attempting to use the image.

### Rust: Edition 2024 Dependency Conflict
- **Symptom**: `error: failed to download moxcms v0.7.11 ... feature edition2024 is required`.
- **Context**: Occurs during Rust builds (e.g., TUI or web-pty-server) when a dependency or its transitive dependencies (like `moxcms` via `arboard`) require the Rust 2024 edition.
- **Root Cause**: The Rust 2024 edition is not yet stabilized in the cargo versions used in the current images (e.g., 1.83.0). A recent update to the `arboard` crate (v3.0+) or one of its dependencies pulled in `moxcms` version 0.7.11+, which mandates the new edition. This specifically affected the `odd-dashboard` TUI which uses `arboard` for clipboard support.
- **Fix (Ratified: Option A)**: 
  1. **Pin Dependencies**: Use strict pinning (`=`) in `Cargo.toml` for the crate causing the issue to a version known to use Edition 2021 or 2018 (e.g., `arboard = "=2.1"`). This unblocks the CI toolchain (Cargo 1.83) without requiring immediate architectural changes.
  2. **Non-Essential Features**: Since `arboard` is only used in the interactive `PrerequisiteSetup` stage, and this stage is bypassed in `SERVER_MODE` (containers), the dependency is effectively non-essential for the mirror infrastructure.
- **Pattern**: For high-fidelity builds in an unstable ecosystem, always use the `=` operator for critical dependencies to prevent "ghost" build failures from transitive dependency shifts.

### arboard v2.1 Downgrade: API Mismatch
- **Symptom**: `error[E0308]: mismatched types ... expected String, found &String` when calling `set_text`.
- **Context**: Occurs when downgrading from `arboard` v3.x to v2.x to avoid higher-edition Rust dependencies.
- **Root Cause**: In `arboard` v3.x, `set_text` takes a `&str` (implicitly accepting `&String`). In `arboard` v2.x, the method signature for `set_text` takes an owned `String`.
- **Fix**: Convert the reference to an owned string or remove the borrow:
  ```rust
  // v3.x (borrow)
  clipboard.set_text(&cmd)
  
  // v2.x (owned)
  clipboard.set_text(cmd)
  ```
- **Verification**: Ensure the TUI builds correctly on the target toolchain (Cargo 1.83) after the fix.
### Zombie Cluster Cleanup
Occasionally, `kind delete cluster` may hang or fail to remove the underlying Docker containers. This prevents `setup-cluster.ps1` from creating a new cluster with the same name.
- **Incident**: The `delete` command hung, leaving containers in a partial state.
- **Fix (Windows/pwsh)**: Manually stop and remove all Docker containers filtering by the cluster name:
  ```powershell
  docker ps -a --filter "name=task-observatory" -q | ForEach-Object { docker stop $_; docker rm $_ }
  ```
- **Fix (Linux/macOS)**:
  ```bash
  docker ps -a --filter "name=task-observatory" -q | xargs -r docker stop | xargs -r docker rm
  ```
- **Verification**: Ensure `docker ps -a` returns nothing for the cluster prefix before re-running the setup script.

### Image Load Verification
When using `kind load docker-image`, the CLI may report that an image is "loading... not yet present on node".
- **Insight**: This is normal during the transfer process. However, if a pod fails with `ErrImagePull`, it usually means the image name in the manifest (e.g., `web-ui:latest`) does not match the tag used during `docker build`.
- **Precedence**: Local images loaded via `kind load` take precedence over remote registry pulls only if `imagePullPolicy: Never` or `imagePullPolicy: IfNotPresent` (provided the tag is not `:latest`).
- **Best Practice**: Always use `:latest` for local dev with `imagePullPolicy: Never` to guarantee the local build is used.
### Startup Race Conditions & AMQP Connectivity
In distributed environments, microservices often start faster than their infrastructure dependencies (RabbitMQ, Postgres).
- **Incident**: The Python `processor` service failed with `pika.exceptions.AMQPConnectionError` during initial deployment.
- **Error Pattern**:
  ```text
  File "/app/main.py", line 119, in main
    connection = pika.BlockingConnection(params)
  pika.exceptions.AMQPConnectionError
  ```
- **Root Cause**: The RabbitMQ container was in the `Running` state (process started) but the internal AMQP broker logic was still initializing, leading to refused connections.
- **Kubernetes Recovery**: This is typically handled by Kubernetes `CrashLoopBackOff` which restarts the pod until the dependency is ready.
- **Resilience Strategy**: Services should ideally implement internal retry logic (with backoff) for initial connections to avoid unnecessary container restarts and noise in the logs.

### Port Forwarding Bind Errors
When running multiple `kubectl port-forward` commands or restarting them quickly, address bind conflicts may occur.
- **Incident**: `error: unable to listen on any of the requested ports: [{3000 3000}]` or `bind: Only one usage of each socket address is normally permitted.`
- **Root Cause**: An existing terminal session or background process is already holding the port, or the socket is in a `TIME_WAIT` state.
- **Fix (Windows)**: Identify and kill the process holding the port:
  ```powershell
  Get-NetTCPConnection -LocalPort 3000 | Select-Object -ExpandProperty OwningProcess | ForEach-Object { Stop-Process -Id $_ -Force }
  ```
- **Fix (Linux/macOS)**:
  ```bash
  lsof -i :3000 -t | xargs kill -9
  ```
- **Quick Cleanup (All Platforms)**: Terminate all `kubectl port-forward` processes:
  ```bash
  # Windows (pwsh)
  Get-Job | Stop-Job | Remove-Job
  # macOS/Linux
  pkill -f "kubectl port-forward"
  ```
- **Precedence**: Ensure all previous port-forward processes are terminated before attempting a clean restart for verification.

### RedisInsight Connectivity Issues (v1.1.1)
- **Symptom**: http://localhost:8001 fails to load with "Connection Refused" (ERR_CONNECTION_REFUSED), even though the TUI/Scripts report the system is "READY".
- **Diagnosis**: 
    1. Check pod status: `kubectl get pods -l app=redisinsight` (should be `Running`).
    2. Check service: `kubectl get svc redisinsight` (should be `ClusterIP: 8001`).
    3. Verify port-forwarding processes: `Get-Process kubectl` or `netstat -ano | findstr ":8001"`.
    4. **Deep Check**: Inspect the container's listening ports: `kubectl exec <pod> -- netstat -tlnp` (or `ss -tlnp`).
- **Root Cause**: **Port Drift**. The `redislabs/redisinsight:latest` image (Version 2) listens on port **5540** internally by default, whereas legacy Version 1 (and many existing manifests) expected port **8001**. If the Kubernetes `containerPort` and `Service.targetPort` are set to 8001, the connection will be refused by the container even if the pod and port-forwarding are "Healthy".
- **Fix (Verified)**: Align the manifest ports to 5540 and update allowed origins:
  1. Update `containerPort: 5540` and `Service.targetPort: 5540` (while keeping legacy `Service.port: 8001` for external consistency).
  2. Update `RITRUSTEDORIGINS` environment variable to include the forwarded port (e.g., `http://localhost:8001,http://localhost:5540`) to bypass strict CORS/origin checks in the new UI.
  3. Re-apply the manifest: `kubectl apply -f infra/k8s/redisinsight.yaml`.
  4. Restart the port-forwarding process: `kubectl port-forward svc/redisinsight 8001:8001`.
- **Pattern**: When using `:latest` tags for 3rd-party infrastructure (RedisInsight, pgAdmin), breaking changes in default listening ports can cause silent "Ready" failures. Always verify the container's bind port (`netstat`/`ss`) during connectivity troubleshooting to detect internal port drift.

### WebSocket: Handshake not finished
- **Symptom**: `ERROR Connection error ... WebSocket protocol error: Handshake not finished`.
- **Context**: Occurs when the client initiates a WebSocket connection but the server fails to complete the upgrading handshake within the protocol timeout.
- **Root Causes**:
    1. **Service Saturation**: The `web-ui` or `web-pty-server` is under extreme load (e.g., high-parallelism Playwright workers), leading to dropped TCP packets or slow processing of headers.
    2. **MIME/Path Mismatch**: If the integration environment is serving stale assets (e.g., trying to load a legacy script that the current server doesn't support as a WS endpoint).
    3. **Unhealthy Frontend**: The Nginx proxy (`web-ui`) is reporting "unhealthy" but still responding to some HTTP requests while failing to proxy WebSocket traffic.
- **Fix**: Perform a full environment reboot (`docker compose down && up`). If the error persists, check for infrastructure "Heat" (CPUs/Memory saturation) and optimize the visual test suite's worker density.

### WebSocket: Maximum sessions per IP reached (PER_IP_CAP)
- **Symptom**: `Error: Maximum sessions per IP reached` (browser console) or code 1005/1006. Connection opens but is immediately closed.
- **Root Cause**: The PTY broker enforces a limit on concurrent sessions from a single IP (default: 5). High-repetition or parallel testing can accumulate sessions if they aren't reaped fast enough.
- **Diagnostic (Metrics)**:
  Query the metrics endpoint (`:9001/metrics`) to observe session states.
  ```powershell
  curl -s http://localhost:9001/metrics | Select-String "pty_sessions"
  ```
  - `pty_sessions_active`: Total sessions.
  - `pty_sessions_idle`: Sessions waiting for the 30s grace period/reaper.
- **Resolution (Manual)**: 
  1. Restart the PTY server container to force-clear the session pool:
     ```bash
     docker restart odto-integ-web-pty
     ```
  2. **Zombie Client Warning**: If the pool immediately fills back up (check metrics), you likely have "Zombie Clients" (e.g., a hung browser subagent or manual tab) that are automatically reconnecting. In this case, perform a **Full Environment Reset**:
     ```bash
     docker compose -f docker-compose.integration.yml down && docker compose -f docker-compose.integration.yml up -d
     ```
- **Resolution (Architecture)**:
  1. **Double-Handle Cleanup**: Ensure **Standard 15** is implemented in `afterEach` to close `window.__odtoWs` and `window.ws`.
  2. **ESM Isolation**: Verify that the frontend (e.g., `terminal.js`) explicitly exposes the handle: `window.__odtoWs = ws`. Module-level variables are NOT accessible to Playwright by default.
  3. **Limit Tuning**: Increase `PTY_PER_IP_CAP` in the integration environment. For ODTO visual tests, this was increased to **30** in `docker-compose.integration.yml`.
  4. **Worker Density**: Reduce Playwright worker count (e.g., `--workers=1` or `2`) in CI if resource contention causes session leaks or handshake timeouts.

### Manual Handshake Verification
To determine if a WebSocket failure is caused by the proxy (Nginx) or the upstream (PTY Broker), use `curl` from within the proxy container to attempt a raw upgrade handshake:

```powershell
# Execute from within the web-ui container
docker exec odto-integ-web-ui curl -v --http1.1 `
    -H "Upgrade: websocket" `
    -H "Connection: Upgrade" `
    -H "Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==" `
    -H "Sec-WebSocket-Version: 13" `
    http://web-pty-server:9000
```

- **Success (101 Switching Protocols)**: The path between Nginx and the PTY Broker is healthy. The issue likely lies in the browser's connection to Nginx or client-side session limits.
- **Failure (502 Bad Gateway / Connection Refused)**: The upstream service is down, misnamed in `nginx.conf`, or the network bridge is broken.

### WebSocket: AUTH_REQUIRED Authorization required
- **Symptom**: Web Mirror loads but shows a persistent "Connecting..." status. Browser console shows `Server error: AUTH_REQUIRED`.
- **Diagnosis**: Check the PTY Server logs for auth failure warnings:
  ```powershell
  kubectl logs -l service=web-pty-ws --tail 20
  ```
  - `WARN Auth failed: no token in header or query string` confirms the server is rejecting the connection due to missing credentials.
- **Fix (Implemented v3.1.7)**: The loader was updated to use `.filter(|s| !s.is_empty())` ensuring `Some("")` is treated as `None`. For local testing, ensure the K8s secret `auth-token` is set to `""`.

### Integration: Phantom Regressions (Stale Image Hazard)
- **Symptom**: New tests fail with consistent assertion errors (e.g., "Script tag not found", "Terminal Unavailable") even after verifying the local code matches the expectations.
- **Discovery**: Integration environments (like Docker Compose integration) may continue to use cached images or old build layers even if the code on the host has changed.
- **Diagnosis**: Proactively probe the service for sentinel keywords:
  ```powershell
  Invoke-WebRequest -Uri "http://localhost:8081" -UseBasicParsing | Select-Object -ExpandProperty Content | Select-String "bundle.js"
  ```
- **Fix**: Force a clean rebuild of the affected image:
  ```bash
  docker compose -f docker-compose.integration.yml build <service> --no-cache
  ```
- **Rule**: Any change to static assets or backend contracts MUST trigger a rebuild mandate to prevent "ghost" regressions in the integration harness.

### Ephemeral Port-Forwarding in Orchestration
When launching background tasks (like `kubectl port-forward`) from an orchestration script, the lifetime of those tasks depends on how they are spawned.
- **Incident**: Port-forwards started in `start-all.ps1` would die as soon as the script finished, making web links in the README unusable.
- **Root Cause**: The script used `Start-Job`. In PowerShell, background jobs are child objects of the current session; when the session (the script process) terminates, the jobs are cleaned up.
- **Fix**: Use `Start-Process` with `-WindowStyle Hidden` instead.
- **Implementation**:
  ```powershell
  Start-Process -FilePath "kubectl" `
      -ArgumentList "port-forward", "svc/$service", "$localPort:$remotePort" `
      -WindowStyle Hidden `
      -PassThru
  ```
- **Pattern**: For "Self-Launching" applications where the orchestration script exits but the infrastructure must remain accessible, use persistent background processes (`Start-Process`) rather than session-scoped jobs (`Start-Job`).

## ⛓️ External Infrastructure & Outage Patterns

### Bazel Release Server Certificate Expiry
- **Symptoms**: `could not download Bazel: HTTP GET ... failed: tls: failed to verify certificate: x509: certificate has expired or is not yet valid`.
- **Context**: Occurs during the `setup-bazel` action when downloading the Bazel binary from `releases.bazel.build`.
- **Root Cause**: The TLS certificate on Google/Bazel's distribution servers has expired, or the CI runner has significant clock skew. This is an external infrastructure issue.
- **Remediation**:
  1. **Wait & Retry**: In most cases, the certificate is renewed within 1-2 hours.
  2. **Check Status**: Verify Bazel community channels (GitHub issues, Slack) for outage reports.
  3. **Job Re-run**: Attempt to re-run the failed CI job once the certificate issue is resolved.

- **Symptoms**: 
  1. `Error accessing registry https://bcr.bazel.build/: PKIX path validation failed: java.security.cert.CertPathValidatorException: validity check failed.`
  2. `WARNING: Download from https://bcr.bazel.build/modules/.../patches/... failed` followed by Build failure during main repo mapping.
- **Context**: Occurs during Bazel module resolution (Bzlmod) or during the build phase when Bazel needs to apply patches stored in the registry.
- **Root Cause**: Similar to the Bazel release server, the BCR domain (`bcr.bazel.build`) may have TLS certificate issues, or the CI runner lacks the necessary root certificates/trust-store updates to validate the connection. Patch files are specifically problematic because they are not cached in the lockfile.
- **Fix (Durable/Simplified)**: Decouple CI verification from registry access for mod resolution. 
  1. Set `common --lockfile_mode=error` in `.bazelrc` to enforce lockfile integrity during builds.
  2. Implement a **Registry-Independent CI Gate** by swapping `bazel mod deps` with a direct lockfile check:
     ```yaml
     - name: Verify MODULE.bazel.lock is unchanged
       run: git diff --exit-code MODULE.bazel.lock
     ```
  3. For the build phase, redirect to a mirror (GitHub Raw) using `common:ci` in `.bazelrc` and `--config=ci` on the CLI.
- **Fix (Absolute Hermeticity)**: If the build fails on **patch downloads**, use **Vendor Mode**.
  1. Run `bazel vendor --vendor_dir=vendor` locally and commit the directory.
  2. Add `common --vendor_dir=vendor` to `.bazelrc`.
- **Enforcement**: Validate hermeticity by failing CI if `bcr.bazel.build` or `raw.githubusercontent.com` (if vendoring) are found in logs, ensuring no silent fallbacks.

## 🧪 Testing & Verification Patterns

### Deterministic Readiness Gating
- **Incident**: Automation scripts fail because they start before the container initialization logic (e.g., DB migrations) is complete.
- **Pattern**: Avoid scripting against `Running` status alone. A pod can be "Running" but still in a `CrashLoopBackOff`.
- **Fix**: Use `kubectl wait --for=condition=Ready pods --all`. This ensures the service's `readinessProbe` has passed.

### MongoDB Event Correlation Failures
- **Incident**: The Integration Gate reports `[FAIL] MongoDB Events - Event missing correlation`.
- **Discovery**: The `read-model` service returns MongoDB documents using the Go driver's `raw` BSON format (an array of `Key`/`Value` pairs) instead of standard JSON objects. This breaks standard property path access in automation scripts.
- **Fix**: Update validation logic to use regex or string-matching on the JSON-serialized response to identify `correlationId` or `eventId` values within the Key/Value structure.
- **Resolution**: Implementation of regex-based matching in `integration-gate.ps1` successfully resolved this failure pattern.
- **Duplicate Event IDs**: If the gate reports duplicates, check RabbitMQ retry logic or Go Metrics Engine idempotency (ensuring `InsertOne` failures or retries don't create "phantom" documents). Ensure the gate correctly extracts IDs from the BSON format before counting.

### Integration Gate False Negatives (Health Checks)
- **Incident**: The Integration Gate reports `[FAIL] Gateway Health` or `[FAIL] Read Model Health`, even when the service is responsive and processing jobs.
- **Root Cause**: Interoperability between PowerShell's `Invoke-RestMethod` and polyglot health endpoints. If an endpoint returns a JSON body (e.g., `{"status":"ok"}`) while the script expects a plain string (e.g., `"OK"`), the comparison `$health -eq "OK"` fails because `$health` is interpreted as a PowerShell object.
- **Fix**: Update assertions to handle both plain strings and JSON objects with a `.status` property.
- **Robust Pattern**:
  ```powershell
  $health = Invoke-RestMethod -Uri $Url
  $isHealthy = ($health -eq "OK") -or ($health.status -eq "ok")
  ```
- **Verification**: This fix was implemented in `scripts/integration-gate.ps1` and `scripts/integration-harness.ps1` to resolve false negatives and "P1 Badge Check" stalls during the Phase 18 hardening cycle.

## 🏗️ Bazel Build & CI Errors

### OCI Tarball Format Mismatch
- **Error**: `Format docker is only supported for oci_image targets but saw "application/vnd.oci.image.manifest.v1+json"`
- **Context**: Occurs during `oci_tarball` when tagging an image derived from an OCI index.
- **Root Cause**: `oci.pull` with `platforms` creates a multi-platform index. `oci_tarball` with `repo_tags` expects a single-platform manifest.
- **Fix**: Update the `oci_image.base` to point to the architecture-specific repo (e.g., `@distroless_node_linux_amd64`) instead of the multi-platform root. 
- **Workaround**: If the error persists (e.g., due to strict rules_oci tagging requirements), add `tags = ["manual"]` to the `oci_tarball` target. This allows `bazel build //...` to pass in CI by excluding the problematic tarball export while keeping the image targets functional.

### Aspect rules_js Package Mapping
- **Error**: `Expected to find source file X in '//package/A', but instead it is in '//package/B'.`
- **Root Cause**: Aspect `rules_js` cannot copy files across package boundaries directly for a `js_binary`.
- **Fix**: Wrap the foreign files in a `js_library` in their home package and depend on that library target.

### Gazelle go_deps Checksum Mismatch
- **Error**: `Multiple mismatching sums for X@Y found: H1 vs H2`
- **Root Cause**: Local `go.sum` files for different Go services disagree on the hash for a shared dependency.
- **Fix**: Empty the `go.sum` files and run `go mod tidy` in each service directory (using the same Go version) to regenerate consistent hashes.

### Module Lockfile Out of Sync
- **Error**: `ERROR: MODULE.bazel.lock is no longer up-to-date because: the root MODULE.bazel has been modified.`
- **Root Cause**: A change to `MODULE.bazel` occurred without running `bazel mod deps --lockfile_mode=update`, or line endings (CRLF vs LF) caused a hash mismatch.
- **Fix**: Run `bazel mod deps --lockfile_mode=update`. If it persists on CI, ensure LF line endings are enforced via `.gitattributes`.

### `whl_library` Fetch Failure (Git Clone)
- **Error**: `rules_python:whl_library(...) FAIL: repo.execute: ... fatal: could not read Username for 'https://github.com': No such device or address`
- **Context**: Occurs during the fetch phase of a Python dependency (e.g., `pika`) even if that dependency is public and not host on git.
- **Root Cause**: An editable install (`-e git+https://...`) exists in `requirements_lock.txt`. `rules_python` propagates this requirement to the pip installer for *every* package. If the git repo is private or requires auth, the fetch for *all* packages will fail as pip tries to clone it.
- **Fix**: Remove the entry starting with `-e git+` from `requirements_lock.txt`. Regenerate the lockfile and verify the build.

### Pip.parse Analysis Stalls (rules_python)
- **Symptom**: Bazel analysis phase hangs or exceeds 10-15 minutes during the resolution of `@pip` or `@pip_heavy` extensions.
- **Diagnostics**:
    1.  **Isolated Replay**: Use the `stall-repro` GitHub Actions job (manual trigger). It runs a minimal `pip.parse` in a clean environment to isolate if the issue is cache-related or dependency-intrinsic.
    2.  **Verbose Logging**: Run `bazel mod deps` locally to see which package is currently being resolved.
- **Known Causes**:
    - **Editable Installs**: As noted above, git clones during fetch can stall if SSH/HTTPS auth prompts appear in a non-interactive shell.
    - **Cyclic Dependencies**: Extreme deep-tree resolutions with conflicting version constraints.
- **Resolution**: Clear the local Bazel cache (`bazel clean --expunge`) if poisoning is suspected. Verify that `requirements_lock.txt` does not contain un-pinned or editable references.
- **Reproduction Context (Legacy)**: The `repro/` directory (specifically `repro/repro-requirements.txt`) previously used the external `ado-pull-request-metrics` repository as a test case for these stalls. This was intentional diagnostic scaffolding used during the Phase 35 hardening cycle and not a production dependency. As of Dec 2025, this directory and related historical comments have been removed to maintain repository hygiene.


### `py_binary` Main Attribute Error
- **Error**: `Error in fail: corresponding default 'target_name.py' does not appear in srcs. Add it or override default file name with a 'main' attribute`
- **Root Cause**: The `py_binary` target name does not match the filename in `srcs`, and no `main` attribute was provided.
- **Fix**: Add `main = "your_file.py"` to the `py_binary` rule in `BUILD.bazel`.

### Go Missing Strict Dependencies
- **Error**: `compilepkg: missing strict dependencies: ... import of "X"`
- **Root Cause**: A Go package is imported in the source code but not declared in the `deps` of the `go_library`, `go_binary`, or `go_test` target in `BUILD.bazel`.
- **Internal Pattern**: This frequently occurs when tests in the `main` package import a helper subpackage (e.g., `metrics-engine` importing `validator`). Even though they share a module, Bazel requires the subpackage to be explicitly listed as a dependency.
- **Fix**: 
    1.  Ensure the subpackage has a `go_library` target defined.
    2.  Add the subpackage target (e.g., `//src/services/metrics-engine/validator:validator`) to the `deps` list in `BUILD.bazel`.
    3.  For external packages, ensures they are defined in `MODULE.bazel` and added to `deps` (e.g., `@org_mongodb_go_mongo_driver//bson`).

### Bazel Test Exit Code 4
- **Error**: `ERROR: No test targets were found, yet testing was requested. Error: Process completed with exit code 4.`
- **Context**: Occurs when running `bazel test //...` with filters that exclude all available tests, or if no `_test` rules are defined in the workspace.
- **Fix**: Update the CI shell script to catch exit code 4 and treat it as a success (`exit 0`).

### Bazel Go Test: Missing Input File
- **Error**: `GoTestGenTest ... failed: missing input file '//src/services/X:main_test.go'`
- **Context**: Occurs after renaming Go test files (e.g., from `main_test.go` to `metrics_engine_test.go`).
- **Root Cause**: The `go_test` rule in `BUILD.bazel` still hardcodes the old filename in its `srcs` attribute. Bazel does not automatically detect renames of files explicitly listed in rules.
- **Fix**: Update the `srcs` list in the `go_test` target in `BUILD.bazel` to match the new filenames.

### Bazel: Missing Strict Dependencies (Internal Packages)
- **Error**: `compilepkg: missing strict dependencies: ... /src/services/X: import of "github.com/.../internal/Y"`
- **Context**: Occurs during Bazel Go builds when a package imports a sub-package (e.g., `metrics-engine` importing its own `validator` package).
- **Root Cause**: Even though internal packages share a module, Bazel's `rules_go` treats every package as a distinct dependency. If the sub-package is not explicitly listed in the `deps` of the importing target, the build fails.
- **Fix**: 
  1. Define a `go_library` target for the sub-package (e.g., in `validator/BUILD.bazel`).
  2. Add that target to the `deps` of the parent `go_library` or `go_test`.

### Gazelle: Indirect Go Dependency Warning
- **Error**: `WARNING: ... go_deps ... reported incorrect imports of repositories via use_repo(): Imported, but reported as indirect dependencies by the extension: X`
- **Context**: Occurs after manually adding a dependency (like `gojsonschema`) to the `use_repo` list in `MODULE.bazel` before Bazel's internal dependency resolution is fully synchronized.
- **Root Cause**: Bzlmod's `go_deps` extension tracks which modules are direct vs. indirect dependencies. If your `use_repo` list explicitly calls out an indirect dependency, Bazel warns of the mismatch.
- **Fix**: Run `bazel mod tidy`. Bazel will automatically rewrite the `use_repo` section of your `MODULE.bazel` to match the canonical dependency graph.

### Bazel Go Test: Testing the 'main' Package
- **Error**: `metrics_engine_test.go: undefined: getEnv` (during Bazel test only)
- **Context**: Occurs when Go tests in `package main` try to access non-exported or un-exported functions defined in `main.go`.
- **Root Cause**: Unlike standard `go test`, Bazel `go_test` targets are separate from `go_library`. If the test is in the same package as the source, it must "embed" the library to see its internal symbols.
- **Fix**: Add `embed = [":your_service_lib"]` to the `go_test` rule in `BUILD.bazel`. This merges the package surfaces, allowing the test to access package-level variables and un-exported functions.

### Bazel: Windows POSIX Shell Dependency (/bin/bash)
- **Error**: `WSL (1689 - Relay) ERROR: CreateProcessCommon:800: execvpe(/bin/bash) failed: No such file or directory` or `FAILED: Execution platform: @@local_config_platform//:host ... failed: /bin/bash: No such file or directory`
- **Context**: Occurs on Windows when certain Bazel rules (e.g., `rules_oci`, `rules_pkg`, or `genrule`) attempt to execute a POSIX shell command and assume `/bin/bash` exists.
- **Root Cause**: Bazel on Windows does not provide a POSIX shell by default. Some rules or custom actions hardcode the path to `/bin/bash`, which is invalid on Windows without an emulator.
- **Fix**:
    1.  **Install Git Bash**: Install Git for Windows, which includes a `bash.exe` emulator.
    2.  **Set BAZEL_SH**: Set the `BAZEL_SH` environment variable to the path of your bash executable (e.g., `set BAZEL_SH=C:\Program Files\Git\bin\bash.exe`).
    3.  **Pathing**: Ensure the directory containing `bash.exe` is in your system `PATH`.
    4.  **Targeted Build**: If the failure is in a specific rule (like `oci_tarball`) that is not critical for local development, run a targeted build (e.g., `bazel build //src/services/metrics-engine/...`) to bypass the problematic target.

### Bazel: Another command is running / Waiting for server lock
- **Error**: `Another command (pid=X) is running. Waiting for it to complete on the server (server_pid=Y)...`
- **Context**: Occurs when a previously executed Bazel command hangs, is interrupted without releasing the lock, or another terminal is actively building.
- **Root Cause**: Bazel enforces a single active command per workspace. If a process (like a hanging `oci_tarball` build on Windows) keeps the lock, all subsequent calls will stall.
- **Fix**:
    1.  **Try Shutdown**: Run `bazel shutdown`. This is the safest way to terminate the server.
    2.  **Force Kill**: If shutdown hangs, kill the server process using the `server_pid` provided in the error message:
        - Windows: `taskkill /F /PID <server_pid>`
        - Linux/macOS: `kill -9 <server_pid>`
    3.  **Clean Output Base**: As a last resort, manually remove the `lock` file in the Bazel output base (found via `bazel info output_base`).

### Pytest: Command Not Found in CI
- **Error**: `The term 'pytest' is not recognized as a name of a cmdlet, function, script file, or executable program.`
- **Context**: Occurred during `run-all-tests.ps1` execution in a CI environment (like GitHub Actions).
- **Root Cause**: The `pytest` entry point might not be in the global `PATH`, or the shell environment (e.g., `pwsh`) doesn't inherit the Python scripts directory correctly.
- **Fix**: 
  1. **Use Module Runner**: Call pytest via the Python module runner: `python -m pytest`. This ensures that the `pytest` package installed in the current Python environment is used regardless of PATH configuration.
  2. **Explicit Installation**: Verify that the CI workflow explicitly installs the test dependencies (e.g., `pip install pytest`) during the setup phase. Module runners still require the library to be present in the environment's `site-packages`.

### Node/Gateway: npm ci vs npm install
- **Error**: `npm ci` fails with `The lockfile is out of sync` or `npm ERR! cipm can only install packages with an existing package-lock.json`.
- **Context**: Occurs during CI dependency provisioning for Node.js services.
- **Root Cause (Missing Lockfile)**: `npm ci` is strictly for clean installs from a lockfile. If the `package-lock.json` is missing from the container or CI context, it fails.
- **Incident (Invisible Ignored File)**: In Phase 25, the Gateway service failed CI because `package-lock.json` was omitted from the repository. Despite being present locally, it was being suppressed by a parent `.gitignore` rule, causing `npm ci` to fail in the clean CI environment.
- **Fix**: Force-add the lockfile to git if it is being ignored:
  ```bash
  git add -f src/services/gateway/package-lock.json
  ```
- **Pattern**: For deterministic binary builds where `npm ci` is preferred, always verify that the lockfile is actually tracked by git (`git ls-files`). Parent directory gitignores can sometimes silently ignore critical vendor or metadata files in sub-services.

### Python: ModuleNotFoundError: No module named 'yaml'
- **Error**: `ModuleNotFoundError: No module named 'yaml'`
- **Context**: Occurs when running governance scripts (like `check-service-versions.py`) in CI that parse Kubernetes manifests or YAML configuration.
- **Root Cause**: The standard library does not include a YAML parser. The `pyyaml` package must be explicitly installed.
- **Fix**: Add `pyyaml` to the CI workflow dependency installation step (ideally via `pip install -r requirements-dev.txt`). Verify the preflight check in `run-all-tests.ps1` passes.

### Git: Missing Upstream for New Branches
- **Error**: `fatal: The current branch X has no upstream branch.`
- **Context**: Occurs when trying to `git push` a newly created feature branch.
- **Root Cause**: Local branches created with `git checkout -b` are not linked to a remote branch by default.
- **Fix**: Use the explicit upstream flag: `git push -u origin X` or `git push --set-upstream origin X`.

### Git: Push Timeout
- **Error**: `fatal: unable to access '...': Operation timed out after X milliseconds`
- **Context**: Occurs during `git push` in environments with high latency or intermittent connectivity.
- **Root Cause**: Transient network issue or large payload (unlikely for text-only PRs).
- **Fix**: Retry the command. If persistent, check repository size or network stability.

### PowerShell: ParserError: Unexpected token
- **Symptoms**: 
  - `ParserError: Unexpected token '?' in expression or statement.`
  - `The token '||' is not a valid statement separator in this version.`
- **Context**: Occurs when running `run-all-tests.ps1` or other modern scripts in a standard Windows PowerShell 5.1 environment.
- **Root Cause**: Modern syntax like the ternary operator (`$condition ? 'a' : 'b'`) and the pipeline chain operators (`||`, `&&`) were introduced in PowerShell 7.0 (Core) and are not supported in Windows PowerShell 5.x.
- **Fix**: Install PowerShell 7+ (Core) and use the `pwsh` command. ODTO mandates `pwsh` for CI/CD consistency.
### GitHub Actions: Invalid Action Reference
- **Symptoms**: `typecheck` or `lint` jobs fail with an error indicating a repository or action could not be found.
- **Incident**: The CI failed because it was using `dtolnay/rust-action@stable`.
- **Root Cause**: Typo in `ci.yml`. The correct repository name for this action is `dtolnay/rust-toolchain`.
- **Fix**: Replace `uses: dtolnay/rust-action@stable` with `uses: dtolnay/rust-toolchain@stable`. Future typos are prevented by the `validate-ci.ps1` script in the `pre-commit.ps1` hook.

### Bazel: Missing Input File (index.js vs index.ts)
- **Error**: `Writing: bazel-out/.../app_tar.tar failed: missing input file '//src/services/gateway:index.js'`
- **Context**: Occurs during Bazel build after converting a Node.js service from JavaScript to TypeScript.
- **Root Cause**: The `BUILD.bazel` file contains hardcoded references to `index.js` in `srcs` or `data` attributes, but the file has been renamed to `index.ts`.
- **Fix**: Update the `entry_point`, `srcs`, and `data` attributes in `BUILD.bazel` to point to the `.ts` source. Bazel rules for Node.js (Aspect) will handle the transpilation or direct execution depending on the rule.

### Python: ModuleNotFoundError: No module named 'jsonschema'
- **Error**: `E   ModuleNotFoundError: No module named 'jsonschema'`
- **Context**: Occurred during the `Tests` job on CI runners.
- **Root Cause**: The Python `processor` service depends on `jsonschema` for contract validation at runtime and during testing, but the library was missing from the CI's `pip install` step.
- **Fix**: Update the CI workflow (`ci.yml`) to include `jsonschema` in the pre-test installation step: `pip install pytest pyyaml jsonschema`.

### Vitest: Coverage Threshold Failure (0%)
- **Error**: `ERROR: Coverage for lines (0%) does not meet global threshold (80%)`
- **Context**: Occurs during `npm run test:coverage` in TypeScript services.
- **Root Cause**: Vitest (v8 coverage) may fail to map `.test.js` execution back to `.ts` source files if standard mappings or includes are missing, resulting in 0% coverage reports that trip hard-fail thresholds.
- **Fix**: Ensure `vitest.config.ts` (or `package.json` config) includes the correct `src` paths and that tests import the source correctly. In hybrid environments, verify that the coverage provider (v8/istanbul) is correctly instrumenting the `.ts` files.
### ESLint: Parsing error: The keyword 'interface' is reserved
- **Error**: `E:\...\index.ts: Parsing error: The keyword 'interface' is reserved`
- **Context**: Occurs when ESLint tries to parse TypeScript files without the `@typescript-eslint/parser` being correctly configured.
- **Root Cause**: The default ESLint parser is for standard JavaScript and does not recognize TypeScript-specific keywords like `interface` or `namespace`.
- **Fix**: Update `eslint.config.js` or `.eslintrc` to use `@typescript-eslint/parser` and include the appropriate plugins for TypeScript analysis.

### CI: "Soft-Fail" Linting Policy
- **Symptom**: CI passes despite visible lint or formatting errors in the build logs.
- **Context**: Observed in polyglot pipelines where linting is used as a "warning" rather than a hard gate.
- **Root Cause**: The CI workflow (`ci.yml`) uses the `|| echo "::warning::..."` pattern or `continue-on-error: true` for linting steps (e.g., Prettier, ESLint, Ruff). This prevents local "embarrassments" from blocking the merge but often allows style drift to reach `main`.
- **Recommendation**: Transition critical services to hard-fail linting once baseline formatting is achieved across the repository. Mandatory for new services.
### Go Coverage Threshold Failure (0%)
- **Error**: `Coverage 0.0% below 60% threshold` during `go tool cover`.
- **Context**: Occurs when Go unit tests exist (e.g., `metrics_engine_test.go`) but only test local helper functions within the test file, failed to import from `main.go`, or only test logic that doesn't trigger `main` package code.
- **Root Cause**: Go `main` package coverage requires tests to actually call public or internal functions defined in `main.go`. If tests are purely decoupled or mock-based without instrumenting the target service, coverage stays at 0%.
- **Fix**: Identify pure-logic helpers in `main.go` (e.g., `getEnv`, `formatValidationErrors`) and add unit tests for them in the `main` package test file. Ensure appropriate imports (like `validator`) are used if required by the main package types.
- **Threshold Calibration**: If testing all logic-heavy helpers still results in coverage below the target (e.g., 60%), calibrate the CI threshold to a lower achievable floor (e.g., **10%** for `metrics-engine`, **3%** for `read-model`) to maintain a hard gate without requiring immediate refactoring of the `main()` loop.
- **Schema Pitfall**: When testing `ValidateMessage`, ensure mock data uses **UUIDs** and **ISO8601 dates**. Schemas with `format: uuid` will reject simple strings like `"evt-123"`, causing tests to fail validation and potentially reporting 0% coverage on path-specific logic.
- **Strategic Decision**: Unlike the Node.js/Gateway "Soft-Fail" approach, the Go pipeline uses hard-fail gates. Coverage gaps must be bridged with "plumbing tests" to maintain gate integrity.
### PowerShell Encoding Issues in TUI Orchestration
- **Symptom**: `ParserError: The string is missing the terminator: "` or `TerminatorExpectedAtEndOfString` when running orchestration scripts via the TUI, even when syntax appears correct.
- **Root Cause**: Encoding mismatch. If a PowerShell script contains multi-byte UTF-8 characters (emojis like 📡, box-drawing characters like ═) and lacks a Byte Order Mark (BOM), `powershell.exe` may interpret it using a local legacy codepage, causing character offset shifts that "swallow" string terminators or quotes.
- **Diagnostic**: Use PowerShell to inspect the first few bytes of the file:
  ```powershell
  [System.IO.File]::ReadAllBytes("path/to/script.ps1")[0..2] -join ','
  ```
  (Result `35,32,115` confirms no BOM; `# s` start).
- **Fix**: 
  1. **Primary (Recommended)**: Replace multi-byte Unicode characters (emojis, box drawing) with ASCII equivalents (e.g., `[OK]`, `====`). This ensures 100% parsing reliability across legacy `powershell.exe` versions and different parent-process redirection methods.
  2. **Secondary**: Re-save the script with **UTF-8 with BOM** encoding. Note that some CI environments or version control transitions may still strip the BOM or cause environmental interpretaton drifts.

### PowerShell: Expected Stderr Output in Orchestration Scripts
- **Symptom**: Orchestration script terminates unexpectedly during cluster detection with `LASTEXITCODE` 0 or no visible error, but the log shows `kind.exe : No kind clusters found.`.
- **Root Cause**: When `$ErrorActionPreference = "Stop"` is set, PowerShell treats ANY output to `stderr` (Stream 2) as a terminating error. Many CLI tools (like `kind` or `kubectl`) use `stderr` for informational status messages when things aren't "found" (e.g., `No kind clusters found.`).
- **Fix**: Wrap the command in a `try/catch` block or use stream redirection and filtering to handle the expected message without triggering an error.
  ```powershell
  # Strategy A: Filter out expected status messages from stderr
  $clusters = & kind get clusters 2>&1 | Where-Object { $_ -notmatch "No kind clusters found" }

  # Strategy B: Temporarily relax ErrorActionPreference for progress-heavy commands
  $ErrorActionPreference = "Continue" # kind create cluster AND load docker-image output progress to stderr
  $output = & kind create cluster --name $name 2>&1
  # OR
  $output = & kind load docker-image $image --name $name 2>&1
  $exitCode = $LASTEXITCODE
  $ErrorActionPreference = "Stop" # Restore strict handling
  ```
- **Pattern**: Always identify CLI commands that use `stderr` for non-fatal status reporting or progress bars and explicitly handle or suppress those messages to prevent premature script termination under `ErrorAction Stop`.

- **Prevention**: When migrating services to TypeScript, include a "Dockerfile Update" step in the migration checklist to ensure continuous deployment compatibility.

### Docker Build: Monorepo Context vs Root Dependencies
- **Symptom**: `docker build` fails with `COPY failed: file not found in build context: contracts` (or other root-level directories).
- **Context**: Occurs in monorepos when an orchestration script (like `start-all.ps1`) is updated to use service-specific subdirectories as the Docker build context (e.g., `src/services/gateway`) instead of the repository root (`.`).
- **Root Cause**: Many Dockerfiles in the ODTO platform (e.g., `gateway`, `processor`) perform `COPY contracts ./contracts`. This folder only exists at the repository root. If the build context is shifted to a subdirectory, the `contracts/` folder is no longer "visible" to the Docker daemon during the build.
- **Latent Hazard (CI)**: A variant of this occurs in CI where the build context is service-local but the Dockerfile uses repo-relative paths (e.g., `COPY src/services/gateway/...`). This may appear to succeed if using stale cached images, leading to a "Latent Failure" that only surfaces on clean builds.
- **Fix (Mandatory Parity)**: Ensure the build context exactly matches the Dockerfile's path assumptions. For services using repo-relative paths, the context MUST be the repository root (`.`).
- **Enforcement**: Run `python scripts/validate-dockerfile-context.py` to verify that CI contexts match Dockerfile requirements.
- **Manual Reproduction**:
  ```powershell
  # If this fails with "file not found", the context is likely service-local while the Dockerfile expects repo-root.
  docker build -t <service>:test -f src/services/<service>/Dockerfile src/services/<service>
  ```
- **Verification**: Ensure the `Context` property for gateway/processor images in `start-all.ps1` and `.github/workflows/ci.yml` points to the project root (`.`).
- **Misleading Symptom**: During such failures, the TUI might report "Failed to build: web-pty-server" even if a different service (like `gateway` or `processor`) failed first. This is because the TUI often displays the last attempted build or summarizes a batch failure under a generic header. Always check the raw script output (running `.\scripts\start-all.ps1` directly) to identify the true proximal cause.

### Docker Build: TUI Reports :latest Tag for Versioned Service
- **Symptom**: The TUI reports "Failed to build: <service>:latest", but the script defines the version as `0.1.0` and the `VERSION` file exists.
- **Root Cause**: **$PSScriptRoot Invocation Hazard**. When the TUI spawns the PowerShell script via `-Command`, `$PSScriptRoot` is empty. If the script relies on `$PSScriptRoot` to find its root, it may fall back to an incorrect path where it cannot find the `VERSION` files, defaulting back to `:latest`.
- **Fix**: Apply the **Hardened Root Resolution Pattern** (marker-based directory traversal) in the `start-all.ps1` script.
- **Verification**: Run `.\scripts\start-all.ps1 -OutputJson` directly. If the JSON shows the correct version (e.g. `0.1.0`) but the TUI still shows `:latest`, perform an **Authoritative Rebuild** of the TUI binary.

### TUI: Cluster Setup Fails Immediately (Hard Failure)
- **Symptom**: Pressing 'L' in the TUI results in an immediate red "Setup Failed" screen without visible progress logs.
- **Root Cause**: The orchestrator script's **Fail-Fast Guard** is triggering. This happens if the script is spawned in a way that the **Hardened Root Resolution Pattern** cannot find the `infra/` marker (e.g., if the TUI is run from an unexpected directory or if the loop termination logic hits a drive root too early).
- **Diagnosis**: Run the simulated TUI command manually: `pwsh -NoProfile -ExecutionPolicy Bypass -Command "& 'path/to/start-all.ps1' -OutputJson"`.
- **Remediation**:
    1. Verify the TUI is being executed from within the `src/interfaces/tui` directory or the repo root.
    2. Check if the `infra/` directory exists at the repository root.
    3. Ensure the parent process (TUI) sets the `current_dir` to the project root before spawning the script.

### Docker Build: "/VERSION": not found
- **Symptom**: `docker build` fails with `ERROR: failed to calculate checksum of ref ...: "/VERSION": not found` (or requirements.txt / package.json).
- **Root Cause**: **Repo-Root Build Context Invariant** violation. The build script is using the repository root (`.`) as the context (required for shared contracts), but the Dockerfile is attempting to copy files using paths relative to the service directory.
- **Fix**: Prefix all `COPY` commands in the Dockerfile with the service's repo-relative path (e.g., `COPY src/services/gateway/VERSION ./`).

### Kind: Load Failure with -SkipBuild (Tag Mismatch)
- **Symptom**: `kind load` fails with `ERROR: image: "<service>:latest" not present locally`, even though versioned images (e.g. `:0.1.0`) are present in the Docker daemon.
- **Root Cause**: **SkipBuild Tag Consistency Hazard**. When `-SkipBuild` is used, the orchestrator may fail to populate its internal version cache, defaulting to `:latest` during the `kind load` step.
- **Fix**: Update the orchestrator to resolve versions independently from `VERSION` files during the load step, regardless of whether the build was skipped.
- **Verification**: Run `.\scripts\start-all.ps1 -SkipBuild -OutputJson` and verify the `load` step logs show versioned tags (e.g., `Loading gateway:0.1.0...`).

### Docker Build: False Failure from Stderr
- **Symptom**: `docker build` is reported as failed (exit code 1) by a parent script (e.g., PowerShell `Start-Job`), but the logs show `DONE` or successful image naming.
- **Root Cause**: Docker (and BuildKit) writes progress and metadata to `stderr` (Stream 2) by design. In some shell hosts (especially PowerShell jobs or certain CI runners), the presence of any data on the error stream can cause the `$LASTEXITCODE` to be set to 1 or trigger an error action, even if the primary process returned 0.
- **Fix**: 
  1. Verify the build logs: if all layers show `DONE`, the image exists.
  2. Handle the exit code explicitly: if `docker build` is the only command in a block, ensure you aren't strictly failing on all stderr output.
  3. Use `--progress=plain` to make output more predictable, though it still utilizes stderr.
- **Pattern**: When orchestrating Docker builds from high-integrity shells, rely on the successful "naming" of the image or specific log markers rather than a zero-exit-code check on a stream that includes progress data.

### Go Build: Git PATH Dependency (Local Modules)
- **Symptom**: `go build` fails in a Docker container (especially Alpine-based) with an error like `exec: "git": executable file not found in $PATH` while trying to resolve a module path that looks like a remote repository.
- **Root Cause**: If a Go `import` path uses a fully qualified name (e.g., `github.com/org/repo/pkg`) but the package is actually inside the current build context, Go may still attempt to verify the module via `git` if the internal module structure is not explicitly defined or if the build context is restricted in a way that Go's solver defaults to remote lookup.
- **Fix**:
    1. **Local Imports**: Ensure that internal packages are imported using relative paths if they aren't part of a properly initialized Go workspace.
    2. **Context Resolution**: Explicitly `COPY` internal sub-package directories (e.g., `COPY validator ./validator/`) and the `go.sum` file into the container context before running `go mod download`. In monorepos, where the build context is often the project root, relative paths in the Dockerfile must be carefully aligned with the service's internal dependency tree.
    3. **Dependency Integrity**: Always ensure `go.sum` is present in the build stage. Go 1.21+ requires the sum file for module verification; its absence during `go mod download` can cause confusing resolution errors or fetch attempts that trigger the Git PATH failure.
    4. **Dependency Presence**: If the module must be fully qualified, ensure `git` is installed in the builder stage of the Dockerfile (e.g., `RUN apk add --no-cache git`).
    5. **Vendoring**: Use `go mod vendor` to include all dependencies in the build context, eliminating the need for network or git access during the container build.
- **Pattern**: For "Self-Launching" builds in restricted environments, minimize external lookups by ensuring all internal microservice dependencies are resolvable within the immediate container context.

### Kind: Pod Readiness Timeout
- **Symptom**: The orchestration script hangs or errors during the "Waiting for pods" step, often showing a stalled count (e.g., `Pods ready: 11/15`).
- **Root Cause**: One or more pods are in `ImagePullBackOff`, `CrashLoopBackOff`, or `Pending` state. In the "Self-Launching" pattern, this is often due to a failure in a previous step (e.g., image loading failed silently) or resource constraints on the Docker host.
- **Fix**: 
    1. Manually inspect the pod states using `kubectl get pods -A`.
    2. Check the logs of the failing pod: `kubectl logs <pod_name>`.
    3. Describe the pod to see events: `kubectl describe pod <pod_name>`.
- **Insight**: Stalls at a specific number (e.g., 11/15) often indicate that core infrastructure (Redis, RabbitMQ, MongoDB) is ready, but the business services that depend on them (Gateway, Processor) are failing to start or connect.
### Kind: ErrImageNeverPull (Tag Mismatch)
- **Symptom**: Pods fail to start with `READY 0/1` and status `ErrImageNeverPull`.
- **Root Cause**: In restricted environments where `imagePullPolicy: Never` is used (common in Kind/local dev), Kubernetes will *only* look for the image in the local node's cache. If there is a mismatch between the tag in the manifest (e.g., `image: service:0.1.0`) and the tag produced by the build system (e.g., `docker build -t service:latest`), Kind will fail to find the image even if it was successfully loaded.
- **Diagnosis**: 
    1. Check pod status: `kubectl get pods --no-headers` (look for `ErrImageNeverPull`).
    2. Inspect manifest image: `kubectl get deployment <name> -o jsonpath='{.spec.template.spec.containers[0].image}'`.
    3. Inspect local images: `docker images --format "{{.Repository}}:{{.Tag}}"` and check `kind get clusters` nodes.
- **Fix**: Align the image tags. Either update the Kubernetes manifests to use `:latest` or update the build orchestration (e.g., `start-all.ps1`) to tag images with the specific version (e.g., `:0.1.0`) expected by the manifests.
    - **Manifest Update**: In ODTO, all manifests in `infra/k8s/*.yaml` were updated to use `:latest` to simplify the build/deploy contract for local development.
- **Pattern**: For "Single-Click" launchers, ensure a rigid contract exists between the Build stage (Docker tags), the Load stage (Kind import), and the Deploy stage (K8s manifests) regarding image naming.

### The Pinned Tag Trap (Kind/Local Dev)
- **Symptom**: You build a fix (e.g., `docker build -t processor:latest`), load it (`kind load docker-image processor:latest`), and restart the pod, but the logs **still show the old bug**.
- **Discovery**: A deployment manifest may be explicitly pinned to a version (e.g., `image: processor:0.1.0`). Loading `latest` into the Kind node has no effect because the pod is instructed to use a specific version that likely already exists in the node's container runtime cache.
- **Diagnosis**: 
  1. Check deployment image: `kubectl get deployment <name> -o jsonpath='{.spec.template.spec.containers[0].image}'`.
  2. If it is NOT `latest`, your local build must match the pinned tag EXACTLY.
- **Fix**: Build with the manifest's specific tag:
  ```powershell
  docker build -t processor:0.1.0 -f src/services/processor/Dockerfile .
  kind load docker-image processor:0.1.0 --name task-observatory
  kubectl rollout restart deployment processor
  ```

### Poisoned Message Loops (AMQP/RabbitMQ)
- **Symptom**: After deploying a fix for a crashing consumer, the logs immediately flood with the same error for old messages.
- **Root Cause**: If a consumer crashes and the message is `nack`'d with `requeue=True` (or if it hits a retry limit without a Dead Letter Queue), the "poisoned" message returns to the queue. When the fixed consumer starts, it immediately pulls these old messages.
- **Diagnosis**: 
  1. Check the logs for `correlationId` or `eventId`. If they match old failed attempts, you are processing a backlog.
  2. Check if the error is identical. If it is, the "fix" might not be active (see [Pinned Tag Trap](#the-pinned-tag-trap-kindlocal-dev)).
- **Remediation**: 
  - Purge the queue (via RabbitMQ UI or `rabbitmqadmin`) if the old messages are purely for testing.
  - Implement a **Dead Letter Queue (DLQ)** to isolate messages that fail validation.
  - Ensure the consumer uses `.get()` or defensive checks for elective schema fields to prevent the crash in the first place.

### Empty Recent Jobs Table (TUI)
- **Symptom**: The "Recent Jobs" pane in the TUI is empty, even after submitting jobs that are confirmed `COMPLETED` in the PostgreSQL database.
- **Root Cause**: Failure of the `read-model` service to communicate with Redis/Postgres or a port-forwarding issue (see [Hardcoded Orchestration Hazard](#hardcoded-orchestration-hazard-refresh-loop)).
- **Diagnosis**: 
  1. Check `read-model` logs: `kubectl logs -l service=read-model`.
  2. Verify port-forward: `localhost:8080/jobs` should return a JSON array.
- **Remediation**: Restart the `read-model` deployment or re-establish port-forwards via the `odd-dashboard doctor` command.

### The Silent Python Container (Buffering)
- **Symptom**: `kubectl logs` reports "No output" for a running Python pod, even if `print()` statements have been executed.
- **Root Cause**: Python's standard output and error streams are buffered by default. If the container process is waiting for messages (e.g., `ch.start_consuming()`), the logs may not appear in the terminal until the buffer fills up or the process exits.
- **Fix**: Set the `PYTHONUNBUFFERED` environment variable to `1`. This forces the streams to be unbuffered, ensuring immediate log visibility.
- **Implementation**:
  - **Dockerfile**: `ENV PYTHONUNBUFFERED=1`
  - **K8s Manifest**: Add `env: - name: PYTHONUNBUFFERED value: "1"` to the container spec.

### PowerShell vs POSIX Redirects (head/grep)
- **Symptom**: Chained commands like `kubectl exec <pod> -- cat /app/main.py | head` fail with `head: The term 'head' is not recognized`.
- **Root Cause**: On Windows, PowerShell is the default shell for `run_command` tools. It does not recognize POSIX-specific utilities like `head`, `tail`, or `grep` as native cmdlets.
- **Fix**: Use PowerShell equivalents or execute the entire chain inside the container's shell.
- **Examples**:
  ```powershell
  # PowerShell way (Select-Object)
  kubectl exec <pod> -- cat /app/main.py | Select-Object -First 10

  # Container-Shell way (Recommended for complex pipes)
  kubectl exec <pod> -- sh -c "cat /app/main.py | head -n 10"
  ```

### TUI: Gateway timeout (2s) during Task Creation
- **Symptom**: User hits 'L' in TUI, dashboard loads (cluster appears active), but pressing 'N' to create a task results in `Gateway timeout (2s)`.
- **Diagnosis**: 
    1. **Check Port-forwards**: Run `Get-Job` in PowerShell. If no jobs are found matching `port-forward`, the tunnels have died or were never started for the current session.
    2. **Verify Health via Curl**:
       - `curl http://localhost:3000/healthz` (Gateway)
       - `curl http://localhost:8080/health` (Read Model)
    3. **Dashboard vs. Gateway**: The TUI dashboard might show data from a previous state or successfully pull from Read Model (8080) while Gateway (3000) is down.
- **Root Cause**: **Ephemeral Port-Forwarding Hazard**. Port-forwards are session-scoped when started via `Start-Job`. If the TUI session that started them is gone, or if they were never started (due to `ClusterStatus::Ready` bypass), the TUI will timeout when trying to POST to the Gateway. See [Local Orchestration Health Parity](./local_orchestration_health_parity.md) for the architectural standard.
- **Implementation Detail**: The TUI's `submit_job()` function (in `src/interfaces/tui/src/cluster.rs`) uses a hardcoded **2.0 second timeout**. In high-latency or stalled environments, this threshold may be hit before the Gateway responds.
- **Verification (Manual curl)**: If health probes pass but task creation still fails, verify the endpoint directly. Note that the Gateway requires a JSON payload with a unique `id` (usually a UUID v4).
  ```bash
  # Test Gateway POST (replace with a unique ID)
  curl -s -X POST http://localhost:3000/jobs \
    -H "Content-Type: application/json" \
    -d '{"id": "550e8400-e29b-41d4-a716-446655440099", "type": "DIAGNOSTIC_JOB"}'
  ```
- **Remediation**: Run `.\scripts\start-all.ps1` manually to re-establish background port-forwards, or use `odd-dashboard doctor` (if implemented).

### Hardcoded Orchestration Hazard (Refresh Loop)
- **Symptom**: TUI reports "Service Unavailable" or stalls when dashboard services (Prometheus, Gateway) are running on non-standard ports or when port-forwarding is flaky.
- **Root Cause**: Hardcoded URLs in the UI's polling loop (e.g., `refresh()` method in Rust/Node). If the application expects `http://localhost:9090` but the environment uses a different port or requires a specific IP, the TUI will fail silently or display stale data.
- **Diagnosis**: 
  1. Check `src/interfaces/tui/src/types.rs` for `reqwest` calls.
  2. Verify if the URLs are configurable via environment variables or CLI flags.
- **Remediation**: Transition hardcoded strings to a configuration struct populated by environment variables (`PROMETHEUS_URL`, `GATEWAY_URL`).

### PowerShell: JSON API Testing (Invoke-RestMethod)
- **Problem**: Using `curl` for JSON POST requests on Windows often leads to complex escaping issues (e.g., `SyntaxError: Expected property name or '}' in JSON at position 1`).
- **Fix**: Use PowerShell's `Invoke-RestMethod` and `ConvertTo-Json`. This handles complex objects and headers cleanly without manual escaping.
- **Example (E2E Job Submission)**:
  ```powershell
  $body = @{
      id = "550e8400-e29b-41d4-a716-446655440099"
      type = "TEST_JOB"
      status = "PENDING"
      createdAt = "2025-12-25T08:00:00Z"
  } | ConvertTo-Json

  Invoke-RestMethod -Uri "http://localhost:3000/jobs" -Method POST -Body $body -ContentType "application/json"
  ```
- **Pattern**: For manual verification of polyglot services on Windows, favor `Invoke-RestMethod` over `curl.exe` to avoid string-parsing hazards.

### Label / Selector Mismatch
- **Symptom**: `kubectl get pods` shows the pod is running, but `kubectl logs -l app=<name>` or `kubectl get pods -l app=<name>` returns "No resources found".
- **Diagnosis**: The deployment may use a non-standard label for its selector (e.g., `service: <name>` instead of `app: <name>`).
- **Fix**: Check the manifest or describe the pod to find the actual labels:
  ```powershell
  kubectl get pod <pod-name> --show-labels
  ```
  In ODTO, the `processor` deployment uses `service: processor` as the selector, necessitating `kubectl logs -l service=processor`.

### REST Endpoint Path Mismatch (404)
- **Symptom**: A service returns `404 page not found` when accessed via a known port, even though the service is running and connected to its dependencies.
- **Root Cause**: Divergence between the API producer (e.g., Go Read Model) and consumer (e.g., Rust TUI) regarding pathing conventions (e.g., `/jobs` vs `/jobs/recent`).
- **Diagnosis**: 
  1. Inspect the service source code (e.g., `main.go`) for `http.HandleFunc`.
  2. Use `curl` to test the explicit paths found in the source.
- **Remediation**: Align the consumer's request URL with the producer's routing table.

### Definitive State Verification (PostgreSQL)
- **Symptom**: `kubectl logs` is silent (see [Silent Python Container](#the-silent-python-container-buffering)) or ambiguous, and you need to know if a job was actually processed.
- **Root Cause**: Logs may be buffered or metrics may be delayed. The database is the authoritative source of truth for job lifecycle completion.
- **Diagnosis**: 
  1. Identify the pod: `kubectl get pods -l service=postgres` (usually `postgres-0`).
  2. Execute a query directly against the task database.
- **Verification Commands**:
  ```powershell
  # Check recent jobs and their status
  kubectl exec -it postgres-0 -- psql -U admin -d task_db -c "SELECT id, type, status, created_at FROM jobs ORDER BY created_at DESC LIMIT 5;"

  # Verify a specific job reached 'COMPLETED'
  kubectl exec -it postgres-0 -- psql -U admin -d task_db -c "SELECT status FROM jobs WHERE id = '550e8400-e29b-41d4-a716-446655440099';"
  ```
- **Pattern**: When debugging "Silent Failures" or verifying fixes in buffered environments, bypass the logging layer and verify the side-effects in the persistence layer.

### Pod CrashLoopBackOff: Service-Specific Diagnostics
- **Symptom**: Pods reach the `Running` state but quickly transition to `CrashLoopBackOff`, stalling the setup progress (e.g., `13/15 pods ready`).
- **Node.js / TypeScript (Gateway)**:
    - **Error**: `Error: Cannot find module '/app/index.js'`.
    - **Cause**: The code was migrated to TypeScript, but the Dockerfile's `CMD` still points to the `.js` entry point while the compilation step (e.g., `tsc`) either failed silenty or placed the output in a different directory.
    - **Fix**: Ensure `RUN npx tsc` is included. If `tsconfig.json` specifies `"outDir": "./dist"`, the `CMD` must point to the output subdirectory (e.g., `CMD ["node", "dist/index.js"]`). Stale `CMD ["node", "index.js"]` entries in migrated `Dockerfiles` are a frequent cause of `MODULE_NOT_FOUND` in containerized polyglot environments.
    - **Missing or Misplaced VERSION file**: If the app fails with `FATAL: Failed to load VERSION file: ENOENT ... '/app/dist/VERSION'`, ensure the `VERSION` file is copied to the specific execution directory (e.g., `dist/`) in the `Dockerfile`. Simply copying to `/app/VERSION` is insufficient if the runtime uses `__dirname` from a subdirectory.
    - **AJV Strict Mode & Custom Keywords**: If the gateway crashes with `Error: strict mode: unknown keyword: "$version"`, this indicates that the JSON schemas contain custom keywords (like `$version`) not recognized by AJV's default strict mode.
        - **Fix**: Update the `Ajv` constructor in the service (e.g., `index.ts`) to include `{ strict: false }`.
        - **Implementation**: `const ajv = new Ajv.default({ strict: false }) as any;`
- **Python (Processor)**:
    - **Error**: `ModuleNotFoundError: No module named 'schema_validator'`.
    - **Cause**: A local dependency or sub-module (like a shared validator) was not copied into the Docker build context.
    - **Fix**: Add explicit `COPY` commands for all local dependencies and subdirectories used by the main script (e.g., `COPY src/services/processor/schema_validator.py ./` and `COPY src/services/processor/schemas ./schemas/`). Missing metadata or schema folders can cause runtime failures even if the main entry point is present.
    - **Local Build Context Failure**: If `docker build` fails with `COPY failed: file not found ... contracts`, it is because the shared monorepo directory is outside the service build context. Developers must manually copy `contracts/` into the service directory before building locally, or use the provided `start-all.ps1` automation.
    - **Missing VERSION file**: If the app fails with `FATAL: Failed to load VERSION file: [Errno 2] ... '/app/VERSION'`, ensure `VERSION` is explicitly copied in the `Dockerfile` (`COPY src/services/processor/VERSION ./VERSION`).
- **Go (Metrics Engine / Read Model)**:
    - **Fix**: Update the `Dockerfile` to copy the `VERSION` file (e.g., `COPY VERSION /VERSION`). Ensure the path in the code matches the location in the container.
    - **Distroless Health Check Failure**: If a Go service in a distroless image fails its Docker Compose health check with `exit code 1` or `executable file not found`, it is because `wget` or `curl` are missing from the image.
    - **Resolution**: Transition to **Externalized Health Checks**. Remove the health check from `docker-compose.yml` and perform readiness probing via the integration harness (HTTP GET /health from the Docker host). This preserves the minimal footprint of distroless while maintaining verification integrity.
    - **Postgres SSL Failure**: If the service logs `pq: SSL is not enabled on the server` and hangs.
    - **Fix**: Update the `POSTGRES_URL` in the compose file or environment to include `?sslmode=disable`.
- **Diagnosis**: Use `kubectl logs <pod-name> --tail=20` to see the exact runtime exception causing the crash.

## The 14/15 Readiness Stall

A recurring phenomenon in the "Self-Launching" flow is the **14/15 Readiness Stall**, where the TUI reports 14 out of 15 pods are ready and the process hangs for the duration of the timeout (10 minutes).

### Identifying the Failure
1. **Visual Confirmation**: Use a separate terminal to run `kubectl get pods --no-headers`.
2. **Targeting the 0/1 Pod**: Look for the pod with `0/1` readiness and a state of `CrashLoopBackOff` or `Pending`.
3. **Common Culprits**:
    - **Gateway**: Frequently the last pod to start; crashes here are often due to pathing issues in the compiled TypeScript (`dist/index.js`) or missing metadata/VERSION files.
    - **Processor**: Crashes often related to missing local Python modules or schemas not being copied into the build context.

### Recovery Pattern
1. **Log Inspection**: `kubectl logs <pod-name> --tail=50`.
2. **Context Cleanup**: If a previous failed run left stale state, run `kind delete cluster --name task-observatory` and restart the TUI.
3. **Image Verification**: Run `kubectl describe pod <pod-name>` to check the exact image name and tag Kubernetes is looking for.
4. **Tag Alignment**: If the state is `ErrImageNeverPull`, confirm that the Docker build produced a tag matching the manifest (e.g., `processor:0.1.0` vs generic `processor:latest`). ODTO uses version-synced tagging (refer to `Foundation Infrastructure`).

## 📡 TUI & Orchestration Patterns

### Optimistic Cluster Detection vs. App Readiness
- **Symptom**: The TUI skips the "Setup Progress" view and goes directly to the Dashboard, but all statistics show `0` or errors, and Web UIs (localhost:8081, etc.) fail to load.
- **Root Cause**: The TUI's `check_cluster_status()` logic may only verify the existence of the Kind cluster nodes (`kubectl get nodes`). If the cluster exists (e.g., from a previous manual `kind create cluster`) but the application manifests have not been applied, the TUI assumes the system is "Ready".
- **Result**: Because the setup script (`start-all.ps1`) is never triggered by the TUI, the automated port-forwarding logic is skipped, and the required application pods remain undeployed.
- **Fix (Manual)**: Run the setup script manually to ensure manifests are applied and port-forwards are established:
  ```powershell
  .\scripts\start-all.ps1
  ```
- **Fix (Automation)**: Enhance `check_cluster_status()` to verify at least one application pod (e.g., `gateway` or `web-ui`) exists in the `default` namespace. This introduces the `ClusterStatus::NoPods` state, which forces the TUI into `AppMode::Launcher` even if the Kind nodes exist.

### Background Port-Forwarding Automation
- **Symptom**: Port-forwards work initially but die after the setup script completes.
- **Insight**: As documented in [Ephemeral Port-Forwarding](#ephemeral-port-forwarding-in-orchestration), PowerShell `Start-Job` is session-scoped. 
- **Verification**: If Web UIs are unreachable, use `Get-Process kubectl` to see if the background forwarders are still alive. If not, the orchestration failed to decouple the processes from the script's terminal session.

## 🛡️ Modern CI/CD & Development Footguns (v1.0.1)

### Git: Diverged Local Main after PR Merge
- **Symptom**: `origin/main` is ahead/diverged from local `main`, and `git status` shows unmerged paths or mismatched commits after a merge PR is closed.
- **Root Cause**: Occurs when a commit is locally `amended` after it has been pushed to a branch, and that branch is then merged (via squash or regular merge) into `main` on GitHub. The remote `main` now contains a different hash than the local `main`'s original or amended commit.
- **Fix**: Reset local `main` to match the remote:
  ```powershell
  git checkout main
  git fetch origin
  git reset --hard origin/main
  ```
- **Pattern**: Avoid amending commits on branches that are actively being reviewed or integrated. If divergence occurs, authoritative reset to `origin/main` is the safest recovery.

### TUI: Slow Test Suite Regression (The 128s Stall)
- **Incident**: TUI test suite duration ballooned from <1s to 128s during the v1.0.1 cycle.
- **Root Cause**: Inclusion of a "unit" test in `install.rs` that invoked a live `execute_install_with_output` command (e.g., `brew install docker`). In CI/macOS environments, this triggered a network-heavy installer in the background.
- **Prevention**: Strictly isolate side-effects from the unit test suite. Use **Structural Verification** (testing known early-exit error paths like "Tool Not Found") to exercise orchestration logic without spawning host processes.
- **Verification**: Ensure `cargo test` returns in <1s for local development.

### TUI: Coverage Gate Calibration (cargo-tarpaulin)
- **Error**: `ERROR cargo_tarpaulin: Coverage is below the failure threshold`
- **Context**: Occurs in CI when `cargo tarpaulin --fail-under X` is higher than the actual code instrumentation.
- **Diagnosis**: TUI code has a high density of rendering (Ratatui) and I/O logic that is difficult to hit in standard unit tests without a virtual terminal.
- **Remediation**: 
    1. Calibrate the threshold to the current verified baseline (e.g., **14%** for ODTO v1.0.x).
    2. Focus coverage expansion on `types.rs` (state transitions) and `doctor.rs` (logic) rather than main loop rendering.
    3. Update `.github/workflows/ci.yml` if the threshold causes cascading failures despite tests passing.

### TUI: Ghost Coverage Gate (Release Failure vs CI Success)
- **Problem**: Release workflow fails with "Coverage 14.75% < 50.00%" even after you locally changed the threshold to 14%.
- **Diagnosis**: 
    1. **Git De-sync**: You amended a commit or performed a `git reset --hard` that reverted the `ci.yml` change on your local `main` branch, but a PR was previously merged to `origin/main` that still contained the high (50%) threshold.
    2. **Release Visibility**: Release workflows often trigger from tags or the `main` branch. If the fix was pushed to a feature branch but the release starts from an older `main`, the failure persists.
- **Verification**: Run `grep 'fail-under' .github/workflows/ci.yml` on the actual branch being released (usually `main`) to confirm the value.
- **The Tag-Time Trap**: If a release fails after you've merged the fix to `main`, check the **Git Tag**. Tags are immutable snapshots. If `semantic-release` cut `v1.1.0` from a commit *just before* your fix was merged, the `v1.1.0` tag still has the 50% threshold and will continue to fail.
- **Authoritative Recovery**: To fix a broken release gate on a tag:
    1. Delete the failed tag (`git push --delete origin vX.Y.Z`).
    2. Confirm the fix is on `main`.
    3. Re-trigger the release workflow to cut a new tag (or a patch version) with the correct metrics.
### Stuck Background Processes (Git / Multi-Stage Tasks)
- **Symptom**: An orchestration script or CI job hangs indefinitely (e.g., `git commit` running for 59+ minutes).
- **Common Cause**: 
    1. **Invisible Prompts**: Background `git` commands may trigger credential or GPG signing prompts that are not visible in the redirection pipe/shell host.
    2. **Orphaned Processes**: Interrupted scripts may leave background tasks (like `kubectl port-forward` or `bazel server`) running, which then hold locks or prevent new instances from starting.
- **Diagnosis**: 
    - Windows: `Get-Process | Where-Object { $_.StartTime -lt (Get-Date).AddMinutes(-30) }` to find stale processes.
    - Check if `git commit` or `gh` processes are waiting for TTY.
- **Fix**: Terminate the stuck process ID manually or using the orchestrator's stop-task utility.
- **Prevention**: Always use non-interactive flags (e.g., `-m "message"` for git commit) and ensure credential helpers are correctly configured for automated environments (PowerShell/CI).

### Windows Compilation Lock (os error 5)
- **Symptom**: `cargo build` or other linker operations fail with `Access is denied. (os error 5)`.
- **Root Cause**: The executable is currently being run by the OS or a debugger, locking the file on disk.
- **Diagnosis**: Check if the TUI or service is currently open. On Windows, this is a hard lock.
- **Fix**: Force-kill the process before rebuilding:
  ```powershell
  Get-Process -Name <binary-name> -ErrorAction SilentlyContinue | Stop-Process -Force
  ```
- **Pattern**: For "Single-Click" developer experiences, build scripts should proactively check for and terminate existing processes to avoid linker failures.

## 📦 Polyglot Dependency & Environment Management

### npm install: Husky Prepare Trap (monorepos)
- **Error**: `npm error command failed ... cd $( git rev-parse --show-toplevel ) && husky install ... The system cannot find the path specified.`
- **Context**: Occurs when running `npm install` inside a service subdirectory of a monorepo that has a root-level `prepare` hook for Husky.
- **Root Cause**: The root hook tries to resolve the git root relative to its own location, which often fails when triggered from a nested folder in certain shells (e.g., Windows CMD vs. Git Bash).
- **Fix**: Bypass lifecycle scripts for sub-service installations:
  ```bash
  cd src/services/gateway && npm install --ignore-scripts
  ```
- **CI Pattern**: In GitHub Actions or restricted environments, use the following to ensure clean installs without side-effect failures:
  ```bash
  npm ci --ignore-scripts || npm install --ignore-scripts
  ```
- **Shadow Failure Handling**: In monorepos, `npm install` may exit 0 even if it failed to populate `node_modules` correctly (due to pre-existing lockfile errors or platform-specific hook failures). Always verify critical dependencies exist if build errors persist (see [TypeScript: Missing Dependency Types](#typescript-missing-dependency-types)).

### TypeScript: Missing Dependency Types
- **Error**: `error TS2307: Cannot find module 'X' or its corresponding type declarations.`
- **Discovery**: The `package.json` contains the `@types/X` dependency, but `tsc` still reports it as missing.
- **Diagnosis**: 
    1. Check if source folders containing library logic (e.g., `lib/`) are missing from the `include` array in `tsconfig.json`.
    2. Check if an explicit `types` array is present in `compilerOptions`, which might be blocking auto-discovery.
    3. **Shadow Failure**: Verify the files actually exist in `node_modules`. If the directory is empty or missing despite a success exit code, the installation failed silently.
- **Fix**: Explicitly scope the `tsconfig.json` to include library folders (e.g., `"lib/**/*.ts"`). Prefer **auto-discovery** of types over explicit listing.
- **Verification (CI)**: Add an explicit check after install: `ls node_modules/@types/node || (echo "FAILED" && exit 1)`.

### TypeScript: Cannot find type definition file (TS2688)
- **Error**: `error TS2688: Cannot find type definition file for 'node'`.
- **Root Cause**: An explicit `types` array was added to `tsconfig.json` (e.g., `"types": ["node"]`), but the compiler cannot locate the corresponding package in the expected path, or the explicit list is preventing the compiler from searching standard `node_modules` locations.
- **Fix**: Remove the explicit `types: [...]` property from `compilerOptions`. TypeScript will automatically discover all packages in `node_modules/@types` by default.

### TypeScript: Ajv Schema Dynamic Load Failure
- **Error**: `error TS2769: No overload matches this call. ... Argument of type 'unknown' is not assignable to parameter of type 'AnySchema'.`
- **Root Cause**: Passing the output of `JSON.parse(readFileSync(...))` directly to `ajv.compile()` in strict mode. The parser returns `any` or `unknown`, but Ajv expects a specific schema type.
- **Fix**: Cast the schema to `any`:
  ```typescript
  const schema = JSON.parse(readFileSync(path, 'utf8'));
  const validate = ajv.compile(schema as any);
  ```
### Package-Lock Corruption (Intractable Shadow Failures)
- **Symptom**: `sh: 1: vitest: not found` or similar "binary missing" errors occur in CI even after `npm ci` reports success. This indicates that the environment-specific logic within a stale `package-lock.json` is preventing a full installation.
- **Fix**: Perform a **Nuclear Regeneration** of the lockfile:
  ```powershell
  # Local cleanup
  Remove-Item -Recurse -Force node_modules
  Remove-Item -Force package-lock.json
  # Fresh installation
  npm install
  # Commit the NEW package-lock.json
  ```
- **Verification**: This ensures that all dependency graph metadata is rebuilt from scratch, eliminating desynchronization between `package.json` and the lockfile. A tell-tale sign of corruption is an massive delta (e.g. >5000 lines change) when running a fresh `npm install` on a previously "working" lockfile.

### The "P1 Badge Check" Stall
- **Symptom**: The integration harness or `integration-gate.ps1` hangs until timeout while waiting for a service to become healthy, even though the container logs show the service started successfully.
- **Root Cause**: The service health endpoint (e.g., `/healthz`) changed from returning a plain string `OK` to a JSON object `{"status":"ok"}`, and the test harness assertion `$health -eq "OK"` fails to handle the object/JSON structure.
- **Fix**: Update the harness assertion to handle both formats:
  ```powershell
  $healthy = ($health -eq "OK") -or ($health.status -eq "ok")
  ```
- **Verification**: Ensure the harness logs show `[PASS] Gateway HTTP Health` immediately after service startup.

### CI Verbose Installation Trace
- **Pattern**: When `npm install` behavior in CI differs from local behavior despite lockfile parity, use a "Loud Install" pattern to inspect the environment.
- **Implementation (YAML)**:
  ```yaml
  - name: Install with debug info
    run: |
      node --version && npm --version
      npm ci --ignore-scripts || npm install --ignore-scripts
      ls node_modules/.bin/vitest || (echo "FAILED" && exit 1)
  ```
- **Goal**: Direct observability into the `node_modules` state after an apparently successful setup.

### Integration Harness: CI Compatibility (Run-from-Source)
- **Symptom**: The integration harness (`integration-harness.ps1`) fails in CI with `[FAIL] Gateway HTTP Health` or `[FAIL] Read Model Health` timeouts, but passes locally. Docker logs show services failing to start.
- **Root Cause**: The `docker-compose.integration.yml` uses volume mounts (`./src/services/X:/app`) and starts services via raw commands (e.g. `npm start`, `go run .`). This works locally where build artifacts or toolchains are available, but fails in minimalist CI containers where TypeScript isn't compiled or the runtime image lacks the necessary compilers.
- **Fix (Strategic Resolution)**: 
  1. **Primary Compliance**: Maintain the harness as a **hard gate** to ensure loyalty to Invariants I3, I4, and I5.
  2. **Failed Pattern (Internalized Build)**: Attempted to compile inside containers (e.g., `npm install && npm run build` in `command:`). This **failed to stabilize** because startup alone consumed ~80s, leaving no room for the verification paths within the **90s I4 budget**.
  3. **Selected Path (Docker Hub)**: Transition the pipeline to use **Pre-built Docker images** (stored at `oddessentials/odto-*`). This decouples the build (transpilation/compilation) from the integration runtime, ensuring health checks pass against verified artifacts.
- **Reference**: See [`integration_harness_architecture.md`](./integration_harness_architecture.md#7-ci-enforcement--invariant-loyalty) for implementation details.
- **Verification**: The CI integration job transitions to green once the harness pulls pre-built binaries instead of attempting on-the-fly source builds.

### TUI Coverage: The 32% Milestone
- **Symptom**: `FAIL: tui coverage 31.96% below minimum 33%`
- **Root Cause**: The library-scoped denominator (582 lines) is high-density logic. While 31.96% is a massive leap from 14.8%, it fell just short of the optimistic 33% initial target.
- **Fix**: Ratified the threshold at **32%** in `coverage-config.json` and `INVARIANTS.md` as the official floor for high-integrity library logic.
- **Verification**: CI passes when the measurement tool reports ≥ 31.5% (rounding to 32%).

### TUI Coverage Metric Drift (Shadow Regression)
- **Symptom**: TUI coverage drops significantly (e.g. from 33% to 14%) in CI despite no changes to library tests or logic.
- **Root Cause**: The CI command `cargo tarpaulin` is missing the `--lib --exclude-files src/main.rs` flags. This causes the tool to include the untestable `main.rs` binary in the denominator, diluting the percentage.
- **Fix**: Update `.github/workflows/ci.yml` to include the mandatory flags specified in `coverage-config.json`.
- **Verification**: Run `cargo tarpaulin --lib --exclude-files src/main.rs` locally to confirm the percentage matches the CI result after the fix.

## 10. Docker Hub Operations

Since Phase 19, the ODTO integration harness relies on pre-built images published to Docker Hub.

### 10.1 Manual Setup for Repository Owners
To enable automated image publishing, the following GitHub Secrets must be configured:
- `DOCKERHUB_USERNAME`: The Docker Hub organization or user (e.g., `oddessentials`).
- `DOCKERHUB_TOKEN`: A Personal Access Token with `Read & Write` permissions.

### 10.2 Rollback Procedures
If a regression is found in the published images that breaks the `integration-phase`:
1. **Manual Tag Recovery**: Re-tag a known healthy `:sha-<commit>` image as `:latest` in the Docker Hub registry UI.
2. **Harness Bypass**: Temporarily set the `integration-phase` trigger to `false` in `ci.yml` until a fix is pushed.
3. **Local Context Fallback**: Replicate the CI build locally by copying `contracts/` into the service directory before building (see Section 6.10).

## 11. Externalized Health Probes

### 11.1 Standardizing on Harness Probes
To ensure compatibility with distroless images (which lack `wget`/`curl`), ODTO designates the **Integration Harness** as the authoritative source of readiness.
- **Symptom**: `docker-compose up` hangs or app containers are marked "unhealthy" despite log evidence of readiness.
- **Fix**: Remove the `healthcheck` block from `docker-compose.integration.yml` for application services. Use the harness script's built-in `Invoke-RestMethod` retry loop to verify port accessibility.
- **Benefit**: Proof of "external accessibility" is a higher-integrity gate than "internal process check."
- **Transient 500 Errors during Gateway Startup**: If the harness fails P1 with a 500 error immediately after health checks pass.
    - **Cause**: The `/healthz` endpoint is reporting OK before the RabbitMQ channel is ready.
    - **Fix**: Ensure the Gateway's health router is passed the `getChannel` dependency and returns a 503 status if the channel is null.
- **Read Model 500 Error: `pq: relation "jobs" does not exist`**: 
    - **Cause**: The Read Model is querying the database before the Write Model (Processor) has had a chance to initialize the schema.
    - **Observed Behavior (Phase 19)**: Even with bounded polling (30s budget), the Read Model may continue to return 500 if the Processor is delayed in processing its first job (which triggers table creation).
    - **Diagnostic Flow**:
        1. **Silent Processor**: If `docker logs odto-integ-processor` shows "No output", ensure `PYTHONUNBUFFERED=1` is set in the environment.
        2. **Queue Drain Analysis**: Run `docker exec odto-integ-rabbitmq rabbitmqctl list_queues`. If `jobs.created` has 0 messages but P1 passed, the message was successfully consumed.
        3. **Processing Verification**: If the queue is empty but logs are silent and the table is missing, use `docker image inspect oddessentials/odto-processor:latest --format='{{.Created}}'` to verify the image age matches the expected deployment version.
        4. **Environment Audit**: Check for mismatched `POSTGRES_URL` credentials or hostnames between services.
        5. **Connection Lifecycle**: Check for `pika.exceptions.AMQPConnectionError` in logs (see below).
    - **Fix (RESOLVED)**: In integration tests, increase the polling budget or ensure a "warm-up" period (5s+) after health checks pass but before the first job is submitted. The integration harness now treats 500 errors as retryable "Waiting for settled state" conditions. **Verified**: 12/12 pass achieved after adding symmetric retries and budget polling.
- **Processor Error: `pika.exceptions.AMQPConnectionError` (RESOLVED)**:
    - **Cause**: The Processor attempt to connect to RabbitMQ occurs before the Broker is ready for AMQP protocol traffic, despite the container being "healthy".
    - **Symptom**: Logs show a traceback ending in `AMQPConnectionError`.
    - **Fix**: Implement a connection retry loop in the Processor's `main()` function (as implemented in Phase 19) to ensure symmetric retries for both PostgreSQL and RabbitMQ. This ensures the service doesn't crash if the containers report health but the protocols aren't ready.
- **Gateway TypeScript Error TS2554 in Tests**: `Expected 2 arguments, but got 1` when calling `createHealthRouter`.
    - **Cause**: The signature for `createHealthRouter` was updated to require a `getChannel` dependency, but unit tests were not updated.
    - **Fix**: Update `__tests__/app.test.ts` to pass a (mock) `getChannel` function to the router factory.

## 12. CI Workflow "Ghost Checks" & Syntax Hazards

### 12.1 The "Checks (0)" PR Failure
- **Symptom**: A Pull Request is created, but no GitHub Actions checks are listed (or it says "Checks (0)").
- **Cause**: GitHub failed to load or parse the `.github/workflows/*.yml` files. This happens if there is a **YAML Syntax Error**, a **Duplicate Job ID**, or a **Character Encoding Conflict** (e.g., hidden Unicode characters).
- **Diagnosis**: 
    1. Check the GitHub Actions tab for "Workflow run failed to trigger" errors.
    2. Run local YAML validation: `python -c \"import yaml; yaml.safe_load(open('.github/workflows/ci.yml', encoding='utf-8'))\"`.
- **Fix**: 
    1. Ensure no circular dependencies in `needs: [...]` blocks.
    2. **Unique Job IDs**: Verify that every job ID in a workflow file is unique. Duplicate IDs (e.g., two `build-images:` blocks) render the entire workflow invalid.
    3. Verify special characters (emojis, smart quotes, box drawing) are safe and encoded in UTF-8.
    4. If `replace_file_content` or other automation edited the YAML, verify the indentation is still valid.

### 12.2 Python `UnicodeDecodeError` in CI Scripts
- **Symptom**: A governance script or inline CI command fails with `UnicodeDecodeError: 'charmap' codec can't decode...`.
- **Cause**: Python on Windows defaults to `cp1252` encoding. If a CI runner (or local machine) reads a UTF-8 file (like `ci.yml`) containing multi-byte characters without specifying the encoding, it crashes.
- **Fix**: Always use `open(path, encoding='utf-8')` in Python scripts.
- **Pattern**: Transition to **Explicit UTF-8 Automation Standard** (refer to Repository Standards Framework Pattern 31).

### 12.3 The "Gated Integration Gap" (Workflow Skips)
- **Symptom**: CI changes meant to fix integration tests or registry logic are "skipped" by the `integration-phase`, preventing verification.
- **Cause**: The `paths-filter` usually excludes `.github/workflows/` (Tier B) from the "critical" list (Tier A) to save resources. When the CI logic itself (e.g. `build-images` job) is the subject of the fix, the `compat_critical` output is false, causing the integration gate to skip.
- **Fix**: 
    1. Temporarily add the workflow file to the `services` or `schemas` filter in `ci.yml`.
    2. Manual override: Use a dummy change in a service file to trigger the filter.
    3. Transition the workflow to **Fail-Closed Workflow Gating** (Pattern 34), ensuring that changes to the "Gatekeeper" (the YAML itself) are treated as Tier A changes.

## 13. Visual Regression & Integration Failures (CI)

### 13.1 Step Timeout (5m)
- **Symptom**: Playwright step in CI terminates with "The action 'Run visual tests' has timed out after 5 minutes."
- **Root Cause**: Often a "Soft Lock" where the WebSocket server is alive but the PTY background task is stalled, OR the test is waiting for a DOM selector that was removed/renamed (e.g., `.connection-status`).
- **Diagnostic**:
    1. **Selector Check**: Verify if the spec's `waitForSelector` matches the HTML in `index.html`.
    2. **Log Correlation**: Match CI timestamp to `web-pty-server` logs. Look for `Connection Upgrade` without subsequent `PTY Spawn`.
    3. **Compose Completeness**: Ensure all required services (e.g., `web-pty-server` for WebSocket tests) are present in the `docker-compose.integration.yml` file used by CI.
    4. **Binary Availability**: If logs show "Success" on connection but no output follows, check if `PTY_TUI_BINARY` points to a reachable file inside the container. Use `/bin/bash` in `docker-compose.integration.yml` to rule out TUI build failures during integration.
    5. **Build Context Conflict**: If the Docker build fails with "missing source" errors for sibling directories (e.g., `interfaces/tui` from `services/web-pty-server`), verify `docker-compose.integration.yml` uses `context: .` (repo root) and the Dockerfile path is relative to that root.

### 13.2 Integration Budget Exceeded
- **Symptom**: `[BUDGET EXCEEDED] 90.7s > 90s` (Initial limit) or similar threshold breach.
- **Root Cause**: The integration suite (P1-P4 + now Phase 29 PTY tests) has grown beyond the initial 90s "Speed-of-Light" limit. Mandates an increase to 120s.
- **Remediation**: 
    1. **Calibrate Budget**: Increase the `INTEGRATION_BUDGET` variable in the harness or `ci.yml` if the overhead is legitimate (e.g. more proof paths).
    2. **Debounce Jitter**: Reduce `waitForTimeout` calls in specs to absolute minimums.

## 14. Docker Multi-Stage Hub Hazards (v3.0.1+)

### 14.1 Dockerfile Parse Error: Unknown Instruction: echo
- **Symptom**: `dockerfile parse error on line 86: unknown instruction: echo`
- **Root Cause**: A multi-line `RUN` command used literal newlines within an `echo` block. If the shell continuation backslashes (`\`) are missing or incorrectly placed, the Docker parser treats the next line of the shell script as a new Dockerfile instruction.
- **Fix**: Use `printf '%s\n'` with explicit backslash continuations for every line to ensure the entire block is treated as a single atomic `RUN` instruction.
- **Verification**: `docker build` succeeds without parse errors.

### 14.2 Build Context Mismatch: "/VERSION": not found
- **Symptom**: `ERROR: failed to calculate checksum ... "/VERSION": not found` or similar errors for `lib/`, `contracts/`, or `Cargo.lock`.
- **Root Cause**: The service Dockerfile expects a build context relative to its own directory (e.g., `services/gateway`), but the build is executed from the repository root (to allow access to shared components like `contracts/`).
- **Remediation**:
    1. **Context Alignment**: Ensure all build commands use the repo root (`.`) as context.
    2. **Dockerfile Pathing (Verified)**: Update `COPY` instructions in the Dockerfile to use paths relative to the repo root (e.g., `COPY src/services/gateway/VERSION ./`). 
    *   *Example (Gateway Fix)*:
        ```dockerfile
        # Context is repo root (.)
        COPY src/services/gateway/package.json ./
        COPY src/services/gateway/index.ts ./
        COPY src/services/gateway/lib ./lib/
        ```
    3. **Consistency Check**: Periodically run `Select-Object -Last 50` on build output to identify failing stages.

### 14.3 Image Load Failure: "not present locally"
- **Symptom**: `[!!] [load] Failed to load <image>:latest: ERROR: image: "<image>:latest" not present locally`
- **Context**: Occurs when running `./scripts/start-all.ps1 -SkipBuild`.
- **Root Cause**: The script is instructed to skip the build step, but the required Docker image is missing from the local daemon (likely due to a previous build failure or a `docker system prune`).
- **Fix**: Run the startup script *without* `-SkipBuild` at least once to ensure images are created and present for the `kind load` step.

### 14.4 PTY Server Hang: "spawn check passed" never appears
- **Symptom**: `web-pty-server` logs show configuration but stop before "WebSocket server listening". The container is reported as "unhealthy". Nginx logs show `Connection refused` for `/ws`.
- **Root Cause**: The `web-pty-server` implements a **Fail-Fast Validation** (Pattern 45) that attempts to execute the `PTY_TUI_BINARY` with `--help` to verify it is executable. If the binary is a mock (shell script) that implements an infinite loop WITHOUT handling the `--help` flag, the `validate_tui_binary()` function hangs indefinitely waiting for the mock to exit.
- **Fix**: Update the mock binary (usually in the `Dockerfile`) to explicitly handle `--help`, `-h`, and `--version` flags by exiting with code 0.
- **Verification**: Restart the container and verify logs show: `INFO PTY_TUI_BINARY validated: ... (spawn check passed)`.

### 14.5 Terminal Visual Drift: Locale Warnings
- **Symptom**: Visual tests fail due to "unexpected text" appearing at the top of the terminal. Page snapshots show `bash: warning: setlocale: LC_ALL: cannot change locale (en_US.UTF-8)`.
- **Root Cause**: Minimal Docker images (e.g., `debian-slim`) often lack the `locales` package. When a mock shell script starts, the shell attempts to set the locale and fails with a warning to `stderr`, which xterm.js dutifully renders.
- **Fix**: 
    1. **Container Fix**: Install `locales` in the Dockerfile.
    2. **Mock Fix**: Add `export LC_ALL=C.UTF-8` and `exec 2>/dev/null` to the top of the mock bash script to suppress system-level noise. (Reference: Hardened Pattern 45.1).

### 14.6 Erlang / RabbitMQ Startup Failure
- **Symptom**: `dependency failed to start: container odto-integ-rabbitmq exited (1)`. Logs show: `Kernel pid terminated (application_controller) ("{application_start_failure,rabbitmq_prelaunch,...")`.
- **Root Cause**: Transient Erlang distribution or runtime error during RabbitMQ initialization (often related to hostname resolution or lock contention in the Docker network).
- **Fix**: Perform an **Idempotent Infrastructure Reset** (Pattern 46 in Standards):
  ```bash
  docker compose down -v
  docker compose up -d
  ```
- **Philosophy**: This is a `RETRYABLE_TRANSIENT` failure. Following the **Principle of Least Intervention** (Section 16), avoid modifying the RabbitMQ configuration or orchestration logic unless the failure persists across multiple clean resets.

### 14.7 Image Tag Discrepancy (latest vs versioned)
- **Symptom**: Pods fail with `ErrImageNeverPull` or `ImagePullBackOff`. 
- **Incident**: Kubernetes manifests in `infra/k8s/*.yaml` expect versioned tags (e.g. `gateway:0.1.0`), but local build scripts (`start-all.ps1`) produce `:latest` images when run with defaults or when loading into Kind nodes.
- **Root Cause**: Desynchronization between the orchestration script's build/tag logic and the manifest's `image` fields.
- **Fix**: 
    1. **Align Manifests**: Update standard Kubernetes manifests to use `:latest` for local development.
    2. **Orchestration Logic**: Update `start-all.ps1` to use the `VERSION` file for tagging if versioned images are required, ensuring the built tag matches the manifest EXACTLY.
    3. **Kind Load**: Ensure the exact tag (including version) is passed to `kind load docker-image`.

- **Pattern**: Maintain a **Rigid Naming Contract** (Pattern 9 in Distribution Patterns) where the producer (Build script) and consumer (K8s manifest) use a single source of truth for versions.

### 14.8 Mock vs. Real Visual Drift (PTY Mirror)
- **Symptom**: Visual tests pass on local dev machines but fail in CI on almost every terminal snapshot, even when "Connected" status is achieved.
- **Root Cause**: The verification harness (`docker-compose.integration.yml`) defaults to `target: mock` for the PTY server to reduce CI build times. The mock TUI outputs generic heartbeats, while local tests (running against the real cluster) expect the high-fidelity ODTO dashboard.
- **Fix**: Transition the integration harness to use the `real` build target for the PTY server. 
  - Edit `docker-compose.integration.yml`: Change `target: mock` to `target: real`.
- **Benefit**: Ensures that "What we prove visually is what we deliver," eliminating the need for divergent golden snapshots for mock environments. (Reference: Visual Regression Strategy Section 3.5).

### 14.9 Terminal Reconnect Loop (Max Sessions Spam)
- **Symptom**: Web Terminal logs show rapid `INFO Created session`, `WARN Reconnect attempted`, and `INFO Client closed connection` messages. The UI may display "Error: Too many sessions. Please close other tabs."
- **Root Cause**: A high-frequency reconnect loop triggered by client-side retry logic following a connection drop (e.g., a `Hangup` signal from the PTY). If the server-side session cleanup is slower than the browser's reconnect attempt, new sessions are spawned until the `GLOBAL_CAP` or `PER_IP_CAP` is reached.
- **Investigation**: Logs show `PTY child exited: ExitStatus { code: 1, signal: Some("Hangup") }`. This confirms the PTY is exiting when the socket closes, but the client is not successfully resuming the session, potentially due to missing or mismatched `reconnectToken` in `sessionStorage`.
- **Fix (Draft)**: 
    1. **Exponential Backoff**: Hardened client-side `reconnectDelay` to prevent rapidfire retries.
    2. **Cleanup Gating**: Enforced stricter session cleanup on the server to prevent "Ghost Sessions" from blocking new connections.
    3. **Token Persistence**: Verified `sessionStorage` persistence of `pty_session` and `pty_token` to ensure resumes are attempted before spawning new PTYs.

### 14.12 Containerized Session Exhaustion (Max Sessions Reached)
- **Symptom**: The terminal displays `Error: Maximum sessions reached`. CLI logs show `INFO GLOBAL_CAP reached` for the `web-pty-server`.
- **Root Cause**: Stale or "zombie" PTY sessions occupying the global session pool. This often occurs during heavy visual regression testing or rapid browser refreshes if the PTY process termination doesn't propagate to the broker fast enough.
- **Immediate Fix**: Restart the `web-pty-server` container to force-clear the in-memory session registry:
  ```powershell
  docker compose -f docker-compose.integration.yml restart web-pty-server
  ```
- **Infrastructure Fix**: The PTY spawner uses a heartbeat/timeout mechanism. Ensure `SESSION_TIMEOUT_SECONDS` is calibrated to the environment (e.g. 30s for mirror, longer for dev).

### 14.10 TUI Prerequisite Check Crash (Inside Container)
- **Symptom**: The mirrored terminal shows a "Prerequisite Setup" screen (or crashes/hangs) instead of the ODTO Dashboard. Logs show `❌ Docker - Not found` or `Hangup` signals.
- **Root Cause**: The high-fidelity TUI performs a "Doctor" check at startup to find host tools (Docker, pwsh, kubectl, kind). These are not present in the minimal `web-pty-server` image.
- **Fix**: Enable **Server Mode** (Pattern 48).
    1. **TUI Change**: Implement `ODD_DASHBOARD_SERVER_MODE=1` to skip these checks.
        - Anchor: `doctor.rs:has_missing_prerequisites()`
        - Anchor: `main.rs:589` (Mode transition logic)
    2. **PTY Server Change**: Update `web-pty-server` to inject this ENV var into the PTY child process.
        - Anchor: `pty.rs:spawn_pty()`
- **Verification**: Run `docker exec -it odto-integ-web-pty /app/odd-dashboard` and verify it skips the setup screen and shows the "Server Mode: prerequisite checks skipped" banner.
- **Visual Drift (Refinement)**: If "Connected" status is achieved but colors or text alignment look "off" in CI snapshots:
    - **Check rendering envs**: Ensure the PTY spawner is injecting `TERM=xterm-256color`, `LANG=en_US.UTF-8`, and `COLORTERM=truecolor`. Missing these variables can cause the TUI to fall back to generic 16-color or ASCII modes, leading to snapshot failure.

### 14.11 TUI: Container Startup Hangs (The Zero-Probe Mandate)
- **Symptom**: TUI hangs at a blank screen or setup screen when running inside a Docker container (Mirror).
- **Diagnosis**: The TUI is likely attempting host-level command probing (`docker --version`, `kubectl`, etc.) for tools that don't exist in the minimal image, leading to shell timeouts or infinite loops.
- **Fix**: Ensure the `ODD_DASHBOARD_SERVER_MODE=1` environment variable is set. This triggers the **Zero-Probe Guarantee**, bypassing all `doctor.rs` checks.
- **Verification**: Run `cargo test doctor::tests::test_server_mode_never_spawns_commands_even_with_empty_path` locally to confirm the logic is intact.
- **API Connectivity Hazard**: If the TUI in Server Mode remains stuck on a "Not Ready" or "Cluster Setup Failed" screen despite services being healthy, check the **Service Name Resolution**. The TUI probes `READ_MODEL_URL` (usually `/stats`). If this is not explicitly passed to the `web-pty-server` in `docker-compose.integration.yml`, the TUI defaults to `localhost`, which fails within the container network. Ensure the service name (e.g., `http://read-model:8080`) is injected.
- **Container Image Staleness**: When developing improvements for the TUI binary (`odd-dashboard`) and verifying them via the `web-pty-server` mirror, `docker compose up` might fail to swap the binary if the container is already running and the image tag (`latest`) hasn't changed.
    - **Fix**: Use `docker compose -f docker-compose.integration.yml up -d --force-recreate [service]` to ensure the new image (with the updated binary) is actually deployed.
    - **Symptom**: TUI logs show the old behavior (e.g., attempting `kubectl` checks when it should be using API health) despite a successful local build/test.
- **Prometheus Unavailability Warning**: The TUI dashboard may show `⚠ Prometheus unavailable` in integration or visual regression environments.
    - **Cause**: The `docker-compose.integration.yml` environment may omit the Prometheus container to remain lightweight. The TUI's metrics engine attempts to poll Prometheus for detailed task history and alerts.
    - **Resolution (Phase 31)**: The `prometheus` service was added to the integration compose file to provide a 1:1 match with the production dashboard state.
    - **Contract**: The TUI handles Prometheus unavailability gracefully by falling back to Read Model API polling for basic job stats, ensuring the dashboard remains functional even without the full metrics stack.
- **Prometheus Hardcoding Hazard**: If Prometheus is running in the container network but the TUI still reports it as `unavailable`, check the **Endpoint Configuration**. 
    - **Incident**: The TUI was found to have hardcoded `http://localhost:9090` for alert polling, which failed inside the PTY container.
    - **Fix**: Implemented the `PROMETHEUS_URL` environment variable in `types.rs`. This must be injected into the PTY daughter process via the `web-pty-server` configuration (e.g. `http://odto-integ-prometheus:9090`).
- **Host-Path Mount Collision**: Containers may fail to start with the error `not a directory: Are you trying to mount a directory onto a file (or vice-versa)?`.
    - **Cause**: This occurs when a Docker Compose volume mount expects a file (e.g. `prometheus.yml`) but the path is missing on the host. Docker automatically creates a *directory* at that path if it doesn't exist, which then causes a collision if the container expects a file.
    - **Remediation**: 
        1. Check the host directory (e.g. `infra/prometheus/`).
        2. Delete any erroneously created directories that match your target filename.
        3. Create the file (e.g. `New-Item prometheus.yml`) before starting the container to ensure Docker performs a file-to-file mount.
- **The Blank Screen Paradox (Mirror-Specific)**: The web interface displays a connected terminal but shows no text or a frozen cursor.
    - **Cause 1: Orphaned Containers**: A `docker compose up --force-recreate` command may fail partway, leaving the terminal emulator (xterm.js) trying to connect to a container that was deleted but not yet replaced (`No such container: odto-integ-web-pty`).
    - **Cause 2: Shared Port Hazard**: Running the primary Kubernetes cluster (`start-all.ps1`) and the Integration Mirror (`docker-compose.integration.yml`) simultaneously on the same host can cause port collisions (e.g. both wanting 5432, 6379, or 9090).
    - **Resolution**: Always run `docker compose -f docker-compose.integration.yml down` before starting/resetting the K8s cluster, and vice-versa. Ensure only one orchestration environment is active to maintain deterministic isolation.
    - **Symptom Logic**: If the TUI "nothing on screen" persists, verify the `web-pty-server` logs. If the broker cannot spawn the PTY child because the binary is missing or the environment injection failed, it may silently fail to send the initial frame, resulting in a blank screen.
### 14.13 UI Registry Not Found (Project Root Hazard)
- **Symptom**: Pressing 'U' in the TUI (Server Mode/Mirror) shows the error `Registry not found: Could not find project root` or `Registry not found: Failed to read: ...`.
- **Root Cause**: The TUI's `load_ui_registry()` function (in `cluster.rs`) attempts to find the project root dynamically to locate `contracts/ui-registry.json`. In a containerized environment (like the `web-pty-server` image), the project structure is flattened, and the `.git` or `VERSION` file typically used to identify the root is absent.
- **Immediate Fix**: Ensure the PTY spawner is running in a directory where a fallback exists or the TUI has a compiled-in default.
- **Structural Fix (Phase 31)**: Implemented **Registry Bundling** for containerized TUI instances. The Dockerfile now copies `contracts/ui-registry.json` into `/app/contracts/` during the build process. Correspondingly, `find_project_root()` in `cluster.rs` was updated to recognize `/app` as the project root when running in Server Mode. This ensures that the UI launcher (shortcut 'U') remains fully functional in stateless mirrors without requiring manual volume mounts or out-of-sync hardcoded lists.
- **Verification**: In the mirror, press 'U' and verify that the launcher menu appears with all active entries (Grafana, Prometheus, etc.) populated from the authoritative JSON contract.

### 14.14 Playwright Parallelism Hazard (Session Cap)
- **Symptom**: Visual regression tests (`npx playwright test`) fail with `Error: Maximum sessions per IP reached` or `Too many sessions. Please close other tabs or try again later.` visible in the error context screenshots.
- **Root Cause**: Playwright runs tests in parallel by default. Each worker creates a WebSocket session.
- **Advanced Root Cause: Grace Period Accumulation**: Even with `--workers=1`, if the `PTY_DISCONNECT_GRACE_SECS` (default: 30s) is longer than the duration of individual tests, the broker will keep multiple "Disconnected" sessions alive for the same IP. A test suite of 13 tests will eventually hit a `PTY_PER_IP_CAP=5` around test 6.
- **Immediate Fix**: Restart the `web-pty-server` container to clear the state and run tests with a larger cap:
  ```bash
  # In docker-compose.integration.yml
  PTY_PER_IP_CAP: 20
  ```
- **Structural Fix**: Set `PTY_DISCONNECT_GRACE_SECS=0` in the integration environment to ensure sessions are reaped immediately upon browser close during automated tests.
- **Implementation Note**: This hazard confirms the effectiveness of the session capping logic but highlights the need for environment-aware scaling of throughput limits.



### 14.15 The WebSocket Blocking Route Trap (Visual Tests)
- **Symptom**: Fallback dashboard visual tests fail because the terminal successfully connects despite `await page.route('**/ws', route => route.abort())`.
- **Root Cause**: The route pattern `**/ws` is too specific. If the client uses query parameters (e.g., `?session=...`) or if the WebSocket is proxied/exposed on a different port (e.g. `9000`), the simple glob fails to match.
- **Advanced Root Cause**: In some CI environments or browser versions, `page.route` may fail to intercept the `Upgrade` handshake for WebSockets if it isn't specifically configured with a WebSocket handler.
- **The Greedy Fix**: Use broad glob patterns and explicitly block known port-specific routes:
  ```typescript
  await page.route('**/ws**', route => route.abort());
  await page.route('**:9000/**', route => route.abort());
  ```
- **The Authoritative Fix (v3.0.x)**: Override the `WebSocket` global in the browser context via `addInitScript` to simulate a failed connection. This bypasses the network layer entirely:
  ```typescript
  await page.addInitScript(() => {
      class FakeWebSocket {
          readyState = 3; // CLOSED
          onerror: ((e: Event) => void) | null = null;
          onclose: ((e: CloseEvent) => void) | null = null;
          constructor() {
              setTimeout(() => {
                  if (this.onerror) this.onerror(new Event('error'));
                  if (this.onclose) this.onclose(new CloseEvent('close', { code: 1006 }));
              }, 100);
          }
          send() {}
          close() {}
      }
      (window as any).WebSocket = FakeWebSocket;
  });
  ```
- **Context**: This ensures that failure modes can be deterministically tested even in complex proxied environments like the ODTO mirror.
- **The Hidden Fallback Race**: If tests continue to fail with `#fallback-container` being "hidden" despite the mock, it may indicate a race between the application's reconnection logic and Playwright's visibility checks. Ensure the mock triggers failure fast enough that the application doesn't cycle back to a "Connecting" state which hides the fallback UI before the snapshot is captured.


## 15. Polyglot Language Hazards (Rust/Go/Node)

### 15.1 Cargo: feature `edition2024` is required
- **Symptom**: `error: feature edition2024 is required ... not stabilized in this version of Cargo (1.83.0)`
- **Context**: Occurs during the `tui-builder` or `pty-builder` stages.
- **Root Cause**: A dependency (e.g., `moxcms` via `arboard` -> `image`) has adopted Rust Edition 2024, which requires Rust 1.85+ or Nightly.
- **Immediate Fix (Verified)**: Pin the intermediate dependency that pulled in the unstable crate. For `moxcms`, pinning `image` to `0.25.4` successfully removes the dependency on the unstable edition:
  ```bash
  # Run in the service directory (e.g., src/interfaces/tui)
  cargo update -p image --precise 0.25.4
  ```
- **Solution (Long-term)**: Update the base Docker image (e.g., `rust:1.85+`) once the edition is stabilized.
- **Pattern**: In polyglot monorepos, treat "Auto-updating dependencies" as a high-risk activity that can break container builds by introducing requirements for un-stabilized language features.

## 16. Governance: Principle of Least Intervention

**Goal**: Restore CI stability with minimal side effects by targeting the proximal cause of failure.

### The Challenge: Over-Engineering Remediation
When a CI break occurs (e.g., a Dockerfile parse error or a dependency conflict), there is a tendency to perform a "deep fix" (e.g., restructuring the entire build context or monorepo pathing). This often introduces new bugs or breaks platform-specific workflows that were previously stable.

### The Strategy: Proximal targeting
1. **Target the proximal error**: Fix the specific syntax error or pin the specific dependency.
2. **Verify the change**: Run local checks (`cargo check`, `docker build`) to confirm the specific error is gone.
3. **Revert secondary changes**: If a fix requires temporary changes to build scripts or global paths, revert them once the root cause is addressed, unless they are strictly necessary for the fix.
4. **Governance Gate**: Ask: *"Is this structural change required for the fix, or am I refactoring while the house is on fire?"*

**Benefit**: Faster mean-time-to-recovery (MTTR) and higher confidence in remediation commits.

## 13. Web Mirror Modernization (v3.1.x)

### 13.1 Docker Port Refusal after Image Launch
- **Symptom**: `docker run` reports success, but subsequent `curl` or `Invoke-WebRequest` fails with `Connection Refused` despite correct port mapping.
- **Root Cause**: **Initialization Lag**. Multi-stage images using heavy base images or complex healthcheck logic may take 2-3 seconds for internal processes (Nginx/Node) to actually bind to the interface.
- **Fix**: Implement an explicit `Start-Sleep -Seconds 2` (or exponential retry) in verification scripts between container launch and service probing.
- **Verification**: Ensure the container remains in `Up` status via `docker ps` to distinguish between a "race" and a "crash".

### 13.2 Asset MIME-Type Mismatches (application/javascript)
- **Symptom**: Console error `Refused to execute script from 'bundle.js' because its MIME type ('text/plain') is not executable`.
- **Cause**: Nginx default configuration or misconfigured `add_header` block in `nginx.conf`.
- **Fix**: Explicitly define the `location ~* \.js$` block and verify it precedes generic `text/plain` catches. Ensure the `X-Content-Type-Options: nosniff` header is present (standard security) and that the server is actually finding the file (a missing file often returns Nginx's default 404 page as `text/html`, which triggers the MIME mismatch).
- **Pattern**: Check the Nginx `error.log` inside the container (`docker exec -it <id> tail /var/log/nginx/error.log`) to confirm the filesystem path of the requested asset matches the Docker Stage 2 `COPY` destination.

### 13.3 Web UI CI Hermeticity Failures
- **Symptom**: The CI job `Web UI Build (Docker)` fails with `COPY failed: ... no such file or directory`.
- **Cause**: A new file or directory was added to `src/interfaces/web` but not explicitly permitted in the `Dockerfile` or it is being ignored by `.dockerignore`.
- **Fix**: 
  1. Check `.dockerignore` to ensure the required path isn't excluded.
  2. Verify the `Dockerfile` has the correct `COPY` or `ADD` instruction.
  3. Ensure the multi-stage "Builder" stage captures all necessary artifacts before they are needed by the "Runner" stage.
- **Verification**: Run `docker build .` locally within `src/interfaces/web` before pushing to confirm the build context is complete.

## 14. Test-Mode Diagnostics (Failure Injection)

**Goal**: Deterministically exercise UI fallback states (e.g., "WebSocket Offline") without relying on brittle browser-side mocking.

### 14.1 PTY Server Test Mode
The `web-pty-server` supports an authoritative `PTY_TEST_MODE` environment variable to simulate infrastructure failures.

- **`PTY_TEST_MODE=fail`**: The server will immediately reject all new WebSocket connection attempts. This is used to verify the frontend's fallback dashboard and retry logic.
- **`PTY_TEST_MODE=delay:<ms>`**: The server will inject a specified delay (in milliseconds) before completing the WebSocket handshake. Useful for testing timeout handling and loading states.
- **Query Parameter Override**: The server also supports `?test_mode=fail` in the connection URL. This allows per-request failure injection without restarting the server, perfect for Playwright tests.
- **Diagnostic Verification**:
  1. Set the env var in `docker-compose.integration.yml` or use the query parameter.
  2. Attempt a connection via the browser (e.g., `http://localhost:8081/?test_mode=fail`).
  3. Check PTY server logs: `Test mode (query): rejected connection from...` confirms the mode is active.
  4. **Build Verification**: If the query parameter is present in the browser URL but the server logs show a normal connection, ensure the `terminal.js` changes were built into the bundle: `grep "test_mode" src/interfaces/web/dist/bundle.js`.

## 15. Nightly Visual Testing Ops

**Goal**: Maintain high-fidelity visual snapshots without introducing flakiness into the critical PR path.

### 15.1 Workflow Maintenance (`nightly.yml`)
Visual regression tests are isolated in a dedicated nightly workflow to prevent "environmental jitter" from blocking merges.

- **Serialization**: The nightly job enforces `--workers=1` to ensure stable font rendering and TUI startup timing.
- **Snapshot Updates**: If a intentional UI change causes snapshot diffs, maintainers can trigger the workflow manually with the `update_snapshots: true` input.
- **Artifact Recovery**: On failure, download the `nightly-playwright-report` to view exact pixel-by-pixel comparisons.
- **Authoritative Environment**: Snapshots MUST be committed in the Ubuntu runner context (via CI) to ensure parity with subsequent automated runs. Snapshots generated on Windows/macOS local machines often contain font rendering artifacts that will fail in CI.

## 16. Rust: The Config Initializer Trap

**Symptom**: `error[E0063]: missing field '<field>' in initializer of 'config::Config'`. This error usually occurs in `auth.rs`, `pty.rs`, or `pty_task.rs` during tests or within library modules.

**Root Cause**: In several `web-pty-server` modules and test suites, the `Config` struct is instantiated manually for unit tests (e.g., in a `test_config()` helper) rather than being loaded from the environment. When a new field (like `test_mode`) is added to the `Config` struct in `config.rs`, every manual instantiation across the crate becomes a compile error.

**Fix**:
1. Search the entire `src/services/web-pty-server` directory for `Config {`.
2. Update every instance (e.g., in `auth.rs`, `pty.rs`, `pty_task.rs`, and `session.rs`) to include the new field with a sensible default for tests (typically `TestMode::None`).
3. **Best Practice**: Use a shared `test_config()` helper in a `tests/common` module (or similarly shared location) to centralize test configuration and reduce the blast radius of schema changes.

**Verification**: Run `cargo check` and `cargo test` to ensure all modules (including tests) compile.

## 17. Local Pre-Push Verification Workflow (v3.1.5)

**Goal**: Verify terminal UI changes across all tiers before pushing to CI/GitHub.

### 17.1 Tier 1 & 3: Smoke + Fallback Tests
These should be run before every push affecting the web terminal.

```powershell
# 1. Start the integration stack
docker compose -f docker-compose.integration.yml up -d

# 2. Wait for services (approx 45s)
# Tip: Check http://localhost:8081/health
while (!(Invoke-WebRequest -Uri "http://localhost:8081/health" -UseBasicParsing -ErrorAction SilentlyContinue)) { 
    Write-Host "Waiting..."; Start-Sleep 2 
}

# 3. Run Bundle Smoke Tests (Tier 1) and Fallback Dashboard (Tier 3)
cd tests/visual
npm ci
npx playwright test --grep "Bundle Smoke Tests|Fallback Dashboard"
```

### 17.2 Tier 2: Visual Regressions (Optional Local)
To verify visual consistency locally without waiting for the nightly CI run.

```powershell
# Run visual tests with single worker for stability
npx playwright test --grep "Web Terminal Visual Tests" --workers=1

# If intentional UI changes were made and snapshots need updating:
npx playwright test --grep "Web Terminal Visual Tests" --workers=1 --update-snapshots
```

### 17.3 Manual "Hard" Rejection (Test Mode)
Authoritative verification that the server-side failure injection is working.

1. Navigate to `http://localhost:8081/?test_mode=fail`.
2. Verify the **Fallback Dashboard** appears immediately with a "Retry Connection" button.
3. Check `web-pty-server` logs for: `Test mode (query): rejected connection from...`.

### 17.4 Cleanup
```powershell
docker compose -f docker-compose.integration.yml down -v
```

## 18. The Infinite Reconnect Trap (Internal Error Handling)

**Symptom**: Fallback Dashboard tests fail because the terminal never shows the "Unavailable" state, or the browser enters an infinite reconnection loop despite the PTY server being in `test_mode=fail`.

**Root Cause**: The ODTO Web Terminal (`terminal.js`) implements a robust auto-reconnect strategy (R6) with exponential backoff. In older versions, any WebSocket closure or non-specific error would trigger a reconnect. When `PTY_TEST_MODE=fail` is active, the server sends an `INTERNAL_ERROR` and closes the connection. Without specific handling, the client sees this as a transient failure and immediately tries to reconnect, masking the fallback UI.

**Fix**:
1. **Authoritative Error Handling**: The client MUST identify `INTERNAL_ERROR` (code `error_codes::INTERNAL_ERROR`) as a terminal failure.
2. **Reconnection Suppression**: Upon receiving an internal error, the client MUST set `intentionalClose = true` to disable the `scheduleReconnect()` logic and call `showFallback()` immediately.
3. **Implementation Pattern**:
   ```javascript
   } else if (msg.code === 'INTERNAL_ERROR') {
       // Server rejected connection or fatal error - show fallback
       console.log('Server rejected connection, showing fallback');
       intentionalClose = true; // SUPPRESS AUTO-RECONNECT
       showFallback();
   }
   ```

**Verification**:
- Navigate to `?test_mode=fail`.
- Inspect the **Network** tab: You should see exactly one WebSocket connection attempt that is closed by the server.
- The **Fallback Dashboard** should appear within < 500ms.
- Console should NOT show "Reconnecting in Xms..." logs.

## 19. CI Regression Hazards (The "Everything is Broken" Incident)

**Symptom**: After successfully implementing a tiered test strategy and verifying a 7/7 pass locally, the CI pipeline reports widespread failures in unrelated jobs: `Windows Script Verification`, `Type Checking & Coverage`, `Lint & Format`, and `Canonical Test Suite`.

**Root Cause**: In infrastructure-heavy repositories, "innocent" changes to shared configurations (like `Config` field additions in Rust) or workflow files (`nightly.yml`) can trigger side effects:
1. **Dependency Pinning Divergence**: If a field is added to a struct but not updated in every manual test initializer across the repo, it results in a "Config Initializer Trap" (see Section 16). While `cargo check` might pass for the main target, the full suite includes library tests that may fail.
2. **Lockfile Desync (`--locked`)**: Adding new dependencies or updating workflows can cause `Cargo.lock` or `package-lock.json` desynchronization. CI often runs with `--locked` or `npm ci`, which will fail if the lockfile doesn't exactly match the manifest.
3. **Environment Parity**: Local environments often have pre-cached dependencies or "dirty" state that masks issues (like missing toolchain components) which become obvious in the "Nuclear Option" reset of a fresh GitHub Actions runner.

**Diagnostic Breakthrough**:
During the Phase 31.5 incident, running the **Canonical Test Suite** (`./scripts/run-all-tests.ps1`) locally resulted in a **100% PASS** (103 Gateway tests, 35 Processor tests, Go validator checks, etc.). This confirmed that the code logic was sound, and the failure was strictly environment-specific or related to CI-only constraints (like `--locked` enforcement).

**Fix/Mitigation Strategy**:
1. **Branch Isolation**: Immediately create a dedicated fix branch (e.g., `fix/ci-visual-test-strategy`) to isolate the CI investigation from the main development line.
2. **Canonical Suite Local Run**: Execute the authoritative test script (`./scripts/run-all-tests.ps1`) locally. This script is designed to replicate the CI environment's strictness.
3. **Struct-Level Audit**: Ensure every instance of shared structs (`Config`, `AppState`) is updated in all submodules, even if they aren't directly related to the current feature.
4. **Lockfile Sync**: Run `cargo fetch` or similar commands to ensure lockfiles are reconciled before pushing.

**Verification**: All CI status checks must return green before merging, regardless of local "works on my machine" status.
