# Docker Build Context Parity and Validation (v3.1.10 - v3.1.12)

## 1. The Latent Build Context Hazard

### 1.1 Incident Overview
During a systematic review of project invariants, a critical "latent" bug was discovered in the Docker image build pipeline.

### 1.2 The Conflict
*   **Dockerfile Requirement**: Service Dockerfiles (e.g., Gateway, Processor) were updated to use **repo-relative paths** (e.g., `COPY src/services/gateway/...`) to ensure they could access shared assets like `contracts/` when built from the repo root.
*   **CI Configuration**: The GitHub Actions `build-images` job used **service-local contexts** (e.g., `src/services/gateway/`) to maximize Docker layer cache hits.
*   **The Result**: These configurations were mechanically incompatible. Building from `src/services/gateway/` means the context does not contain `src/services/gateway/...`, causing the build to fail.

### 1.3 Why it remained latent
*   **Cache Persistence**: The job only triggers on pushes to `main` when service directories change. No service changes had been merged after the Dockerfile update.
*   **Environmental Divergence**: Local development (`start-all.ps1`) correctly used repo-root context, concealing the CI-specific failure.

## 2. Hardened Invariant: B1 (Repo Root Context)

To resolve this hazard, the system transitioned to **Mandatory Context Parity**.

### 2.1 Invariant B1 (Refined v3.1.15)
The build context must match the Dockerfile's path assumptions in all environments. This is enforced through two specialized patterns:

- **Invariant B1a (Local Dev)**: Local orchestration (`start-all.ps1`) uses the **Repo-Root context** (`context: .`). This provides the simplest path for developers to access shared assets without pre-sync scripts.
- **Invariant B1b (CI Optimization)**: CI workflows may use a **Service-Local context** for cache efficiency. This is only permitted if the CI job explicitly performs a **pre-sync phase** (e.g., `cp -r contracts src/services/gateway/`) to ensure repo-relative `COPY` paths in the Dockerfile remain valid.

### 2.2 web-pty-server Fidelity (v3.1.11)
The `web-pty-server` represents a critical hazard:
1.  **Embedded Dependency**: It embeds the `odd-dashboard` TUI binary.
2.  **Context Requirement**: The builder stage needs access to `src/interfaces/tui/` to compile the TUI.
3.  **Resolution**: Using `context: .` ensures the TUI can be built and embedded with high fidelity.

## 3. Automated Enforcement: validate-dockerfile-context.py

A specialized validation script `scripts/validate-dockerfile-context.py` acts as a pre-flight CI gate to enforce Invariant B1.

### 3.1 Validation Logic
The script parses `.github/workflows/ci.yml` using regex and checks `context` definitions against service requirements.

| Service | Required Context | Reason |
| :--- | :--- | :--- |
| `gateway` | `.` (Repo Root) | Uses `COPY src/services/gateway/...` and `COPY contracts/` |
| `processor` | `.` (Repo Root) | Uses `COPY src/services/processor/...` and `COPY contracts/` |
| `web-pty-server` | `.` (Repo Root) | Uses `COPY src/services/web-pty-server/...` and `COPY src/interfaces/tui/...` |
| `metrics-engine` | Service-Local | Self-contained Go service |
| `read-model` | Service-Local | Self-contained Go service |
| `web-ui` | Service-Local | Builds within `src/interfaces/web` |

### 3.2 Total Matrix Inclusion (v3.1.11)
To prevent "Validation Bypass via Matrix Omission," every service with a Dockerfile is included in the CI `build-images` matrix. This ensures the validation script checks every deployable image.

### 3.3 Total Trigger Coverage (v3.1.12)
The CI trigger condition was hardened to ensure that changes to any service (including those in `src/interfaces/web`) correctly trigger the image build job, preventing "Stale Registry" hazards.

| Service | Context (Local) | Context (CI) | Invariant | Outcome |
| :--- | :--- | :--- | :--- | :--- |
| `gateway` | `.` | Service-Dir (+ sync) | B1a / B1b | ✅ Validated |
| `processor` | `.` | Service-Dir (+ sync) | B1a / B1b | ✅ Validated |
| `web-pty-server` | `.` | `.` | B1 | ✅ Validated |
| `metrics-engine` | Service-Dir | Service-Dir | B2 | ✅ Validated |
| `read-model` | Service-Dir | Service-Dir | B2 | ✅ Validated |
| `web-ui` | Service-Dir | Service-Dir | B2 | ✅ Validated |
