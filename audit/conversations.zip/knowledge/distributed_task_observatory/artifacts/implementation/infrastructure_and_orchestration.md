# Infrastructure & Orchestration

The Distributed Task Observatory (ODTO) uses a "Self-Launching" pattern to automate the deployment and management of its polyglot microservice environment on a local Kubernetes cluster.

## 1. Foundation Infrastructure

The system runs on a local `kind` (Kubernetes in Docker) cluster. Core platform services include:

- **Cluster Management**: `kind` cluster named `task-observatory`.
- **Event Spine**: **RabbitMQ 3.11** with management UI (port 15672).
- **Relational Authority**: **Postgres 15** for stable job state (pgAdmin on port 5050).
- **Fast Metrics**: **Redis 7** for real-time aggregation (RedisInsight v2 on port 5540 internally, 8001 externally).
- **Document Store**: **MongoDB 6** for raw event audit trails (Mongo Express on port 8082).

## 2. Self-Launching Application Pattern

The "Self-Launching" pattern integrates infrastructure orchestration directly into the application interfaces (TUI/Web Mirror). This ensures a "Zero-Touch" onboarding experience for developers.

### 2.1 Orchestration Logic
- **Discovery**: The TUI detects if the cluster or application pods are missing.
- **Initialization**: Automatically triggers `start-all.ps1` to build images, initialize kind, and deploy manifests.
- **Streaming Progress**: Progress logs are streamed from the orchestration script to the UI using a structured JSON protocol.
- **Readiness Probing**: The system gates on full Pod `Ready` conditions and establishes background port-forwards only when services are accessible.

### 2.2 Actionable Error Remediation
When prerequisites (Docker, kubectl, kind, pwsh) are missing or configuration errors occur (e.g., port conflicts), the system provides cross-platform remediation steps:
- **Windows**: `winget install ...`
- **macOS**: `brew install ...`
- **Linux**: Platform-specific `apt`/`dnf` commands.

## 3. High-Resilience Deployments
- **Image Loading**: Images are built locally and loaded directly into the kind node to avoid external registry dependencies.

## 4. Hardened Distribution Model

The ODTO platform has transitioned from a source-only developer tool to a production-ready binary distribution (`odd-dashboard`).

### 4.1 Verifiable Build Pipeline
- **Binary Renaming**: The Rust TUI is standardized as `odd-dashboard`.
- **Metadata Injection**: `build.rs` injects Git SHA, build timestamp, and compiler version into the binary for complete bit-for-bit traceability before signing.
- **Safety Invariants**: The distribution enforces a "No-Side-Effect-Entry" model where platform checks and CLI dispatch occur before any filesystem or network initialization.
- **Support Matrix Enforcement**: Automated verification of POSIX/Windows compatibility via exact `std::env::consts` matching.

### 4.2 Multi-Channel Distribution
- **Package Managers**: Support for Homebrew (macOS/Linux), Winget/Scoop (Windows), and npm (cross-platform shim).
- **Integrity**: Every release includes GPG-signed `SHA256SUMS` and platform-specific code signing (Authenticode/Notarization).
## 5. Infrastructure Evolution & Contract Stability

As the ODTO platform matures, internal infrastructure components are upgraded (e.g., RedisInsight v1 to v2). The project adheres to a **Stability-First** policy where internal image drift must not break the public system contract.

### 5.1 Decoupled Service Mapping (v1.1.1 Case Study)
When RedisInsight was upgraded to v2, it moved its internal container port from 8001 to 5540.
- **Problem**: Changing the port to 5540 in the `ui-registry.json` contract would break current user expectations and existing launcher configurations.
- **Solution**: The internal K8s manifest was updated to use `targetPort: 5540`, while the public `Service` port and the `ui-registry.json` entry were kept at **8001**.
- **Result**: Drastic internal technology evolution was achieved with zero breakage of the outward-facing developer interface, ensuring high-integrity integration remains the ODTO standard.
### 5.2 Internalized Build Performance Breaches
In Phase 18, it was identified that source-based builds (performing `npm install`, `tsc`, and `go run` within the container) in CI were breaching **Invariant I4** (Runtime < 90s), frequently taking 60-90s just for startup. This led to the adoption of the **Docker Hub Pre-built Images** distribution model for integration testing.

## 6. Docker Hub Migration & Containerization Patterns

To restore CI enforcement of integration invariants (I3-I5), the repository transitioned from source-based `docker-compose` builds to pre-built, high-integrity images hosted on Docker Hub.

### 6.1 Multi-Stage Dockerization Patterns
Service Dockerfiles were standardized on a multi-stage build pattern to ensure minimal runtime footprints and maximize security:

| Service | Language | Build Stage | Runtime Stage | Hardening Pattern |
| :--- | :--- | :--- | :--- | :--- |
| **Gateway** | Node.js | `node:20-slim` (Build) | `node:20-slim` (Run) | `npm ci --omit=dev`, baked-in contracts |
| **Processor** | Python | — | `python:3.11-slim` | `pip install --no-cache-dir`, baked-in contracts |
| **Metrics Engine** | Go | `golang:1.21-alpine` | `distroless/static` | Static binary, ldflags (`-s -w`) optimization |
| **Read Model** | Go | `golang:1.21-alpine` | `distroless/static` | Static binary, ldflags (`-s -w`) optimization |

### 6.2 Baked-in Contract Governance (Invariant I3)
To satisfy **Invariant I3** (Self-contained harness), the **Gateway** and **Processor** services include a `COPY contracts ./contracts` step in their Dockerfiles. This ensures that AJV schema validation remains authoritative without depending on external volume mounts or network fetches during integration testing.

### 6.3 Integration Harness Optimization (Invariant I4)
By using pre-built images, the `integration-harness.ps1` startup period was reduced from **30s** to **10s**, successfully bringing the total wall-clock runtime of the integration phase well below the **90s** threshold.

### 6.4 Tagging for Traceability
Every push to `main` triggers a matrix build job in CI that generates dual tags for each service image:
- `:latest`: The current head of `main`, used for standard integration tests.
- `:sha-<commit>`: A fixed reference for historical traceability and failure analysis.

### 6.5 Mandatory Build Context Parity (v3.1.10)

Following the identification of the **Latent Build Context Hazard**, ODTO has standardized on absolute parity between local, CI, and integration environments.

- **The Standard**: For services consuming shared monorepo assets (e.g., `contracts/`), the build context MUST be the repository root (`.`).
- **Dockerfile Convention**: All `COPY` instructions for these services use repo-relative paths (e.g., `COPY src/services/gateway/package.json ./`).
- **Enforcement**: This is mechanically enforced for CI by `scripts/validate-dockerfile-context.py`.
- **Elimination of Side-Effects**: This pattern replaces the obsolete "Context Preparation" pattern (Pattern 2) where CI and developers had to manually copy files into service directories before building, which created "Ghost File" drift.

#### 6.5.1 Automated Validation Logic
The `scripts/validate-dockerfile-context.py` script ensures that CI workflow definitions match Dockerfile path assumptions using a three-way check:
1. **Parse CI**: Extracts `context` from the `build-images` job matrix in `.github/workflows/ci.yml` using regex (avoiding YAML dependencies on the runner).
2. **Handle Windows Diversity**: Explicitly uses `encoding="utf-8"` to prevent `UnicodeDecodeError` when executed on Windows agents.
3. **Verified Classification**: Compares service contexts against explicit classifications (`REPO_ROOT_REQUIRED` vs `SERVICE_LOCAL_OK`).
4. **Conservatism**: Definite mismatches produce hard failures (exit 1), while unknown services produce warnings to allow for rapid bootstrapping.

| Component | Build Context | enforcement |
| :--- | :--- | :--- |
| **Local Startup** (`start-all.ps1`) | `.` (Repo Root) | ✅ Hardcoded in `$images` |
| **CI Pipeline** (`ci.yml`) | `.` (Repo Root) | ✅ `validate-dockerfile-context.py` |
| **Integration Mirror** (`docker-compose.integration.yml`) | Mixed | ✅ Verified Phase 34.1 |

### 6.6 Total Matrix Inclusion (v3.1.11)
To eliminate the **Governance Gap** where services built locally bypassed CI context validation, ODTO enforces **Total Matrix Inclusion**:
- **Rule**: Every service with a Dockerfile intended for cluster deployment MUST be in the CI `build-images` job matrix.
- **Purpose**: This ensures that even if an image is not yet used by production manifests, its path assumptions are continuously verified by `validate-dockerfile-context.py`.

### 6.6 Self-Contained Service Exception (Service-Local)
Services that are strictly self-contained (e.g., Go services without monorepo dependencies) are permitted to use **Service-Local** contexts (`src/services/metrics-engine`) for faster build isolation.

### 6.7 Internalized Health Probe Pattern
To ensure container availability within the integration harness without introducing external network dependencies (like `curl` or `wget`), the system uses internalized health probes in its **base images**:
- **Node.js (Gateway)**: `node -e \"require('http').get(...)\"` (Used for orchestrator health checks in non-distroless environments).
- **Python (Processor)**: `python -c 'import socket; ...'` (Used for connection validation).
- **Go (Read Model)**: `wget -q --spider ...` (Only compatible with alpine/standard bases; deprecated for distroless app services).

> **Note**: As of Phase 19, primary application readiness has migrated to the **Externalized Harness Pattern** (Section 6.12).

### 6.8 Matrix Build Pattern for Multi-Stack Logic
The repository uses a single GitHub Actions matrix job to manage builds across diverse tech stacks (Node, Python, Go), ensuring that all service images are built and tagged using the same governance rules:
- **Strategy**: `fail-fast: false` ensures one service's build failure doesn't block the artifact capture of others.
- **Context Flexibility**: The matrix maps each service to its specific directory (`src/services/gateway`) and image name, allowing for a unified `docker/build-push-action` configuration.
- **Tagging Invariant**: Every build generates both `:latest` and `:sha-<commit>` tags for consistent traceability across the environment.

### 6.9 Runtime Path Sensitivity (Gateway Case Study)
Dockerization often shifts the execution environment from repo-relative to container-relative paths, which can break services that depend on `__dirname` or relative lookups for metadata (e.g., `VERSION` files).
- **The Failure**: In ODTO v1.2.2, the Gateway service failed to start because it looked for `VERSION` in `dist/VERSION` (relative to the entry point), but the Dockerfile only placed it at `/app/VERSION`.
- **The Fix**: Standardized the Dockerfile to copy required metadata into the specific subdirectory where the runtime executes (e.g., `COPY VERSION ./dist/VERSION`).

### 6.10 Build Context Matrix
The ODTO platform supports a dual-context model to balance flexibility with monorepo integrity:

| Service | Category | Build Context | Reason |
| :--- | :--- | :--- | :--- |
| **Gateway** | Repo-Root | `.` | Uses `COPY contracts/` |
| **Processor** | Repo-Root | `.` | Uses `COPY contracts/` |
| **Web PTY Server** | Repo-Root | `.` | Embeds TUI from `src/interfaces/tui` |
| **Metrics Engine** | Service-Local | `src/services/metrics-engine` | Self-contained Go binary |
| **Read Model** | Service-Local | `src/services/read-model` | Self-contained Go binary |
| **Web UI** | Service-Local | `src/interfaces/web` | Isolated JS build |

### 6.11 The Distroless Health Check Dilemma
Distroless images (like `gcr.io/distroless/static`) prioritize security and size by removing all shells and utilities, including `wget` and `curl`.
- **The Conflict**: Using `CMD-SHELL` or `wget` in a Docker Compose health check will result in a fatal error (exit code 1) because the executable is not found.
- **The Discovery**: Verification of Phase 19 images confirmed that standard compose health checks are incompatible with ODTO's high-integrity distroless targets.

### 6.12 Externalized Health Check Governance (Option 4)
To resolve the distroless conflict while maintaining deterministic gating, ODTO employs a "Harness-Owned Readiness" strategy:
- **Rule**: Docker Compose only manage infrastructure health (Postgres, RabbitMQ, etc.) to enable `depends_on` sequencing.
- **Governance**: All application services (Gateway, Read Model, etc.) have their `healthcheck` removed or set to `test: ["NONE"]` in `docker-compose.integration.yml`.
- **Enforcement**: The `integration-harness.ps1` (or equivalent CI runner) performs authoritative health probes via external HTTP requests (`Invoke-RestMethod`) to exposed ports. 
- **Benefit**: This pattern ensures that "health" proves the service is actually usable from the outside, eliminates minimal-image utility bloat, and prevents "health check drift" between compose logic and harness logic.

### 6.13 Postgres SSL Mode Governance
Standard PostgreSQL client libraries (particularly Go's `lib/pq`) often default to requiring SSL for connections. 
- **The Friction**: In the ODTO integration harness, the PostgreSQL container (`postgres:15-alpine`) does not have SSL enabled by default. This causes services to hang or crash with `pq: SSL is not enabled on the server`.
- **The Standard**: To ensure deterministic container startup across all services (Node, Go, Python), all connection strings in `docker-compose.integration.yml` must explicitly append `?sslmode=disable` (or the environment equivalent) to the `POSTGRES_URL`.

### 6.14 Dependency-Aware Health Probe Governance
In polyglot environments, a service binary may report "Healthy" (e.g., via a simple HTTP 200) before its internal background async dependencies (RabbitMQ channels, database pools, circuit breakers) are fully wire-ready.
- **The Optimistic Health Check**: If a health endpoint returns OK based only on port availability, the integration harness may encounter transient 500 errors (Internal Server Error) during the first proof path probes.
- **The Anti-Pattern**: Implementing "Startup Grace Periods" (hardcoded delays) in the harness is a shortcut that masks underlying readiness issues.
- **The Standard**: Application health endpoints (`/healthz` or equivalent) MUST be dependency-aware. They must perform a lightweight check of critical async dependencies (e.g., verifying a RabbitMQ channel exists) and return a non-ready status (e.g., 503 Service Unavailable) until the service is actually capable of processing requests.
### 6.15 Response vs. Domain Schema Governance
To prevent false-negative verification failures in the integration harness, a clear distinction must be maintained between domain schemas and API response schemas.
- **The Confusion**: Validating a lightweight "Accepted" or "No Content" response against a heavy domain schema (e.g. `job.json`) will cause a validation failure due to missing core fields.
- **The Standard**: Integration harnesses MUST target the appropriate schema for the specific HTTP verb and status code. Domain schemas should only be used to validate the state of the database (e.g. via Read Model query) after the event loop has processed the request. Lightweight transport contracts (e.g., `job-accepted.json`) should be created for acknowledgements to maintain contract-first integrity without overloading domain models.

### 6.16 Integration Schema Initialization Governance
In distributed systems using CQRS (like ODTO), the Read Model (Query side) and Processor (Write side) may share a database but have different startup lifecycles.
- **The Friction**: If the Read Model starts and receives a query before the Processor (or a migration job) has created the necessary tables, it will fail with `pq: relation "..." does not exist`.
- **The Standard**: Integration environments MUST ensure that schema initialization is a blocking prerequisite for service readiness. This can be achieved via:
    1. **Migration Sidecars**: A dedicated job that runs migrations and exits before app services start.
    2. **Lazy Initialization**: Services handling "missing table" errors gracefully and retrying.
    3. **Harness Gating**: The integration harness verifying table existence (e.g., via a dummy insert or schema query) before starting proof paths.
    4. **Bounded State Polling**: The preferred pattern for async systems. The harness should poll the Read Model for a terminal state (e.g., `COMPLETED`) with bounded retries and loud logging.

### Pattern: Bounded State Polling (Preferred)

Rather than forcing DDL logic into services that perform queries (which creates ambiguous ownership and hidden coupling), use deterministic polling in the harness:
- **Monotonic Counters**: Track attempts explicitly (`$attempt++ / $maxAttempts`).
- **Intervals**: Fixed sleep periods (e.g., 2s) between probes.
- **Fail-Fast**: Hard fail if the state is not reached within the wall-clock budget.

### Pattern: Single DDL Owner (Anti-Pattern: In-App Table Creation)

Avoid and "everyone does CREATE IF NOT EXISTS" pattern in polyglot systems. 
- **Ownership**: Establish a single service (or a dedicated migration job) as the authoritative owner of the database schema.
- **Dependency**: If the Read Model depends on tables created by the Processor, use the **Harness Gating** or **Bounded State Polling** pattern to manage the startup race rather than duplicating DDL in the Read Model.

## 7. Tiered Image Sourcing (Hybrid Fidelity Strategy)

ODTO employs a tiered approach to image sourcing to balance developer agility with CI performance and visual test fidelity.

### 7.1 Local Source-Based Builds (Developer Mode)
When running the cluster via the TUI or `start-all.ps1` locally, the system defaults to **building images from local source code**.
- **Reason**: Ensures that any modifications made by the developer (e.g., Go/Python/Rust code changes) are immediately reflected in the local Kind cluster.
- **Mechanism**: The PowerShell orchestrator executes `docker build` using the repo root context as required.

### 7.2 Deterministic Pre-built Images (CI/Main Mode)
In CI and standard integration tests, ODTO transitions to using **pre-built images from Docker Hub**.
- **Reason**: Reduces integration job runtime (e.g., from 15+ minutes to < 90s) by eliminating redundant compilation.
- **Constraint**: This requires the **Shortcut Elimination Policy**; CI images must exactly match the versioned tags in the manifests.

### 7.3 The Hybrid Visual Fidelity Exception (v3.1.11)
A specialized hybrid model is used for the **Visual Regression Suite** (`docker-compose.integration.yml`):
- **Core services** (Gateway, Processor, etc.) use pre-built images for speed.
- **Edge services** (`web-pty-server`, `web-ui`) are **built locally**.
- **The Rationale**: Since visual tests verify the TUI (embedded in the PTY server), using pre-built images would mean PRs fail to test current TUI changes. Building locally ensures that the TUI binary in the test container matches the PR's source code, maintaining 100% fidelity.

### 7.4 RabbitMQ Erlang Lock Remediation
If a core infrastructure dependency (e.g., RabbitMQ) fails with an Erlang-specific startup error (Transient Error 14.6), the system adheres to the **Idempotent Infrastructure Reset** pattern (Standards Pattern 46): a forceful cleanup (`docker compose down -v`) followed by a fresh start.

## 8. Integration Fidelity Audit (Mirror vs. K8s)

### 8.1 Gap Analysis (v3.0.1)
An audit conducted in Phase 31 compared the 14 standard Kubernetes deployments against the integration compose environment to ensure high-fidelity mirroring.

| Status | Component | Purpose | Context |
| :--- | :--- | :--- | :--- |
| ✅ | **Gateway** | API Aggregator | Both |
| ✅ | **Read Model** | Query Side | Both |
| ✅ | **Processor** | Write Side | Both |
| ✅ | **Metrics Engine** | Logic Layer | Both |
| ✅ | **Prometheus** | Observability | Both (Added Phase 31) |
| ✅ | **RabbitMQ** | Message Broker | Both |
| ✅ | **Postgres** | SQL Store | Both |
| ✅ | **MongoDB** | NoSQL Audit | Both |
| ✅ | **Redis** | Speed Layer | Both |
| ✅ | **Web PTY / UI** | Mirror Interface | Both (**Hybrid Build**) |
| ✅ | **Grafana** | Dashboards | **Mandatory** (Added Phase 31) |
| ❌ | **Alertmanager** | Alert Routing | K8s Only (Deferred) |
| ❌ | **Admin UIs** | pgAdmin, RedisInsight | K8s Only (Optional) |

### 8.2 Prometheus Integration
In Phase 31, the `prometheus` service was added to `docker-compose.integration.yml`. 
- **Reasoning**: The TUI Dashboard displayed a persistent `⚠ Prometheus unavailable` warning. While the system is "Diagnostic-Hardened" and falls back to Read Model API polling, incorporating Prometheus into the integration environment ensures that visual regression tests capture the "Golden Path" dashboard state without warning banners.
- **Contract**: The Integration Prometheus uses a shared configuration (`infra/prometheus/prometheus.yml`) shared with the K8s manifests, maintaining the **Authoritative Configuration Pattern**.

### 8.3 "No Shortcuts" Mandate (Pattern 48.4)
While "Server Mode" (Skip Probing) is a necessary shortcut for containerized mirrors, the **Authoritative Cluster Path** (using `kubectl` and host tools) remains the primary delivery vehicle.
- **Governance**: Every infrastructure change for the mirror must be verified against the native cluster flow to ensure zero regression for the local developer experience on Windows/macOS/Linux.
- **Verification**: Symmetric unit tests (e.g., `test_normal_mode_uses_kubectl`) are required for all platform detection logic.

### 8.4 Service Recovery & Drift Correction (Zero-Gap Mandate)
To maintain high-fidelity visual snapshots, any service found missing from the integration mirror that generates a non-standard TUI state (like `⚠ Prometheus unavailable`) is treated as a **Production Blocker**. 
- **Urgency**: Missing core observability (Prometheus, Grafana) is a P1 drift risk as it invalidates visual regression baselines.
- **Resolution**: Phase 31 Formalized the mandatory inclusion of Prometheus and Grafana, completing the observability parity loop. This is now enforced by **Invariant I7**.

### 8.5 Pattern: Automated Parity Validation (v3.0.1)
To prevent future architectural drift between Kubernetes manifests and the Docker Compose integration mirror, ODTO employs an automated validation script: `validate-compose-k8s-parity.ps1`.

**Validation Strategy**:
1. **Manifest Parsing**: The script scans `infra/k8s/*.yaml` for deployment definitions, extracting the service identities.
2. **Key Correspondence**: It parses `docker-compose.integration.yml` to verify that every critical k8s service has a corresponding service key in the compose file.
3. **Zero-Gap Enforcement**: The script enforces the **Zero-Gap Mandate** (Invariant I7). It categorizes gaps as **FAIL** for any missing critical or observability services.
4. **CI Enforcement**: This script is integrated into the pre-commit and CI loops, ensuring that any developer adding a new service to the cluster is forced to symmetrically update the integration mirror.

## 9. Nightly Visual Testing Infrastructure

To resolve the environmental jitter and session exhaustion hazards during high-fidelity testing, the visual suite is split across CI and Nightly stages.

### 9.1 Stage Separation (Tiered Strategy)
- **CI Stage (Tier 1)**: Executes "Bundle Smoke Tests" to verify asset delivery without live WebSocket dependencies. Uses high parallelism with `PTY_PER_IP_CAP=30`.
- **Nightly Stage (Tier 2/3)**: Executes screenshot-heavy visual regressions in an isolated, serialized environment.
    - **Serialization**: Enforces `--workers=1` to prevent rendering races and session-limit overlaps.
    - **Stability Gating**: Implements extended readiness probes (60s+ for Web UI, PTY Metrics check) to ensure full environment convergence before capture.
    - **Failure Injection**: Support for `PTY_TEST_MODE=fail` (Tier 3) to exercise fallback UI paths deterministically.

### 9.2 Authoritative Snapshot Maintenance
The nightly workflow provides a manual trigger with an `update_snapshots: true` input, allowing maintainers to safely regenerate golden baselines within the authoritative Ubuntu runner environment, ensuring 100% parity for subsequent nightly runs.

## 10. Port Mapping Standards (Dual-Mode Isolation)

To prevent conflicts with existing developer environments and ensure deterministic verification, ODTO employs a **Dual-Mode Isolation** port strategy.

### 10.1 Demo Mode (13000+ Range)
When running via `docker-compose.demo.yml`, the system uses an isolated host port range. This avoids common collisions with services like Node.js (3000) or MongoDB (27017).
- **Gateway**: 13000
- **Read Model**: 18080
- **Web UI**: 18081
- **RabbitMQ Management**: 25672

### 10.2 Developer/K8s Mode (Standard Range)
When running the full cluster (via `start-all.ps1` and `kind`), the system uses the standard service ports via `kubectl port-forward`. This matches the TUI's internal lookup logic and standard developer expectations.
- **Gateway**: 3000
- **Read Model**: 8080
- **Web UI**: 8081
- **RabbitMQ**: 15672

### 10.3 Port Conflict Remediation
The `start-all.ps1` script and the TUI launcher include a **Port Availability Guard**. Before initiating port-forwards, the system checks if the local port is occupied and provides the specific PID and instruction (`Stop-Job` or `pkill`) to clear the conflict.
### 6.22 The 8-Step Cluster Bootstrap Sequence

The `start-all.ps1` script implements a deterministic 8-step lifecycle:
1. **Prerequisites**: Verifies `docker`, `kind`, `kubectl`, and `pwsh`.
2. **Cluster Init**: Idempotent creation of the `task-observatory` Kind cluster.
3. **Incremental Building**: Sequential Docker builds with per-service context routing.
4. **Kind Loading**: Transfer of images from Docker host to Kind node cache.
5. **K8s Deployment**: Application of manifests (infra/k8s/).
6. **Readiness Polling**: Sequential wait for Pod availability.
7. **Background Port-Forwards**: Persistent forwarding for API access.
8. **Connectivity Probe**: Final HTTP health check verification.

### 11.2 Post-Fix Invariant Verification

When remediation is applied to the orchestration layer (e.g., v3.0.2 context fix), the change must be gated against the **Invariant Map** (`docs/INVARIANTS.md`):

1. **Self-Containment (I3)**: Verify that changing build contexts doesn't break the service's ability to bake in contracts. The 3.0.2 audit confirmed that `gateway` and `processor` maintain local `contracts/` copies, allowing service-dir context to satisfy I3.
2. **Cross-Platform Parity (X1)**: Any change to `start-all.ps1` must be verified in a `pwsh` environment to ensure no shell-specific regressions.
3. **Orchestration Determinism (A2)**: Ensure the fix remains "zero-touch." The v3.0.2 fix restored the "One-Click" guarantee which had been degraded by build failures.

### 11.3 Pattern: Authoritative Subprocess Identity (Diagnostic Proofing)

In "Self-Launching" applications where errors are swallowed or summarized by a UI (like the TUI's Cluster Setup screen), developers often encounter "Ghost Failures"—cases where the fix is applied but the UI continues to report failure due to residual artifacts, terminal lag, or incorrect binary execution paths.

- **The Strategy**: Perform an **Authoritative Subprocess Identity** check. Run the failing command (e.g., the specific `docker build` command) in isolation, using the IDENTICAL context and flags as the orchestration script.
- **The Case Study (v3.0.2)**: After applying the context fix, the TUI still reported a failed cluster launch. The maintainer ran `docker build -t ... -f ... .` (repo root context) manually.
- **Conclusion**: If the isolated command succeeds but the UI fails, the root cause shifted from "Code Error" to "Environmental Artifacts" (e.g., the TUI running a cached stale script or Docker daemon lag). This proof is mandatory before escalating a persisting bug to a secondary remediation phase.

### 11.4 The Image Tag Drift Hazard (Manifest Parity)

**The Failure Mode**: Cluster setup scripts build images with one tag (e.g., `:0.1.0` based on a `VERSION` file) while Kubernetes manifests or Docker Compose files expect another (e.g., `:latest`). This results in `ErrImagePull` or, more dangerously, the cluster running stale code from a previously pulled `:latest` image.

**The Case Study (v3.0.2 Audit)**:
- **Discovery**: After fixing build contexts, the TUI launch still reported failure. **Authoritative Subprocess Identity** checks proved the image built successfully, but `kubectl describe pod` revealed the cluster was still trying to pull `:latest`.
- **Root Cause**: `start-all.ps1` built `web-pty-server:0.1.0` (reading its version file), but `infra/k8s/web-pty-ws.yaml` specified `image: web-pty-server:latest`.
- **Secondary Hazard**: `web-ui` lacked a `VERSION` file entirely, reverting to `:latest` by default, creating an inconsistent tagging protocol across the monorepo.

**The Shortcut Elimination Policy (Implemented v3.0.2)**:

1.  **Universal Versioning**: Every core service now has an authoritative `VERSION` file (including `web-ui` and `web-pty-server`). Hardcoded `:latest` tags in `infra/k8s/` and `docker-compose.demo.yml` have been eliminated in favor of versioned tags (e.g., `:0.1.0`).
2.  **Extended CI Verification**: The `scripts/check-service-versions.py` tool has been expanded to cover ALL application services, including the `web-pty-server` and `web-ui`. This creates a hard failure in CI if manifest tags drift from their corresponding `VERSION` files.
3.  **Manifest & Label Parity**: Manifests (e.g., `web-pty-ws.yaml`, `web-ui-http.yaml`) now explicitly include `app.kubernetes.io/version` labels matching the image tags, improving observability and rollback tracing.
4.  **Orchestrator Enforcement**: `start-all.ps1` now uses the resolved versions for both the `docker build` and the `kind load` steps, ensuring that the image built is identical to the image loaded into the cluster nodes.

### 11.5 The Execution Environment Drift (Final Diagnostic)

**The Phenomenon**: In the final stage of the v3.0.2 fix, even after the `start-all.ps1` script and Kubernetes manifests were perfectly aligned and verified by the `check-service-versions.py` tool, the TUI continued to report build failures for `:latest` tags.

- **Root Cause**: The TUI was executing a version of the setup script that did not reflect the latest changes on disk, or was operating within a shell session where script definitions were cached.
- **Remediation**: 
    1. **Authoritative Subprocess Identity**: (Ref Section 11.3) Manual execution of the script with `-OutputJson` in a clean `pwsh -NoProfile` session proved the script was correct.
    2. **Fresh Environment**: Users should restart the TUI or clear shell caches to ensure the orchestration layer picks up the corrected script definition.
    3. **Pre-Flight Invariant**: The inclusion of `scripts/check-service-versions.py` in the pre-commit and CI workflows serves as the final guard—if this script passes on the developer's machine, any persisting UI failure is an environmental artifact, not a systemic bug.

### 11.6 The Stale Image Cache Hazard (Multi-Tag Ambiguity)

**The Failure Mode**: Even after aligning manifests and scripts to a versioned tag (e.g., `:0.1.0`), the system may still pull or report old code if a `:latest` tag exists in the local Docker daemon for the same image name. The TUI or Kind may prioritize a stale `:latest` if the build-context or pull policies are ambiguous.

**The Diagnostic Proof (v3.0.3 Audit)**:
- **Discovery**: `docker images` revealed multiple tags for `web-pty-server` (`:0.1.0` and `:latest`) on the same host disk. 
- **The Risk**: Ambiguous tag presence leads to "Successful builds" that result in "Stale cluster state" because the wrong artifact was loaded into the Kind nodes or pulled from a local cache.
- **Remediation**:
    1. **Authoritative Local Audit**: Use `docker images --format "table {{.Repository}}:{{.Tag}}" | Select-String <service>` to confirm exactly which tags exist.
    2. **Cleanup**: Explicitly remove `:latest` variants (`docker image rm <name>:latest`) for services that have transitioned to the **Shortcut Elimination Policy**.
    3. **Canonical Suite Verification**: Before manual testing, developers MUST run the **Canonical Test Suite** (`scripts/run-all-tests.ps1`). It includes the `check-service-versions.py` gate which validates 100% manifest parity for all 6 application services.

### 11.7 The PSScriptRoot Invocation Hazard (Foreign Shell context)

**The Failure Mode**: PowerShell scripts that rely on `$PSScriptRoot` to resolve the **ProjectRoot** (e.g., `$ProjectRoot = Split-Path -Parent $PSScriptRoot`) will fail when invoked by an external process (e.g., a Rust `std::process::Command`) using the `-Command` flag with the `&` operator (e.g., `pwsh -Command "& 'path/to/script.ps1'"`). In this context, `$PSScriptRoot` is **empty** because the script is not being executed as a discrete file by the shell, but as a string command.

**The Diagnostic Proof (v3.1.6 Fix)**:
- **Discovery**: While the **Canonical Test Suite** passed in a direct shell, the TUI launch continued to report build failures or "stale" behavior (reverting to `:latest`).
- **Deep Trace**: `Write-Host "PSScriptRoot: $PSScriptRoot"` inside the script during a TUI launch revealed an empty string. The script was falling back to an incorrect default or failing to find `VERSION` files, breaking the **Mixed-Context Build Lifecycle**.
- **Symptom**: The TUI would report "Failed to build: <service>:latest" even when the `VERSION` file specified `0.1.0`. This is a signature of root-resolution failure.

### 11.8 The Hardened Root Resolution Pattern (v3.1.8 Fix)

**The Failure Mode**: Even after documenting the `$PSScriptRoot` hazard, scripts may still fail if the fallback logic is not robust against multiple "Parent" levels. If `Split-Path -Parent $PSScriptRoot` returns `\` (drive root), the script attempts to find VERSION files in non-existent system directories (e.g., `E:\src\...`), defaulting to `:latest` and causing silent build failures.

- **Remediation**: The project has adopted the **Hardened Root Resolution Pattern** (refer to `Repository Standards & Release Governance: Cross-Platform Orchestration Hardening`). 
- **Implementation (start-all.ps1)**: The script now uses a multi-tiered resolution:
    1. Resolve from `$MyInvocation.MyCommand.Path` (script location).
    2. Fallback to `$PSScriptRoot` (shell context).
    3. Fallback to `Get-Location` (process CWD) with a marker-based walk upward to find the `infra/` directory.
- **Fail-Fast Policy**: In compliance with the ODTO Hard Failure Policy, the script terminates immediately with a fatal error if the project root cannot be resolved or if the required repository markers are missing.
- **Diagnostic Proof (v3.1.8 Audit)**: Simulation via `pwsh -Command` and TUI-spawned verification confirmed that the marker-based loop correctly identifies the root, enabling the Docker build to find versioned tags instead of defaulting to `:latest`.

### 11.9 The Orchestrator Staleness Hazard (Binary/Script Desync)

**The Failure Mode**: In a "Self-Launching Application" architecture where a compiled binary (Rust TUI) spawns a script (`start-all.ps1`), a developer may apply a fix to the script and verify it in a standalone shell, yet still see failing behavior in the TUI. This occurs if the developer is running a **stale TUI binary** built before the orchestration logic or environment invariants (like `VERSION` files) were stabilized, leading to a "ghost regression" where the script on disk is correct but the application's runtime context is polluted.

**The Diagnostic Proof (v3.1.6 Fix)**:
- **Discovery**: After hardening `$PSScriptRoot`, the TUI still reported building `:latest` tags in the user's environment.
- **Deep Trace**: `Get-Item` on the TUI binary revealed a `LastWriteTime` (3:21 PM) that preceded the final stabilization of the `check-service-versions.py` and `VERSION` file manifests.
- **Remediation**:
    1. **Authoritative Rebuild**: When modifying orchestration logic or script-facing metadata, developers MUST perform a clean rebuild of the parent application (`cargo build --release`) to ensure the entire execution chain is synchronized.
    2. **Binary Timestamp Audit**: Use `Get-Item <binary> | Select-Object LastWriteTime` to verify that the running orchestrator post-dates the latest infrastructure changes.
    3. **Context Refresh**: Ensure that any local environment variables (which might be cached by a long-running TUI) are refreshed.
    4. **Path Sanitization**: The v3.1.8 stabilization revealed that even with a fresh binary, `Get-Location` returning a `PathInfo` object (instead of a string) could cause `Split-Path` to fail silently when resolving the project root during a TUI spawn.
    5. **Ghost Failure Verification**: If a developer relies on local builds but has a stale image in their terminal cache, the TUI might report "Building..." but the cluster might pull the old image if tag synchronization is lost. Always perform an authoritative rebuild or refresh the environment state.

### 11.10 PathInfo Resolution Hazard (v3.1.8 Fix)

**The Failure Mode**: When a PowerShell script is spawned via a TUI with an empty `$PSScriptRoot`, the fallback logic relies on `Get-Location`. In PowerShell, `Get-Location` returns a `System.Management.Automation.PathInfo` object. While most cmdlets handle this gracefully via string conversion, arithmetic on the path (like traversing multiple parents) or passing it to specific string-expecting logic can create brittle resolution.

**The Diagnostic Proof (v3.1.8 Audit)**:
- **Incident**: After implementing the Hardened Root Resolution Pattern, the TUI still intermittently failed to resolve the project root on Windows.
- **Discovery**: Explicitly calling `Split-Path -Parent $curr` where `$curr` was a `PathInfo` object from a drive root or deep subdirectory was producing inconsistent results depending on whether the shell was `pwsh` or `powershell.exe`.
- **Remediation**: Hardened the resolution to always cast to string using the `.Path` property: `$script:ProjectRoot = (Get-Location).Path`.

### 11.11 Pre-flight Diagnostic Hardening (v3.1.8 Fix)

**The Failure Mode**: If an orchestration script fails *before* it begins its main JSON-emitting loop (e.g., during project root resolution), it traditionally outputs to `stderr` or uses `Write-Host`. A TUI capturing JSON from `stdout` will see an empty stream or a "Failed to parse JSON" error, masking the root cause (e.g., "marker 'infra/' not found").

**The Diagnostic Proof (v3.1.8 Audit)**:
- **Incident**: TUI users reported "Failed to parse JSON" with no hint that the script couldn't find the repository markers.
- **Remediation**: Added a pre-flight diagnostic hook that detects if `-OutputJson` is enabled. Fatal errors now emit a single-line JSON blob containing `PSScriptRoot` and `CWD` before exiting.
- **Result**: TUIs can now display the exact path variables being used for resolution, dramatically reducing the "Diagnostic Capitulation" time.

### 11.12 The SkipBuild Tag Consistency Hazard (v3.1.8)

**The Failure Mode**: When running `start-all.ps1` with the `-SkipBuild` flag, the `Build-DockerImages` step (which typically resolves and caches image versions) is bypassed. If the orchestration script relies on a shared state (e.g., `$script:ImageVersions`) to communicate versioning to subsequent steps like `Import-ImagesToKind` or `Apply-K8sManifests`, that state remains unpopulated. This results in the system defaulting to `:latest` tags during image loading or pod deployment, creating a fatal mismatch with versioned Kubernetes manifests.

**The Diagnostic Proof (v3.1.8 Audit)**:
- **Discovery**: Verification of the `$PSScriptRoot` fix using `-SkipBuild` revealed that while the project root resolved correctly, the script still attempted to load `service:latest`.
- **Root Cause**: The `Import-ImagesToKind` function implemented a "soft" fallback: `$version = if ($ImageVersions[$img]) { ... } else { "latest" }`.
- **Remediation (Authoritative Pattern)**:
    1. **Independent Resolution**: Functions that depend on image versions MUST be capable of idempotent resolution from source (VERSION files) if the orchestrator's global cache is empty.
    2. **Elimination of Fallbacks**: The "latest fallback" is now prohibited. If a version cannot be resolved or found in the cache, the script must terminate immediately with a reference to the missing metadata.
    3. **Authoritative Mapping**: Use a hardcoded or derived mapping of service names to VERSION file paths within the loading function to ensure it can always identify the correct tag without build-step prerequisites.

### 11.13 TUI State Machine Ready-Mode Hazard (v3.1.8 Audit)

**The Failure Mode**: The TUI implements a bypass mechanism where if `ClusterStatus::Ready` is detected at startup, it proceeds directly to the `Dashboard`. If the cluster is functionally "Ready" (API responding) but structurally "Stale" (incorrect tags), the user may attempt to trigger a manual repair. In this state, background setup threads may conflict with the TUI's cached view or fail to render the new diagnostics.

**The Diagnostic Proof (v3.1.8 Audit)**:
- **Discovery**: A developer reported "Still immediately fails" when clicking "Launch" while the cluster was already running. This indicates the TUI's state machine may be in a state where it doesn't correctly capture the script's diagnostics if triggered outside the standard flow.
- **Remediation**: Use the 'R' (Refresh) key to force re-evaluation, or perform an authoritative stop (`start-all.ps1 -Stop`) before re-launching.

### 11.14 The Extended Path Resolution Hazard (v3.1.8 Fix)

**The Failure Mode**: In Windows environments, the TUI may pass paths to the orchestration layer using the extended path prefix (`\\?\`). While this bypasses path length limits, it can break script logic that relies on string-based path matching or specific `Split-Path` behaviors if the script expect standard DOS-style paths.

**The Diagnostic Proof (v3.1.8 Audit)**:
- **Incident**: After hardening root resolution, the TUI still failed with "Project root could not be resolved" even though the CWD was correct.
- **Discovery**: Structured diagnostics (Section 11.11) revealed `PSScriptRoot='\\?\E:\projects\odd-demonstration\scripts'`. The `\\?\` prefix was preventing the marker-based walk from correctly identifying the `infra/` directory.
- **Remediation**: Updated the Hardened Root Resolution Pattern to explicitly strip the `\\?\` prefix before processing: `$scriptRoot = $PSScriptRoot -replace '^\\\\\?\\', ''`.

### 11.15 Connectivity Probe Race Condition (v3.1.8 Fix)

**The Failure Mode**: Even when `start-all.ps1` reports "System ready", the TUI's verification step (Verify Connectivity) may fail with "Read Model not reachable". This results from a race condition between the cluster's internal pod readiness, the TUI's background port-forwarding initialization, and the service's internal state convergence.

**The Diagnostic Proof (v3.1.8 Audit)**:
- **Incident**: Cluster launch successfully builds and loads all versioned images (`:0.1.0`), and all pods reach `Ready` state, but the final TUI verification yields a fatal reachability error.
- **Root Cause**: The orchestrator exited as soon as Kubernetes reported pods were `Ready`. However, port-forwarding (via `kubectl port-forward`) is asynchronous. The orchestrator's 2-second wait (`Start-Sleep -Seconds 2`) was insufficient for the TCP tunnels to stabilize.
- **TUI State Machine Hazard**: The TUI (`cluster.rs`) parses the script's JSON stream. It contains a trap: `if status == "error" { p.has_error = true; }`. Because `Test-Connectivity` was emitting `status: "error"` upon timeout, the TUI marked the entire launch as "Setup Failed" even though the cluster was fully functional ("System ready").
- **Remediation**:
    1. **Bounded Retry Loop**: Implemented a polling mechanism that waits up to 15 seconds for connectivity, checking every 2 seconds.
    2. **Status Convergence**: The script now only reports "System ready" if the connectivity test passes; otherwise, it reports a "warning" status.
    3. **Warning Protocol**: By switching to `status: "warning"`, the script informs the user of the delay without triggering the TUI's fatal error state. This allows the user to simply press 'R' (Refresh) once the tunnels stabilize.
    4. **Final Tier (TUI Recovery)**: As of Phase 35 (v3.1.14), the TUI implements a **Multi-Tiered Readiness Probe**. If the orchestrator reports "System ready" but the local tunnels have died (e.g., due to a terminal restart), the TUI auto-detects the failure via direct health probes and re-initiates the `kubectl port-forward` commands during its loading phase.

### 11.16 The Trigger Decoupling Hazard (v3.1.12)
**The Hazard**: In monorepos using path-based filtering (e.g., `dorny/paths-filter`) to optimize CI execution, a secondary **Governance Gap** occurs when the build matrix is expanded but the job-level trigger is not updated.
- **Incidence**: When `web-ui` was added to the build matrix, the trigger `if: ...` condition only checked the `services` filter (matching `src/services/**`). Since `web-ui` resides in `src/interfaces/web/**`, changes to the Web UI would not trigger a rebuild.
- **Remediation**: Transitioned to **Total Trigger Coverage**. All monorepo build jobs must logically group every path-filter output representing a matrix service using OR logic in the job's entry condition.
- **Verification**: Hardened `ci.yml` entry condition to include `web_terminal` filter logic.
## 11. Safe Cluster Termination & Resource Cleanup (v3.1.20)

To ensure a clean environment and prevent "Ghost Port" conflicts, the ODTO platform follows a strict 3-stage shutdown sequence.

### 11.1 The Cleanup Hazard
**The Problem**: Background port-forwarding processes (like `kubectl port-forward`) are often started as detached processes (refer to **Pattern 9: Windows Subprocess Job Scoping**). 
- **The Symptom**: Deleting the Kubernetes cluster (`kind delete cluster`) does not automatically terminate these local proxy processes.
- **The Failure**: Stale port-forward processes can keep local ports bound (e.g., 3000, 8080), preventing subsequent cluster launches from success.

### 11.2 The Termination Protocol
The system implements a deterministic teardown sequence triggered by **Ctrl+Q** in the Dashboard (adhering to **Pattern 10: PID-Scoped Resource Lifecycle Management**):

1.  **Stage 1: Connectivity Teardown (PID-Scoped)**: Forcefully terminate all local proxy processes by targeting PIDs stored in the `PortForwardRegistry`. This avoids collateral damage to unrelated host processes.
2.  **Stage 2: Infrastructure Teardown (Cluster)**: Delete the local Kubernetes cluster using the centralized **`CLUSTER_NAME`** constant to ensure the correct target is removed.
3.  **Stage 3: Process Exit**: Once cleanup is verified, the TUI exits and signals the Web Mirror to enter its disconnected/auto-retry state.

**TUI Pattern: Modifier Precedence**  
To distinguish between the destructive "Shutdown" (Ctrl+Q) and non-destructive "Quit" (Q), the event handler must evaluate modifiers **before** the character check or as part of a specific match arm. This prevents a Ctrl+Q press from falling through to the ‘q’ exit if the modifier is not explicitly checked first.

### 11.3 Platform-Specific Cleanup (ODTO Implementation)

**Windows (PowerShell Capture)**:
The TUI spawns `kubectl` via PowerShell to capture the PID from the `-PassThru` object:
```powershell
$proc = Start-Process -PassThru -WindowStyle Hidden -FilePath kubectl `
    -ArgumentList 'port-forward', 'svc/...', '...', '--context', 'kind-task-observatory'
Write-Output $proc.Id
```

**UNIX (Direct Termination)**:
The TUI uses `child.id()` from `std::process::Child` and terminates via SIGTERM:
```bash
# Authoritative termination of specific tracked PIDs
kill -TERM $trackedPid
```

## 12. Shared Configuration Authority

To prevent drift between cluster creation, status checking, and deletion, the system centralizes infrastructure identities in `src/interfaces/tui/src/types.rs`:

- **`CLUSTER_NAME`**: The authoritative name for the Kind cluster (`task-observatory`).
- **`KUBECTL_CONTEXT`**: The canonical context used for all kubectl commands (`kind-task-observatory`).
- **`CLUSTER_NAME` in `start-all.ps1`**: This script also consumes these values to ensure the bootstrap and teardown paths are 100% symmetric.

## 13. Web Mirror Lifecycle Resilience

The Shutdown command creates a unique lifecycle event for the Web Mirror:
- **PTY Session Integrity**: When the TUI exits, the `web-pty-server` detects the child process termination and notifies the client.
- **Auto-Retry Persistence**: The Web Mirror (`terminal.js`) implements a **20s auto-retry interval** and a retry button that allows the environment to recover automatically once a new cluster is provisioned.
- **Deterministic Testing**: The mirror exposes `__odtoTestHooks` (e.g., `simulateDisconnect`, `triggerRetry`) to enable automated Playwright verification of the reconnection state machine.
