# Service Credentials & Access Points

This document provides an authoritative record of credentials and ports for the core microservices and infrastructure components of the Distributed Task Observatory (ODTO).

## Infrastructure Access

| Service | Protocol | Host (Internal) | Port | Local Access (via Port-Forward) | Default Credentials |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **RabbitMQ** | AMQP | `rabbitmq` | 5672 | `localhost:5672` | `guest` / `guest` |
| **RabbitMQ UI** | HTTP | `rabbitmq` | 15672 | `localhost:15672` | `guest` / `guest` |
| **PostgreSQL** | TCP | `postgres` | 5432 | `localhost:5432` | `admin` / `admin` (DB: `task_db`) |
| **MongoDB** | TCP | `mongodb` | 27017 | `localhost:27017` | `admin` / `password123` |
| **Redis** | TCP | `redis` | 6379 | `localhost:6379` | *No password by default* |
| **Prometheus** | HTTP | `prometheus` | 9090 | `localhost:9090` | *No auth by default* |
| **Grafana** | HTTP | `grafana` | 3000 | `localhost:3002` | `admin` / `admin` |

## Environment-Specific Overrides

### Integration Environment (`docker-compose.integration.yml`)
In the integration environment used for automated tests, credentials may differ to ensure isolation:

- **RabbitMQ**: `observatory` / `demo`
- **MongoDB**: `admin` / `password123`

### Demo Environment (`docker-compose.demo.yml`)
- **RabbitMQ**: `observatory` / `demo`

## Service APIs

| Service | Port | Endpoint (Status) | Access Points |
| :--- | :--- | :--- | :--- |
| **Gateway** | 3000 | `/healthz` | `localhost:3000`, `localhost:3000/docs` |
| **Read Model** | 8080 | `/health` | `localhost:8080/stats`, `localhost:8080/docs` |
| **Web Dashboard**| 8081 | `/` | `localhost:8081` |
| **PTY Server** | 9000 | `/health` | `localhost:9000` (WebSocket) |

## Database Admin UIs

| UI Tool | Default Port | Local Port | Default Credentials |
| :--- | :--- | :--- | :--- |
| **pgAdmin** | 80 | 5050 | `admin@example.com` / `admin` |
| **Mongo Express**| 8081 | 8082 | `admin` / `password123` |
| **RedisInsight** | 5540 | 8001 | *Web-based UI* |

> [!NOTE]
> **RedisInsight Port Hazard**: Historically, Mongo Express and RedisInsight ports were swapped in some manifests. As of v1.1.1, RedisInsight listens on port 5540 internally but is forwarded to `localhost:8001`.
