# Port-Forward Health Check & Auto-Recovery (Phase 35)

## The Hazard: Ephemeral Port-Forwarding
While `kubectl` confirms the cluster is running on the backend, interactive operations (like Task Creation) often depend on **local port-forwards** (`localhost:3000` -> `gateway:3000`).
- **Hazard**: Port-forwards initiated via background shell jobs (e.g., `Start-Job` in PowerShell) are typically session-scoped and expire when the spawning terminal is closed or the parent process exits.
- **Symptom**: If the user restarts their terminal, the tunnels die, but the cluster remains `Ready`.
- **Dashboard Fallacy**: The TUI detects the cluster is ready and loads the dashboard, but clicking "Add Task" results in a **Gateway timeout (2s)** because the tunnel to port 3000 is gone.

## The Standard: Multi-Tiered Readiness Probe
To ensure high-fidelity orchestration, the TUI must validate all levels of the stack before enabling interactive features:
1. **Tier A (Infrastructure)**: Verify the cluster exists (`kind get nodes`).
2. **Tier B (Service)**: Verify target pods are in a `Running` state and healthy.
3. **Tier C (Local)**: Perform a direct health check on the local port (e.g., `GET http://localhost:3000/healthz`).

## Implementation Details (v3.1.14 Complete)

### 1. Port-Forward Verification logic
The TUI implements the `PortForwardStatus` enum to track service-specific connectivity:

```rust
#[derive(Debug, Clone, PartialEq)]
pub enum PortForwardStatus {
    AllHealthy,          // Both Gateway and Read Model reachable
    GatewayUnhealthy,    // Gateway unreachable, Read Model OK
    ReadModelUnhealthy,  // Read Model unreachable, Gateway OK
    AllUnhealthy,        // Neither service reachable
    Error(String),       // Error during health check
}
```

### 2. Auto-Recovery Mechanism
If the cluster/pods are `Ready` but the local probes fail, the TUI attempts to re-establish the tunnels. 

**CRITICAL (Windows Lifetime Standard)**: On Windows, the TUI MUST use `Start-Process -WindowStyle Hidden` instead of `Start-Job`. PowerShell Jobs are session-scoped and die when the spawning PowerShell process (initiated via `Command::new`) exits. Detached processes via `Start-Process` persist independently.

```rust
/// Start port-forwards for unhealthy services
pub fn ensure_port_forwards(gateway_url: &str, read_model_url: &str) -> Result<(), String> {
    // 1. Check current status
    // 2. Identify missing tunnels (Gateway, Read-Model, or both)
    // 3. Spawn background 'kubectl port-forward' processes:
    //    - Windows (Detached): 
    //        Command::new("powershell.exe")
    //            .args(["-NoProfile", "-Command", "Start-Process -WindowStyle Hidden -FilePath kubectl -ArgumentList 'port-forward', 'svc/gateway', '3000:3000'..."])
    //    - Unix (Direct): 
    //        Command::new("kubectl").args(["port-forward", "svc/gateway", "3000:3000", "&"])...
    // 4. Poll for health success (max 5s timeout)
}
```

### 3. Loading Flow Integration
The transition to `AppMode::Dashboard` is gated by the background loading thread which ensures port-forwards are healthy before fetching data.

```rust
// Finalized Loading Logic (main.rs)
let handle = thread::spawn(move || {
    // Step 1: Ensure port-forwards are healthy (or restarted)
    let _ = ensure_port_forwards(&gateway_url_clone, &api_url_clone);
    
    // Step 2: Refresh data only after connectivity is verified
    let mut background_app = App::new(api_url_clone, gateway_url_clone);
    background_app.refresh();
    loading_done_clone.store(true, Ordering::SeqCst);
    background_app
});

// ... wait for thread ...

// Final verification before Dashboard
if let Err(_) = ensure_port_forwards(&app.gateway_url, &app.api_url) {
    app.alerts_error = Some("Port-forwards unhealthy - task creation may fail".to_string());
}
app.mode = AppMode::Dashboard;
```


## Status
- **Plan Approved**: December 27, 2025
- **Implementation Status**: Stabilizing (v3.1.14 / Branch `fix/tui-port-forward-health-check`)
- **Verified**: 147/148 unit tests passed. Addressing intermittent project root resolution failure in tests.
