# Architecture Diagram Audit: Data Flow Correction

## Overview
This document records the audit and correction of the system's architectural diagrams to ensure they accurately represent the data flow within the Distributed Task Observatory.

## Identified Inaccuracies
Six semantic errors were identified in the Mermaid diagrams across several files (`architecture/system-diagram.md`, `architecture/runtime.md`, `architecture/observability.md`, `README.md`, and `experiment/test.html`).

### 1. Read Model → PostgreSQL (Reversed)
- **Error**: Diagrams showed Step 5 "Query updated views" flowing from the Read Model API to PostgreSQL.
- **Correction**: Data flows from **PostgreSQL to the Read Model API**.
- **Scope**: Applied to both the **Task Creation Flow (Step 5)** and the **Core Runtime Connections** sections.
- **Evidence**: 
    - `src/services/read-model/main.go`: The `recentJobsHandler` executes a SQL `SELECT` query on the `jobs` table to retrieve data.
    - `scripts/integration-gate.ps1`: The integration test calls `GET /jobs/recent` and expects the response to contain job data sourced from the database.

### 2. Grafana → Prometheus (Reversed)
- **Error**: Diagrams showed data flowing from Grafana to Prometheus.
- **Correction**: Data flows from **Prometheus to Grafana**.
- **Evidence**: 
    - Grafana acts as the visualization layer that queries Prometheus as a data source. The flow of metrics data is from the source (Prometheus) to the consumer (Grafana).

### 3. Prometheus → Metrics Engine (Reversed / Pull Model)
- **Error**: Diagrams showed Step "Prometheus -.-> Metrics" (Metrics Engine).
- **Correction**: Data flows from **Metrics Engine to Prometheus** (Scrape model).
- **Evidence**: 
    - `infra/prometheus/prometheus.yml`: Explicitly defines a scrape job for `metrics-engine`.
    - `infra/k8s/metrics-engine.yaml`: Service exposes port for scraping.
    - Prometheus follows a "Pull" model where it fetches metrics from targets.

### 4. Metrics Engine → RabbitMQ (Reversed / Consumer)
- **Error**: Diagrams showed Step `Metrics -.-> RabbitMQ` (pointing to RabbitMQ).
- **Correction**: Data flows from **RabbitMQ to Metrics Engine**.
- **Evidence**: 
    - `src/services/metrics-engine/main.go`: Uses `ch.Consume("jobs.completed", ...)` to receive messages from the queue.
    - The service is a subscriber/consumer of events from the RabbitMQ event spine.

### 5. Read Model → MongoDB (Reversed)
- **Error**: Diagrams showed `ReadModel -.-> Mongo`.
- **Correction**: Data flows from **MongoDB to the Read Model API**.
- **Evidence**: 
    - `src/services/read-model/main.go`: The `eventsHandler` executes `eventsColl.Find` to retrieve event data from MongoDB.

### 6. Read Model → Redis (Reversed)
- **Error**: Diagrams showed `ReadModel -.-> Redis`.
- **Correction**: Data flows from **Redis to the Read Model API**.
- **Evidence**: 
    - `src/services/read-model/main.go`: The `statsHandler` uses `rdb.Get` to retrieve cached metrics from Redis.

## Verified Correct Flows
The following connections were audited and found to be accurately represented in the original diagrams:

- **Processor → PostgreSQL**: The Processor (Python) explicitly writes job data to the database using `INSERT` and `UPDATE` statements in `src/services/processor/main.py`.

## Resolution Summary
The arrow directions were reversed in the following diagrams:

| Diagram Component | Old Flow | New Corrected Flow |
|------------------|----------|-------------------|
| Task Creation Step 5 | `ReadModel --> Postgres` | `Postgres --> ReadModel` |
| Core Runtime (Read) | `ReadModel -.- Postgres` | `Postgres -.- ReadModel` |
| Observability (Metrics Source) | `Prometheus -.-> Metrics` | `Metrics -.-> Prometheus` |
| Observability (Dashboards) | `Grafana -.-> Prometheus` | `Prometheus -.-> Grafana` |
| Event Consumption | `Metrics -.-> RabbitMQ` | `RabbitMQ -.-> Metrics` |
| Read Model (Mongo) | `ReadModel -.-> Mongo` | `Mongo -.-> ReadModel` |
| Read Model (Redis) | `ReadModel -.-> Redis` | `Redis -.-> ReadModel` |

## Corrected Files
The corrections have been applied to:
- `architecture/system-diagram.md`
- `architecture/runtime.md`
- `architecture/observability.md`
- `README.md`
- `experiment/test.html`

## Conclusion
The audit ensures that the documentation is semantically consistent with the actual implementation and communication patterns of the services.
