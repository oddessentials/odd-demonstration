# Shutdown Feature Implementation Walkthrough

## Summary

Implemented a safe "Shutdown" feature for the TUI dashboard and web mirror with:
- **Ctrl+Q** key binding for shutdown (plain Q remains non-destructive quit)
- **PID-scoped port-forward cleanup** (only kills processes started by this TUI instance)
- **Cluster name constant** (single source of truth)
- **20s auto-retry** for web mirror recovery after disconnect
- **Test hooks** for Playwright testing

---

## Changes Made

### TUI Core - Types Module

#### [types.rs](file:///e:/projects/odd-demonstration/src/interfaces/tui/src/types.rs)

**Added constants:**
- `CLUSTER_NAME: &str = "task-observatory"` - Single source of truth for cluster name
- `KUBECTL_CONTEXT: &str = "kind-task-observatory"` - Derived kubectl context

**Added types:**
- `ShutdownProgress` struct - Tracks shutdown step, message, completion, errors
- `PortForwardRegistry` struct - Stores (service_name, PID) pairs for port-forwards
- `AppMode::ShutdownProgress` variant - New app mode for shutdown UI

**Updated `App` struct:**
- Added `shutdown_progress: Arc<Mutex<ShutdownProgress>>`
- Added `port_forward_registry: Arc<Mutex<PortForwardRegistry>>`

---

### TUI Core - Cluster Module

#### [cluster.rs](file:///e:/projects/odd-demonstration/src/interfaces/tui/src/cluster.rs)

**Replaced hardcoded context strings (4 places):**

```diff
-.args(["get", "nodes", "--context", "kind-task-observatory", ...])
+.args(["get", "nodes", "--context", KUBECTL_CONTEXT, ...])
```

**New functions:**

| Function | Purpose |
|----------|---------|
| `start_port_forward_tracked()` | Starts port-forward and records PID in registry |
| `stop_port_forwards()` | Kills only PIDs from registry (PID-scoped, safe) |
| `delete_cluster()` | Deletes Kind cluster using `CLUSTER_NAME` constant |
| `run_shutdown()` | Orchestrates shutdown sequence with progress reporting |

---

### TUI Core - Main Module

#### [main.rs](file:///e:/projects/odd-demonstration/src/interfaces/tui/src/main.rs)

**Added imports:**
- `KeyModifiers` from crossterm for Ctrl+Q detection
- `ShutdownProgress` and `run_shutdown` from library

**Added Ctrl+Q handler in Dashboard mode:**

```rust
// Ctrl+Q = Shutdown cluster and exit (destructive)
if key.code == KeyCode::Char('q') && key.modifiers.contains(KeyModifiers::CONTROL) {
    app.mode = AppMode::ShutdownProgress;
    let progress = Arc::clone(&app.shutdown_progress);
    let registry = Arc::clone(&app.port_forward_registry);
    thread::spawn(move || {
        run_shutdown(progress, registry);
    });
}
```

**Updated help bar:**

```
 Q Quit  R Refresh  N New Task  U UIs  ^Q Shutdown  │  v3.1.0
```

**Added ShutdownProgress rendering:**
- Centered modal with "🛑 Shutting Down" title
- Spinner animation during shutdown
- Green checkmark on success, red X on error
- "Press any key to exit..." when complete

---

### Web Mirror

#### [terminal.js](file:///e:/projects/odd-demonstration/src/interfaces/web/terminal.js)

**Added auto-retry interval:**

```javascript
const CONFIG = {
    // ...
    autoRetryInterval: 20000,  // 20s auto-retry when disconnected
};
```

**Added auto-retry timer management:**
- `showFallback()` starts 20s interval timer for auto-retry
- `showTerminal()` clears timer when connected
- Timer cleared on page unload

**Added test hooks for Playwright:**

```javascript
window.__odtoTestHooks = {
    getConnectionStatus: () => ({ connected, sessionActive, reconnectAttempts, intentionalClose, autoRetryActive }),
    simulateDisconnect: () => { /* closes WebSocket, allows reconnect */ },
    triggerRetry: () => retryConnection(),
    getAutoRetryInterval: () => CONFIG.autoRetryInterval,
};
```

---

### Visual Tests

#### [retry-on-disconnect.spec.ts](file:///e:/projects/odd-demonstration/tests/visual/retry-on-disconnect.spec.ts)

New Playwright test file with tests for:
- Test hooks are available and expose correct status shape
- Auto-retry interval is 20 seconds
- Retry button triggers reconnect attempt
- simulateDisconnect closes WebSocket gracefully

---

### Documentation

#### [README.md](file:///e:/projects/odd-demonstration/README.md)

Updated cleanup section:

```markdown
## 🛑 Cleanup

**Via TUI (recommended):**
Press **Ctrl+Q** in the dashboard to cleanly stop port-forwards and delete the cluster.

**Manual cleanup:**
...
```

---

## Testing Results

**TUI Tests:**
```
test result: ok. 167 passed; 0 failed; 1 ignored
```

**New tests added:**
- `test_cluster_name_constant`
- `test_kubectl_context_constant`
- `test_kubectl_context_derived_from_cluster_name`
- `test_shutdown_progress_default`
- `test_shutdown_progress_fields`
- `test_shutdown_progress_with_error`
- `test_shutdown_progress_clone`
- `test_port_forward_registry_default`
- `test_port_forward_registry_tracks_pids`
- `test_port_forward_registry_clone`
- `test_port_forward_registry_clear`
- `test_app_mode_shutdown_variant`
- `test_stop_port_forwards_empty_registry`
- `test_stop_port_forwards_clears_registry`
- `test_delete_cluster_returns_result`

---

## Key Design Decisions

### 1. PID-Scoped Port-Forward Cleanup

**Problem:** The original plan used broad `pkill -f "kubectl port-forward"` which could kill unrelated kubectl processes.

**Solution:** Track PIDs of port-forwards started by this TUI instance in `PortForwardRegistry`. Only those specific PIDs are killed during shutdown.

### 2. Cluster Name Constant

**Problem:** Cluster name was hardcoded in multiple places, creating drift risk.

**Solution:** `CLUSTER_NAME` and `KUBECTL_CONTEXT` constants in `types.rs` serve as single source of truth. All kubectl commands use these constants.

### 3. Ctrl+Q vs Plain Q

**Problem:** Need to distinguish between quick quit (no cleanup) and full shutdown.

**Solution:** 
- **Q** = Quit only (non-destructive, leaves cluster running)
- **Ctrl+Q** = Shutdown (stops port-forwards, deletes cluster, then exits)

### 4. Web Mirror Recovery

**Problem:** When TUI shuts down, web terminal loses connection.

**Solution:** 20-second auto-retry interval automatically attempts reconnection. User can also click retry button manually.

---

## Files Modified

| File | Changes |
|------|---------|
| `src/interfaces/tui/src/types.rs` | Added constants, types, App fields |
| `src/interfaces/tui/src/cluster.rs` | Added shutdown functions, replaced hardcoded contexts |
| `src/interfaces/tui/src/main.rs` | Added Ctrl+Q handler, help bar, shutdown modal |
| `src/interfaces/tui/src/lib.rs` | Exported new items |
| `src/interfaces/web/terminal.js` | Added auto-retry, test hooks |
| `tests/visual/retry-on-disconnect.spec.ts` | New test file |
| `README.md` | Updated cleanup section |

---

## Final Delivery

**Status: ✅ COMMITTED & PUSHED**  
- **Branch**: `feat/stop-cluster`
- **Verification**: 167 total tests passing.
- **Key Outcome**: Safe, deterministic cluster termination with no host port leakage and automated web mirror recovery.
